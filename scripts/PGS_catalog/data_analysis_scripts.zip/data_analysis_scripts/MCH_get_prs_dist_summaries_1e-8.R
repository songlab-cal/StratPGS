####################################################
########### Mean Corpuscular Hemoglobin ############
############## Shuffling Experiment ################
########### Range of Target SNP cutoffs 1e-8 #######
############ Shuffle and Sign flips  ###############
####################################################
# This version computes sensitivity of mean corpuscular haemoglobin
# PRSs from PGS Catalog. 
# 6/12/23: Performs a pre-check of corr(y,orig. PRS) to decide
# if y needs to be flipped prior to evaluating metrics.

#################
## Directories ##
#################
# Create output file 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/MCH_get_dist_summaries_cutoff1e-8.log')
sink(stdout(), type = "message")

library(data.table)
library(dplyr)
library(bigsnpr)

R.workbench <- FALSE
sig.cutoff <- '1e-8'
message('sig.cutoff = ', sig.cutoff)

if (R.workbench) {
  shuffled.prs.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  pheno.gwas.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/tables/'
} else {
  shuffled.prs.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  pheno.gwas.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/tables/'
}

##########
## Main ##
##########
prs.ids <- c("PGS000099","PGS000174","PGS001219","PGS001989","PGS002206","PGS002339",
             "PGS002371","PGS002411","PGS002460","PGS002509","PGS002558","PGS002607",
             "PGS002656","PGS002705","PGS003560")

message(date(), ": Computing magnitudes and variances...")
mag.var.df <- data.frame(PRS = character(),
                         N_SNPS = numeric(),
                         N_TARGET_SNPS = numeric(),
                         MAX_MAG_BKGRD = numeric(),
                         MEDIAN_MAG_BKGRD = numeric(),
                         AVE_MAG_BKGRD = numeric(),
                         BETA_WILCOX_PVAL = numeric(),
                         VAR_BKGRD = numeric(),
                         SUM_BKGRD = numeric(),
                         MAX_MAG_TARGET = numeric(),
                         MEDIAN_MAG_TARGET = numeric(),
                         AVE_MAG_TARGET = numeric(),
                         VAR_TARGET = numeric(),
                         SUM_TARGET = numeric(),
                         SUM_RATIO_TARGET_BKGRD = numeric())
message(date(),": ", length(prs.ids), " PRSs detected.")
for (pheno in prs.ids) {
  # Print message
  message(date(), ": Working on ", pheno)
  
  # Load GWAS results 
  message("Loading GWAS results...")
  pheno.gwas <- data.table::fread(paste0(pheno.gwas.dir,
                                         "v2_files/",
                                         pheno,
                                         "_matched_v2.txt"))
  
  # Subset to only those variants with valid beta value
  message("Removing ", 
          round(100*sum(is.na(pheno.gwas$beta))/nrow(pheno.gwas)), 
          "% of variants that could not be matched. Variants are located in:")
  print(table((pheno.gwas %>% subset(is.na(beta)))$chr_name))
  pheno.gwas <- pheno.gwas %>% subset(!is.na(beta))
  
  # Compute variance and magnitudes of effect sizes
  # for participating SNPs and background SNPs
  message("Collecting metrics...")
  rel.inds <- which(pheno.gwas$gwas_p_value >= as.numeric(sig.cutoff))
  n.snps <- length(pheno.gwas$gwas_p_value)
  n.target.snps <- length(rel.inds)
  
  var.target <- var(pheno.gwas$beta[rel.inds])
  var.bkgrd <- var(pheno.gwas$beta[-rel.inds])
  
  abs.betas <- abs(pheno.gwas$beta)
  max.mag.target <- max(abs.betas[rel.inds])
  mean.mag.target <- mean(abs.betas[rel.inds])
  median.mag.target <- median(abs.betas[rel.inds])
  
  max.mag.bkgrd <- max(abs.betas[-rel.inds])
  mean.mag.bkgrd <- mean(abs.betas[-rel.inds])
  median.mag.bkgrd <- median(abs.betas[-rel.inds])
  
  # Are target variant esizes > bkgrd variant esizes?
  beta.wilcox.p <- wilcox.test(abs.betas[rel.inds],
                               abs.betas[-rel.inds],
                               alternative = 'greater')$p.value
  
  # What's the sum(|beta_target|)/sum(|beta_causal|)
  sum.target <- sum(abs.betas[rel.inds])
  sum.bkgrd <- sum(abs.betas[-rel.inds])
    
  new.row <- data.frame(PHENOTYPE = pheno,
                        N_SNPS = n.snps,
                        N_TARGET_SNPS = n.target.snps,
                        MAX_MAG_BKGRD = max.mag.bkgrd,
                        MEDIAN_MAG_BKGRD = median.mag.bkgrd,
                        AVE_MAG_BKGRD = mean.mag.bkgrd,
                        BETA_WILCOX_PVAL = beta.wilcox.p,
                        VAR_BKGRD = var.bkgrd,
                        SUM_BKGRD = sum.bkgrd,
                        MAX_MAG_TARGET = max.mag.target,
                        MEDIAN_MAG_TARGET = median.mag.target,
                        AVE_MAG_TARGET = mean.mag.target,
                        VAR_TARGET = var.target,
                        SUM_TARGET = sum.target,
                        SUM_RATIO_TARGET_BKGRD = sum.target/sum.bkgrd)
  
  # writeLines(as.vector(new.row) %>% `colnames<-`(NULL) %>% as.character(), 
  #            fileConn)

  # Add new row
  mag.var.df <- rbind(mag.var.df,
                      new.row)
  
}

readr::write_csv(mag.var.df, 
                 file = paste0(out.dir, "prs_dist_summaries_cutoff",sig.cutoff,".csv"))
# close(fileConn)
sink()
####################################################
########### Mean Corpuscular Hemoglobin ############
############ Perturbation Experiment ###############
########### Range of Target SNP cutoffs 1e-10 #######
############ Shuffle and Sign flips  ###############
####################################################
# This version combines original PRS metrics and distribution metrics
# to detect significant relationships

#################
## Directories ##
#################
# Create output file 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/MCH_get_dist_vs_orig_perf_cutoff_1e-10_logtransformcounts_062823.log')
sink(stdout(), type = "message")

library(data.table)
library(dplyr)
library(bigsnpr)

R.workbench <- FALSE
sig.cutoff <- '1e-10'
message('sig.cutoff = ', sig.cutoff)

if (R.workbench) {
  in.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/tables/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/dist_vs_orig_perf/'
} else {
  in.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/tables/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/dist_vs_orig_perf/'
}

### Analysis -------------------------------------------------------------------
# Read distribution file
prs_combined_df <- readr::read_csv(paste0(in.dir,'orig_prs_perf_vs_dist_summary_cutoff',
                                          sig.cutoff,'.csv'),
                                   show_col_types = FALSE) %>% 
  as.data.frame()

# Log transform before computing correlations
message(date(), ": Log-transforming variant counts")
prs_combined_df$N_TARGET_SNPS <- log(prs_combined_df$N_TARGET_SNPS)
prs_combined_df$N_SNPS <- log(prs_combined_df$N_SNPS)

# Analyze trends - compute p-values and correlations
dist_vs_orig_perf_corr_array <- matrix(NA,nrow=11,ncol=14)
dist_vs_orig_perf_pvals_array <- matrix(NA,nrow=11,ncol=14)

colnames(dist_vs_orig_perf_corr_array) <- colnames(prs_combined_df)[2:15]
rownames(dist_vs_orig_perf_corr_array) <- colnames(prs_combined_df)[16:26]

colnames(dist_vs_orig_perf_pvals_array) <- colnames(prs_combined_df)[2:15]
rownames(dist_vs_orig_perf_pvals_array) <- colnames(prs_combined_df)[16:26]

n.tests <- nrow(dist_vs_orig_perf_pvals_array)*ncol(dist_vs_orig_perf_pvals_array)
message(date(), ": No. tests performed = ", n.tests)
fwer.thres.cutoff <- 0.05/n.tests
message(date(), ": FWER corrected p-value threshold = ", fwer.thres.cutoff)

for (i in 1:nrow(dist_vs_orig_perf_corr_array)) {
  for (j in 1:ncol(dist_vs_orig_perf_corr_array)) {
    # Shuffle, max
    dist_vs_orig_perf_corr_array[i,j] <- cor(prs_combined_df[[rownames(dist_vs_orig_perf_corr_array)[i]]],
                                             prs_combined_df[[colnames(dist_vs_orig_perf_corr_array)[j]]])
    p_val <- cor.test(prs_combined_df[[rownames(dist_vs_orig_perf_corr_array)[i]]],
                      prs_combined_df[[colnames(dist_vs_orig_perf_corr_array)[j]]])$p.value
    spearman_p_val <- cor.test(prs_combined_df[[rownames(dist_vs_orig_perf_corr_array)[i]]],
                               prs_combined_df[[colnames(dist_vs_orig_perf_corr_array)[j]]],
                               method = 'spearman')$p.value
    dist_vs_orig_perf_pvals_array[i,j] <- p_val
    if (is.na(p_val)) {
      message('Constant value observed for ', rownames(dist_vs_orig_perf_corr_array)[i])
    } else if (p_val < fwer.thres.cutoff) {
      message('Significant correlation (p = ',p_val,') between ', 
              rownames(dist_vs_orig_perf_corr_array)[i], ' and ', 
              colnames(dist_vs_orig_perf_corr_array)[j])
      message('Pearson r = ', dist_vs_orig_perf_corr_array[i,j])
    }
    if (spearman_p_val < fwer.thres.cutoff) {
      message('Significant Spearman correlation (p = ',p_val,') between ', 
              rownames(dist_vs_orig_perf_corr_array)[i], ' and ', 
              colnames(dist_vs_orig_perf_corr_array)[j])
      message('Spearman rho = ', cor(prs_combined_df[[rownames(dist_vs_orig_perf_corr_array)[i]]],
                                     prs_combined_df[[colnames(dist_vs_orig_perf_corr_array)[j]]],
                                     method = 'spearman'))
      message('Spearman rho p-value = ', spearman_p_val)
    }
  }
}

# Convert to dataframe and include sensitivity metrics as a new feature column
dist_vs_orig_perf_corr_array <- as.data.frame(dist_vs_orig_perf_corr_array)
dist_vs_orig_perf_corr_array$SENSITIVITY_METRIC <- rownames(dist_vs_orig_perf_corr_array)
dist_vs_orig_perf_pvals_array <- as.data.frame(dist_vs_orig_perf_pvals_array)
dist_vs_orig_perf_pvals_array$SENSITIVITY_METRIC <- rownames(dist_vs_orig_perf_pvals_array)

# Save files
readr::write_csv(dist_vs_orig_perf_corr_array,
                 file = paste0(out.dir,"corr_cutoff",
                               sig.cutoff,"_prs_dist_vs_orig_perf.csv"))
readr::write_csv(dist_vs_orig_perf_pvals_array,
                 file = paste0(out.dir,"pvals_cutoff",
                               sig.cutoff,"_prs_dist_vs_orig_perf.csv"))
sink()
####################################################
########### Mean Corpuscular Hemoglobin ############
############## Shuffling Experiment ################
########### Range of Target SNP cutoffs 1e-8 #######
############ Shuffle and Sign flips  ###############
####################################################
# This version computes sensitivity of mean corpuscular haemoglobin
# PRSs from PGS Catalog. 
# 6/12/23: Performs a pre-check of corr(y,orig. PRS) to decide
# if y needs to be flipped prior to evaluating metrics.

#################
## Directories ##
#################
# Create output file 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/MCH_get_perturb_sensitivity_cutoff1e-8_JeremyTest_062823.log')
sink(stdout(), type = "message")

library(data.table)
library(dplyr)
library(bigsnpr)

R.workbench <- FALSE
sig.cutoff <- '1e-8'
message('sig.cutoff = ', sig.cutoff)

if (R.workbench) {
  shuffled.prs.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  pheno.gwas.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/v2_files/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/Jeremy_test/'
  autosome.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_autosome_metadata.csv',
                                       show_col_types = FALSE)
  phenos.subset.df <- readr::read_csv('/deep_learning/aaw/032323/phenos/phenos_subset_df.csv',
                                      show_col_types = FALSE)
} else {
  shuffled.prs.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  pheno.gwas.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/v2_files/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/Jeremy_test/'
  autosome.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_autosome_metadata.csv',
                                       show_col_types = FALSE)
  phenos.subset.df <- readr::read_csv('/illumina/scratch/deep_learning/aaw/032323/phenos/phenos_subset_df.csv',
                                      show_col_types = FALSE)
}

## Main Body -------------------------------------------------------------------
message(date(), ": Computing perturbation sensitivities for Mean_Corpuscular_Hemoglobin PRSs")
# FULL IDS (UNCOMMENT TO RUN FOR ALL PRSs) -------------
prs.ids <- c("PGS000099","PGS000174","PGS001219","PGS001989","PGS002206","PGS002339",
             "PGS002371","PGS002411","PGS002460","PGS002509","PGS002558","PGS002607",
             "PGS002656","PGS002705","PGS003560")
# PARTIAL IDS (SINCE SOME TAKE A WHILE TO RUN) ---------
# prs.ids <- c("PGS000099","PGS000174","PGS001219","PGS001989",
#              "PGS002206","PGS002411","PGS002460","PGS002509",
#              "PGS002558","PGS002607","PGS002656","PGS003560")
message(date(), ": No. PRSes = ", length(prs.ids))

test.ids <- which(autosome.metadata$TEST & autosome.metadata$EURO)
test.metadata <- autosome.metadata[test.ids,]; colnames(test.metadata)[1] <- 'sample_id'

# Left join to ensure ordering of phenotype matches ordering of genotypes
phenos.subset.df <- left_join(test.metadata,phenos.subset.df, by = 'sample_id')
leakage.ids <- which(phenos.subset.df$TEST & phenos.subset.df$TRAIN) 

# Create dataframes for saving
signflip.metrics.df <- data.frame(PRS_ID = character(),
                                  N_TARGET_VARS = numeric(),
                                  PEARSON_CORR = numeric(),
                                  SPEARMAN_RHO = numeric(),
                                  COSINE_SIM = numeric(),
                                  TOP10PCT_PREV = numeric(),
                                  TOP1PCT_PREV = numeric(),
                                  TOP10PCT_OR = numeric(),
                                  TOP1PCT_OR = numeric(),
                                  PERCENTILE_AVE_PREV_SLOPE = numeric(),
                                  PERCENTILE_AVE_PREV_SPEARMAN = numeric(),
                                  PERCENTILE_AVE_PHENO_SLOPE = numeric(),
                                  PERCENTILE_AVE_PHENO_SPEARMAN = numeric())
shuffle.metrics.df <- data.frame(PRS_ID = character(),
                                 N_TARGET_VARS = numeric(),
                                 PEARSON_CORR = numeric(),
                                 SPEARMAN_RHO = numeric(),
                                 COSINE_SIM = numeric(),
                                 TOP10PCT_PREV = numeric(),
                                 TOP1PCT_PREV = numeric(),
                                 TOP10PCT_OR = numeric(),
                                 TOP1PCT_OR = numeric(),
                                 PERCENTILE_AVE_PREV_SLOPE = numeric(),
                                 PERCENTILE_AVE_PREV_SPEARMAN = numeric(),
                                 PERCENTILE_AVE_PHENO_SLOPE = numeric(),
                                 PERCENTILE_AVE_PHENO_SPEARMAN = numeric())
usual.signflip.metrics.df <- data.frame(PRS_ID = character(),
                                        N_TARGET_VARS = numeric(),
                                        PEARSON_CORR = numeric(),
                                        SPEARMAN_RHO = numeric(),
                                        COSINE_SIM = numeric(),
                                        TOP10PCT_PREV = numeric(),
                                        TOP1PCT_PREV = numeric(),
                                        TOP10PCT_OR = numeric(),
                                        TOP1PCT_OR = numeric(),
                                        PERCENTILE_AVE_PREV_SLOPE = numeric(),
                                        PERCENTILE_AVE_PREV_SPEARMAN = numeric(),
                                        PERCENTILE_AVE_PHENO_SLOPE = numeric(),
                                        PERCENTILE_AVE_PHENO_SPEARMAN = numeric())
usual.shuffle.metrics.df <- data.frame(PRS_ID = character(),
                                       N_TARGET_VARS = numeric(),
                                       PEARSON_CORR = numeric(),
                                       SPEARMAN_RHO = numeric(),
                                       COSINE_SIM = numeric(),
                                       TOP10PCT_PREV = numeric(),
                                       TOP1PCT_PREV = numeric(),
                                       TOP10PCT_OR = numeric(),
                                       TOP1PCT_OR = numeric(),
                                       PERCENTILE_AVE_PREV_SLOPE = numeric(),
                                       PERCENTILE_AVE_PREV_SPEARMAN = numeric(),
                                       PERCENTILE_AVE_PHENO_SLOPE = numeric(),
                                       PERCENTILE_AVE_PHENO_SPEARMAN = numeric())

# Load phenotype values
message(date(), ": Loading phenotype values in test cohort...")
pheno.name <- paste0('Mean_corpuscular_haemoglobin.all_ethnicities.both.original.IRNT')
pheno.vals <- phenos.subset.df[,c('sample_id',pheno.name)]
pheno.vals <- pheno.vals[[pheno.name]]
message(date(), ": Replacing leaked samples with NaNs...") 
pheno.vals[leakage.ids] <- NA
message("No. NaNs in Mean_corpuscular_haemoglobin = ", (is.na(pheno.vals) %>% sum()) - 5153)
message("Completeness rate = ", 1-((is.na(pheno.vals) %>% sum()) - 5153)/(74084-5153))
binarized.pheno.vals <- (pheno.vals > median(na.omit(pheno.vals))) 

# Helper functions, depending on binarized.pheno.vals,
# for computing prevalence 
getPrevalence <- function(x) { # Top 10%
  cutoff <- as.numeric(quantile(na.omit(x), probs = 0.9))
  return(mean(na.omit(binarized.pheno.vals[which(x > cutoff)])))
} 
getPrevalenceC <- function(x) { # Top 10%
  cutoff <- as.numeric(quantile(na.omit(x), probs = 0.9))
  return(mean(na.omit(binarized.pheno.vals[which(x <= cutoff)])))
} 
getPrevalence2 <- function(x) { # Top 1%
  cutoff <- as.numeric(quantile(na.omit(x), probs = 0.99))
  return(mean(na.omit(binarized.pheno.vals[which(x > cutoff)])))
} 
getPrevalence2C <- function(x) { # Top 10%
  cutoff <- as.numeric(quantile(na.omit(x), probs = 0.99))
  return(mean(na.omit(binarized.pheno.vals[which(x <= cutoff)])))
} 

# for computing prevalence vector / average phenotype vector
getPrevVector <- function(x) {
  cutoffs <- quantile(na.omit(x), probs = seq(0,1,by=0.01))
  cutoffs[101] <- cutoffs[101]+1 # make sure top scoring individual is included
  to.return <- c()
  for (i in 0:99) {
    to.return <- c(to.return,
                   mean(na.omit(binarized.pheno.vals[which(x >= cutoffs[[paste0(i,'%')]] & 
                                                             x < cutoffs[[paste0(i+1,'%')]])])))
  }
  return(to.return)
}

getAvePhenoVector <- function(x) {
  cutoffs <- quantile(na.omit(x), probs = seq(0,1,by=0.01))
  cutoffs[101] <- cutoffs[101]+1 # make sure top scoring individual is included
  to.return <- c()
  for (i in 0:99) {
    to.return <- c(to.return,
                   mean(na.omit(pheno.vals[which(x >= cutoffs[[paste0(i,'%')]] & 
                                                   x < cutoffs[[paste0(i+1,'%')]])])))
  }
  return(to.return)
}

# Start collecting metrics here 
for (pheno in prs.ids) {
  # Print message
  message(date(), ": Working on ", pheno)
  
  # Load GWAS results 
  message("Loading GWAS results...")
  pheno.gwas <- data.table::fread(paste0(pheno.gwas.dir,
                                         pheno,
                                         "_matched_v2.txt"))
  
  # Subset to only those variants with valid beta value
  pheno.gwas <- pheno.gwas %>% subset(!is.na(beta))
  
  # Check no. variants to be perturbed
  n.perturb.vars <- pheno.gwas %>% 
    subset(gwas_p_value >= as.numeric(sig.cutoff)) %>% 
    nrow()
  
  # If fewer than 5, perform exact permutations and compute [6/1/23]
  message(date(), ": Calculating perturbation experiment metrics...")
  if (n.perturb.vars < 5) {
    message(pheno, " -- Detected k = ", n.perturb.vars, " (< 5) perturbed variants")
    message(pheno, " -- No. shuffled PRSs = ", factorial(n.perturb.vars)-1)
    message(pheno, " -- No. signflipped PRSs = ", 2^n.perturb.vars-1)
    
    # Initialize empty pheno-specific metrics (for visualization)
    pheno.spec.df <- data.frame(TYPE = c('original',rep('shuffle',factorial(n.perturb.vars)-1), rep('signflip',2^n.perturb.vars-1)),
                                PEARSON_CORR = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                SPEARMAN_RHO = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                COSINE_SIM = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                TOP10PCT_PREV = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                TOP1PCT_PREV = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                TOP10PCT_OR = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                TOP1PCT_OR = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                PERCENTILE_AVE_PREV_SLOPE = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                PERCENTILE_AVE_PREV_SPEARMAN = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                PERCENTILE_AVE_PHENO_SLOPE = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                PERCENTILE_AVE_PHENO_SPEARMAN = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1))
    usual.pheno.spec.df <- data.frame(TYPE = c('original',rep('shuffle',factorial(n.perturb.vars)-1), rep('signflip',2^n.perturb.vars-1)),
                                      PEARSON_CORR = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      SPEARMAN_RHO = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      COSINE_SIM = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      TOP10PCT_PREV = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      TOP1PCT_PREV = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      TOP10PCT_OR = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      TOP1PCT_OR = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      PERCENTILE_AVE_PREV_SLOPE = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      PERCENTILE_AVE_PREV_SPEARMAN = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      PERCENTILE_AVE_PHENO_SLOPE = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1),
                                      PERCENTILE_AVE_PHENO_SPEARMAN = rep(0, factorial(n.perturb.vars)+2^n.perturb.vars-1))
    
  } else {
    message(pheno, " -- Detected k = ", n.perturb.vars, " (>= 5) perturbed variants")
    message(pheno, " -- No. shuffled PRSs = 100")
    message(pheno, " -- No. signflipped PRSs = 100")
    
    # Initialize empty pheno-specific metrics (for visualization)
    pheno.spec.df <- data.frame(TYPE = c('original',rep('shuffle',100), rep('signflip',100)),
                                PEARSON_CORR = rep(0, 201),
                                SPEARMAN_RHO = rep(0, 201),
                                COSINE_SIM = rep(0, 201),
                                TOP10PCT_PREV = rep(0, 201),
                                TOP1PCT_PREV = rep(0, 201),
                                TOP10PCT_OR = rep(0, 201),
                                TOP1PCT_OR = rep(0, 201),
                                PERCENTILE_AVE_PREV_SLOPE = rep(0, 201),
                                PERCENTILE_AVE_PREV_SPEARMAN = rep(0, 201),
                                PERCENTILE_AVE_PHENO_SLOPE = rep(0, 201),
                                PERCENTILE_AVE_PHENO_SPEARMAN = rep(0, 201))
    usual.pheno.spec.df <- data.frame(TYPE = c('original',rep('shuffle',100), rep('signflip',100)),
                                      PEARSON_CORR = rep(0, 201),
                                      SPEARMAN_RHO = rep(0, 201),
                                      COSINE_SIM = rep(0, 201),
                                      TOP10PCT_PREV = rep(0, 201),
                                      TOP1PCT_PREV = rep(0, 201),
                                      TOP10PCT_OR = rep(0, 201),
                                      TOP1PCT_OR = rep(0, 201),
                                      PERCENTILE_AVE_PREV_SLOPE = rep(0, 201),
                                      PERCENTILE_AVE_PREV_SPEARMAN = rep(0, 201),
                                      PERCENTILE_AVE_PHENO_SLOPE = rep(0, 201),
                                      PERCENTILE_AVE_PHENO_SPEARMAN = rep(0, 201))
  }
  
  # Load all results 
  # - original, shuffle, sign flip, inversion
  perturbed.res <- readRDS(paste0(shuffled.prs.dir, 
                                  pheno,
                                  "_cutoff",
                                  sig.cutoff,
                                  "_test_pred_v2.rds"))
  
  # Compute metrics
  message(date(), ": Defining PRS-related vectors and matrices")
  shuffled.df <- perturbed.res$TEST_SHUFFLE_ONLY; shuffled.df[leakage.ids,] <- NA # shuffle
  signflip.df <- perturbed.res$TEST_SIGNFLIP_ONLY; signflip.df[leakage.ids,] <- NA # sign flip
  orig.test <- perturbed.res$ORIGINAL; orig.test[leakage.ids] <- NA # original PRS predictions (PRS_r + PRS_s)
  invert.test <- perturbed.res$INVERSION; invert.test[leakage.ids] <- NA # original PRS predictions (-PRS_r + PRS_s)
  
  if (cor(orig.test, pheno.vals, use = "pairwise.complete.obs") < 0) {
    message(date(), ": Cor(orig.test, pheno.vals) = ", 
            cor(orig.test, pheno.vals, 
                use = "pairwise.complete.obs"), ", which is NEGATIVE")
    message(date(), ": Flipping sign of PRS-related objects to ensure it and phenotype are in the same general direction")
    shuffled.df <- 0-shuffled.df # shuffle
    signflip.df <- 0-signflip.df # sign flip
    orig.test <- 0-orig.test # original PRS predictions (PRS_r + PRS_s)
    invert.test <- 0-invert.test # original PRS predictions (-PRS_r + PRS_s)
  }

  # Get PRS_s 
  PRS_s <- (orig.test + invert.test)/2
  
  # Compute original stats
  orig.v.pheno.spearman <- cor(orig.test, pheno.vals, method = 'spearman',
                               use = "pairwise.complete.obs") 
  orig.v.pheno.pearson <- cor(orig.test, pheno.vals, method = 'pearson',
                              use = "pairwise.complete.obs") 
  orig.v.pheno.cossim <- sum(orig.test*pheno.vals,na.rm=TRUE)/(norm(na.omit(pheno.vals),'2')*norm(na.omit(orig.test),'2'))
  orig.v.pheno.prev <- getPrevalence(orig.test)
  orig.v.pheno.prev2 <- getPrevalence2(orig.test)
  orig.v.pheno.prevC <- getPrevalenceC(orig.test)
  orig.v.pheno.prev2C <- getPrevalence2C(orig.test)
  orig.top10pct.or <- orig.v.pheno.prev * (1-orig.v.pheno.prevC) / 
    (orig.v.pheno.prevC * (1-orig.v.pheno.prev))
  orig.top1pct.or <- orig.v.pheno.prev2 * (1-orig.v.pheno.prev2C) / 
    (orig.v.pheno.prev2C * (1-orig.v.pheno.prev2))
  orig.v.pheno.aveprev.pearson <- cor(seq(0,0.99,by=0.01),getPrevVector(orig.test))
  orig.v.pheno.aveprev.spearman <- cor(seq(0,0.99,by=0.01),getPrevVector(orig.test),method='spearman')
  orig.v.pheno.avepheno.pearson <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(orig.test))
  orig.v.pheno.avepheno.spearman <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(orig.test),method='spearman')
  
  # Compute perturbed stats
  # SHUFFLE --------------------------------------------------------------------
  # Need to compute max(f(PRS^-,y),f(PRS^+,y))
  # Original code computes just f(PRS^+,y)
  # To get PRS^- from PRS^+ for each perturbation df
  # PRS^- = PRS_s - hat(PRS_r) = 2*PRS_s - (PRS_s + hat(PRS_r)) = 2*PRS_s - PRS^+
  shuffled.spearman.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(x,pheno.vals, method = 'spearman',use = "pairwise.complete.obs")
    minus <- cor(2*PRS_s-x,pheno.vals, method = 'spearman',use = "pairwise.complete.obs")
    return(max(plus,minus))
  })
  shuffled.pearson.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(x,pheno.vals, method = 'pearson',use = "pairwise.complete.obs")
    minus <- cor(2*PRS_s-x,pheno.vals, method = 'pearson',use = "pairwise.complete.obs")
    return(max(plus,minus))
  })
  shuffled.cosine.sim.vals <- apply(shuffled.df,2,function(x) {
    plus <- sum(x*pheno.vals,na.rm=TRUE)/((norm(na.omit(pheno.vals),'2')*norm(na.omit(x),'2')))
    minus <- sum((2*PRS_s-x)*pheno.vals,na.rm=TRUE)/((norm(na.omit(pheno.vals),'2')*norm(na.omit(2*PRS_s-x),'2')))
    return(max(plus,minus))
  })
  # -----
  usual.shuffled.spearman.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(x,pheno.vals, method = 'spearman',use = "pairwise.complete.obs")
    return(plus)
  })
  usual.shuffled.pearson.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(x,pheno.vals, method = 'pearson',use = "pairwise.complete.obs")
    return(plus)
  })
  usual.shuffled.cosine.sim.vals <- apply(shuffled.df,2,function(x) {
    plus <- sum(x*pheno.vals,na.rm=TRUE)/((norm(na.omit(pheno.vals),'2')*norm(na.omit(x),'2')))
    return(plus)
  })
  # -----
  shuffled.prev.vals.plus <- apply(shuffled.df,2,function(x) {
    getPrevalence(x)
  })
  shuffled.prev2.vals.plus <- apply(shuffled.df,2,function(x) {
    getPrevalence2(x)
  })
  shuffled.prevC.vals.plus <- apply(shuffled.df,2,function(x) {
    getPrevalenceC(x)
  })
  shuffled.prev2C.vals.plus <- apply(shuffled.df,2,function(x) {
    getPrevalence2C(x)
  })
  shuffled.prev.vals.minus <- apply(shuffled.df,2,function(x) {
    getPrevalence(2*PRS_s-x)
  })
  shuffled.prev2.vals.minus <- apply(shuffled.df,2,function(x) {
    getPrevalence2(2*PRS_s-x)
  })
  shuffled.prevC.vals.minus <- apply(shuffled.df,2,function(x) {
    getPrevalenceC(2*PRS_s-x)
  })
  shuffled.prev2C.vals.minus <- apply(shuffled.df,2,function(x) {
    getPrevalence2C(2*PRS_s-x)
  })
  shuffled.prev.vals <- pmax(shuffled.prev.vals.plus,
                             shuffled.prev.vals.minus)
  shuffled.prev2.vals <- pmax(shuffled.prev2.vals.plus,
                              shuffled.prev2.vals.minus)
  # -----
  shuffled.top10pct.or.vals <- pmax(
    shuffled.prev.vals.plus * (1-shuffled.prevC.vals.plus) / 
      (shuffled.prevC.vals.plus * (1-shuffled.prev.vals.plus)),
    shuffled.prev.vals.minus * (1-shuffled.prevC.vals.minus) / 
      (shuffled.prevC.vals.minus * (1-shuffled.prev.vals.minus))
  )
  shuffled.top1pct.or.vals <- pmax(
    shuffled.prev2.vals.plus * (1-shuffled.prev2C.vals.plus) / 
      (shuffled.prev2C.vals.plus * (1-shuffled.prev2.vals.plus)),
    shuffled.prev2.vals.minus * (1-shuffled.prev2C.vals.minus) / 
      (shuffled.prev2C.vals.minus * (1-shuffled.prev2.vals.minus))
  )
  shuffled.aveprev.pearson.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getPrevVector(x))
    minus <- cor(seq(0,0.99,by=0.01),getPrevVector(2*PRS_s-x))
    return(max(plus,minus))
  })
  shuffled.aveprev.spearman.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getPrevVector(x),method='spearman')
    minus <- cor(seq(0,0.99,by=0.01),getPrevVector(2*PRS_s-x),method='spearman')
    return(max(plus,minus))
  })
  shuffled.avepheno.pearson.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(x))
    minus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(2*PRS_s-x))
    return(max(plus,minus))
  })
  shuffled.avepheno.spearman.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(x),method='spearman')
    minus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(2*PRS_s-x),method='spearman')
    return(max(plus,minus))
  })
  # -----
  usual.shuffled.top10pct.or.vals <- (
    shuffled.prev.vals.plus * (1-shuffled.prevC.vals.plus) / 
      (shuffled.prevC.vals.plus * (1-shuffled.prev.vals.plus))
  )
  usual.shuffled.top1pct.or.vals <- (
    shuffled.prev2.vals.plus * (1-shuffled.prev2C.vals.plus) / 
      (shuffled.prev2C.vals.plus * (1-shuffled.prev2.vals.plus))
  )
  usual.shuffled.aveprev.pearson.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getPrevVector(x))
    return(plus)
  })
  usual.shuffled.aveprev.spearman.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getPrevVector(x),method='spearman')
    return(plus)
  })
  usual.shuffled.avepheno.pearson.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(x))
    return(plus)
  })
  usual.shuffled.avepheno.spearman.vals <- apply(shuffled.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(x),method='spearman')
    return(plus)
  })
  
  # SIGNFLIP -------------------------------------------------------------------
  signflip.spearman.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(x,pheno.vals, method = 'spearman',use = "pairwise.complete.obs")
    minus <- cor(2*PRS_s-x,pheno.vals, method = 'spearman',use = "pairwise.complete.obs")
    return(max(plus,minus))
  })
  signflip.pearson.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(x,pheno.vals, method = 'pearson',use = "pairwise.complete.obs")
    minus <- cor(2*PRS_s-x,pheno.vals, method = 'pearson',use = "pairwise.complete.obs")
    return(max(plus,minus))
  })
  signflip.cosine.sim.vals <- apply(signflip.df,2,function(x) {
    plus <- sum(x*pheno.vals,na.rm=TRUE)/((norm(na.omit(pheno.vals),'2')*norm(na.omit(x),'2')))
    minus <- sum((2*PRS_s-x)*pheno.vals,na.rm=TRUE)/((norm(na.omit(pheno.vals),'2')*norm(na.omit(2*PRS_s-x),'2')))
    return(max(plus,minus))
  })
  # -----
  usual.signflip.spearman.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(x,pheno.vals, method = 'spearman',use = "pairwise.complete.obs")
    return(plus)
  })
  usual.signflip.pearson.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(x,pheno.vals, method = 'pearson',use = "pairwise.complete.obs")
    return(plus)
  })
  usual.signflip.cosine.sim.vals <- apply(signflip.df,2,function(x) {
    plus <- sum(x*pheno.vals,na.rm=TRUE)/((norm(na.omit(pheno.vals),'2')*norm(na.omit(x),'2')))
    return(plus)
  })
  # -----
  signflip.prev.vals.plus <- apply(signflip.df,2,function(x) {
    getPrevalence(x)
  })
  signflip.prev2.vals.plus <- apply(signflip.df,2,function(x) {
    getPrevalence2(x)
  })
  signflip.prevC.vals.plus <- apply(signflip.df,2,function(x) {
    getPrevalenceC(x)
  })
  signflip.prev2C.vals.plus <- apply(signflip.df,2,function(x) {
    getPrevalence2C(x)
  })
  signflip.prev.vals.minus <- apply(signflip.df,2,function(x) {
    getPrevalence(2*PRS_s-x)
  })
  signflip.prev2.vals.minus <- apply(signflip.df,2,function(x) {
    getPrevalence2(2*PRS_s-x)
  })
  signflip.prevC.vals.minus <- apply(signflip.df,2,function(x) {
    getPrevalenceC(2*PRS_s-x)
  })
  signflip.prev2C.vals.minus <- apply(signflip.df,2,function(x) {
    getPrevalence2C(2*PRS_s-x)
  })
  signflip.prev.vals <- pmax(signflip.prev.vals.plus,
                             signflip.prev.vals.minus)
  signflip.prev2.vals <- pmax(signflip.prev2.vals.plus,
                              signflip.prev2.vals.minus)
  # -----
  signflip.top10pct.or.vals <- pmax(
    signflip.prev.vals.plus * (1-signflip.prevC.vals.plus) / 
      (signflip.prevC.vals.plus * (1-signflip.prev.vals.plus)),
    signflip.prev.vals.minus * (1-signflip.prevC.vals.minus) / 
      (signflip.prevC.vals.minus * (1-signflip.prev.vals.minus))
  )
  signflip.top1pct.or.vals <- pmax(
    signflip.prev2.vals.plus * (1-signflip.prev2C.vals.plus) / 
      (signflip.prev2C.vals.plus * (1-signflip.prev2.vals.plus)),
    signflip.prev2.vals.minus * (1-signflip.prev2C.vals.minus) / 
      (signflip.prev2C.vals.minus * (1-signflip.prev2.vals.minus))
  )
  signflip.aveprev.pearson.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getPrevVector(x))
    minus <- cor(seq(0,0.99,by=0.01),getPrevVector(2*PRS_s-x))
    return(max(plus,minus))
  })
  signflip.aveprev.spearman.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getPrevVector(x),method='spearman')
    minus <- cor(seq(0,0.99,by=0.01),getPrevVector(2*PRS_s-x),method='spearman')
    return(max(plus,minus))
  })
  signflip.avepheno.pearson.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(x))
    minus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(2*PRS_s-x))
    return(max(plus,minus))
  })
  signflip.avepheno.spearman.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(x),method='spearman')
    minus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(2*PRS_s-x),method='spearman')
    return(max(plus,minus))
  })
  # -----
  usual.signflip.top10pct.or.vals <- (
    signflip.prev.vals.plus * (1-signflip.prevC.vals.plus) / 
      (signflip.prevC.vals.plus * (1-signflip.prev.vals.plus))
  )
  usual.signflip.top1pct.or.vals <- (
    signflip.prev2.vals.plus * (1-signflip.prev2C.vals.plus) / 
      (signflip.prev2C.vals.plus * (1-signflip.prev2.vals.plus))
  )
  usual.signflip.aveprev.pearson.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getPrevVector(x))
    return(plus)
  })
  usual.signflip.aveprev.spearman.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getPrevVector(x),method='spearman')
    return(plus)
  })
  usual.signflip.avepheno.pearson.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(x))
    return(plus)
  })
  usual.signflip.avepheno.spearman.vals <- apply(signflip.df,2,function(x) {
    plus <- cor(seq(0,0.99,by=0.01),getAvePhenoVector(x),method='spearman')
    return(plus)
  })
  
  # Fill in the pheno-specific dataframe for plotting
  # -----
  pheno.spec.df$PEARSON_CORR <- c(orig.v.pheno.pearson, 
                                  shuffled.pearson.vals, 
                                  signflip.pearson.vals)
  pheno.spec.df$SPEARMAN_RHO <- c(orig.v.pheno.spearman, 
                                  shuffled.spearman.vals,
                                  signflip.spearman.vals)
  pheno.spec.df$COSINE_SIM <- c(orig.v.pheno.cossim, 
                                shuffled.cosine.sim.vals,
                                signflip.cosine.sim.vals)
  pheno.spec.df$TOP10PCT_PREV <- c(orig.v.pheno.prev,
                                   shuffled.prev.vals,
                                   signflip.prev.vals)
  pheno.spec.df$TOP1PCT_PREV <- c(orig.v.pheno.prev2,
                                  shuffled.prev2.vals,
                                  signflip.prev2.vals)
  pheno.spec.df$TOP10PCT_OR <- c(orig.top10pct.or,
                                 shuffled.top10pct.or.vals,
                                 signflip.top10pct.or.vals)
  pheno.spec.df$TOP1PCT_OR <- c(orig.top1pct.or,
                                shuffled.top1pct.or.vals,
                                signflip.top1pct.or.vals)
  pheno.spec.df$PERCENTILE_AVE_PREV_SLOPE <- c(orig.v.pheno.aveprev.pearson,
                                               shuffled.aveprev.pearson.vals,
                                               signflip.aveprev.pearson.vals)
  pheno.spec.df$PERCENTILE_AVE_PREV_SPEARMAN <- c(orig.v.pheno.aveprev.spearman,
                                                  shuffled.aveprev.spearman.vals,
                                                  signflip.aveprev.spearman.vals)
  pheno.spec.df$PERCENTILE_AVE_PHENO_SLOPE <- c(orig.v.pheno.avepheno.pearson,
                                                shuffled.avepheno.pearson.vals,
                                                signflip.avepheno.pearson.vals)
  pheno.spec.df$PERCENTILE_AVE_PHENO_SPEARMAN <- c(orig.v.pheno.avepheno.spearman,
                                                   shuffled.avepheno.spearman.vals,
                                                   signflip.avepheno.spearman.vals)
  # -----
  usual.pheno.spec.df$PEARSON_CORR <- c(orig.v.pheno.pearson, 
                                        usual.shuffled.pearson.vals, 
                                        usual.signflip.pearson.vals)
  usual.pheno.spec.df$SPEARMAN_RHO <- c(orig.v.pheno.spearman, 
                                        usual.shuffled.spearman.vals,
                                        usual.signflip.spearman.vals)
  usual.pheno.spec.df$COSINE_SIM <- c(orig.v.pheno.cossim, 
                                      usual.shuffled.cosine.sim.vals,
                                      usual.signflip.cosine.sim.vals)
  usual.pheno.spec.df$TOP10PCT_PREV <- c(orig.v.pheno.prev,
                                         shuffled.prev.vals.plus,
                                         signflip.prev.vals.plus)
  usual.pheno.spec.df$TOP1PCT_PREV <- c(orig.v.pheno.prev2,
                                        shuffled.prev2.vals.plus,
                                        signflip.prev2.vals.plus)
  usual.pheno.spec.df$TOP10PCT_OR <- c(orig.top10pct.or,
                                       usual.shuffled.top10pct.or.vals,
                                       usual.signflip.top10pct.or.vals)
  usual.pheno.spec.df$TOP1PCT_OR <- c(orig.top1pct.or,
                                      usual.shuffled.top1pct.or.vals,
                                      usual.signflip.top1pct.or.vals)
  usual.pheno.spec.df$PERCENTILE_AVE_PREV_SLOPE <- c(orig.v.pheno.aveprev.pearson,
                                                     usual.shuffled.aveprev.pearson.vals,
                                                     usual.signflip.aveprev.pearson.vals)
  usual.pheno.spec.df$PERCENTILE_AVE_PREV_SPEARMAN <- c(orig.v.pheno.aveprev.spearman,
                                                        usual.shuffled.aveprev.spearman.vals,
                                                        usual.signflip.aveprev.spearman.vals)
  usual.pheno.spec.df$PERCENTILE_AVE_PHENO_SLOPE <- c(orig.v.pheno.avepheno.pearson,
                                                      usual.shuffled.avepheno.pearson.vals,
                                                      usual.signflip.avepheno.pearson.vals)
  usual.pheno.spec.df$PERCENTILE_AVE_PHENO_SPEARMAN <- c(orig.v.pheno.avepheno.spearman,
                                                         usual.shuffled.avepheno.spearman.vals,
                                                         usual.signflip.avepheno.spearman.vals)
  # Saving metrics for individual phenotype
  message("Saving metrics for ", pheno)
  readr::write_csv(pheno.spec.df,
                   file = paste0(out.dir,
                                 pheno,
                                 '_cutoff',
                                 sig.cutoff,
                                 '_metrics_df.csv'))
  readr::write_csv(usual.pheno.spec.df,
                   file = paste0(out.dir,
                                 pheno,
                                 '_cutoff',
                                 sig.cutoff,
                                 '_usual_metrics_df.csv'))
  
  # (Note: these aren't p-values, but fractions of randomized PRS beaten by original!)
  #
  shuffled.spearman.corr.pval <- mean(orig.v.pheno.spearman > shuffled.spearman.vals)
  shuffled.pearson.corr.pval <- mean(orig.v.pheno.pearson > shuffled.pearson.vals)
  shuffled.cosine.sim.pval <- mean(orig.v.pheno.cossim > shuffled.cosine.sim.vals)
  shuffled.prev.pval <- mean(orig.v.pheno.prev > shuffled.prev.vals)
  shuffled.prev2.pval <- mean(orig.v.pheno.prev2 > shuffled.prev2.vals)
  shuffled.top10pct.or.pval <- mean(orig.top10pct.or > shuffled.top10pct.or.vals)
  shuffled.top1pct.or.pval <- mean(orig.top1pct.or > shuffled.top1pct.or.vals)
  shuffled.aveprev.pearson.pval <- mean(orig.v.pheno.aveprev.pearson > shuffled.aveprev.pearson.vals)
  shuffled.aveprev.spearman.pval <- mean(orig.v.pheno.aveprev.spearman > shuffled.aveprev.spearman.vals)
  shuffled.avepheno.pearson.pval <- mean(orig.v.pheno.avepheno.pearson > shuffled.avepheno.pearson.vals)
  shuffled.avepheno.spearman.pval <- mean(orig.v.pheno.avepheno.spearman > shuffled.avepheno.spearman.vals)
  
  #
  signflip.spearman.corr.pval <- mean(orig.v.pheno.spearman > signflip.spearman.vals)
  signflip.pearson.corr.pval <- mean(orig.v.pheno.pearson > signflip.pearson.vals)
  signflip.cosine.sim.pval <- mean(orig.v.pheno.cossim > signflip.cosine.sim.vals)
  signflip.prev.pval <- mean(orig.v.pheno.prev > signflip.prev.vals)
  signflip.prev2.pval <- mean(orig.v.pheno.prev2 > signflip.prev2.vals)
  signflip.top10pct.or.pval <- mean(orig.top10pct.or > signflip.top10pct.or.vals)
  signflip.top1pct.or.pval <- mean(orig.top1pct.or > signflip.top1pct.or.vals)
  signflip.aveprev.pearson.pval <- mean(orig.v.pheno.aveprev.pearson > signflip.aveprev.pearson.vals)
  signflip.aveprev.spearman.pval <- mean(orig.v.pheno.aveprev.spearman > signflip.aveprev.spearman.vals)
  signflip.avepheno.pearson.pval <- mean(orig.v.pheno.avepheno.pearson > signflip.avepheno.pearson.vals)
  signflip.avepheno.spearman.pval <- mean(orig.v.pheno.avepheno.spearman > signflip.avepheno.spearman.vals)
  
  # 
  usual.shuffled.spearman.corr.pval <- mean(orig.v.pheno.spearman > usual.shuffled.spearman.vals)
  usual.shuffled.pearson.corr.pval <- mean(orig.v.pheno.pearson > usual.shuffled.pearson.vals)
  usual.shuffled.cosine.sim.pval <- mean(orig.v.pheno.cossim > usual.shuffled.cosine.sim.vals)
  usual.shuffled.prev.pval <- mean(orig.v.pheno.prev > shuffled.prev.vals.plus)
  usual.shuffled.prev2.pval <- mean(orig.v.pheno.prev2 > shuffled.prev2.vals.plus)
  usual.shuffled.top10pct.or.pval <- mean(orig.top10pct.or > usual.shuffled.top10pct.or.vals)
  usual.shuffled.top1pct.or.pval <- mean(orig.top1pct.or > usual.shuffled.top1pct.or.vals)
  usual.shuffled.aveprev.pearson.pval <- mean(orig.v.pheno.aveprev.pearson > usual.shuffled.aveprev.pearson.vals)
  usual.shuffled.aveprev.spearman.pval <- mean(orig.v.pheno.aveprev.spearman > usual.shuffled.aveprev.spearman.vals)
  usual.shuffled.avepheno.pearson.pval <- mean(orig.v.pheno.avepheno.pearson > usual.shuffled.avepheno.pearson.vals)
  usual.shuffled.avepheno.spearman.pval <- mean(orig.v.pheno.avepheno.spearman > usual.shuffled.avepheno.spearman.vals)
  
  #
  usual.signflip.spearman.corr.pval <- mean(orig.v.pheno.spearman > usual.signflip.spearman.vals)
  usual.signflip.pearson.corr.pval <- mean(orig.v.pheno.pearson > usual.signflip.pearson.vals)
  usual.signflip.cosine.sim.pval <- mean(orig.v.pheno.cossim > usual.signflip.cosine.sim.vals)
  usual.signflip.prev.pval <- mean(orig.v.pheno.prev > signflip.prev.vals.plus)
  usual.signflip.prev2.pval <- mean(orig.v.pheno.prev2 > signflip.prev2.vals.plus)
  usual.signflip.top10pct.or.pval <- mean(orig.top10pct.or > usual.signflip.top10pct.or.vals)
  usual.signflip.top1pct.or.pval <- mean(orig.top1pct.or > usual.signflip.top1pct.or.vals)
  usual.signflip.aveprev.pearson.pval <- mean(orig.v.pheno.aveprev.pearson > usual.signflip.aveprev.pearson.vals)
  usual.signflip.aveprev.spearman.pval <- mean(orig.v.pheno.aveprev.spearman > usual.signflip.aveprev.spearman.vals)
  usual.signflip.avepheno.pearson.pval <- mean(orig.v.pheno.avepheno.pearson > usual.signflip.avepheno.pearson.vals)
  usual.signflip.avepheno.spearman.pval <- mean(orig.v.pheno.avepheno.spearman > usual.signflip.avepheno.spearman.vals)
  
  # Add to summary dataframes
  shuffle.metrics.df <- rbind(shuffle.metrics.df,
                              data.frame(PRS_ID = pheno,
                                         N_TARGET_VARS = n.perturb.vars,
                                         PEARSON_CORR = shuffled.pearson.corr.pval,
                                         SPEARMAN_RHO = shuffled.spearman.corr.pval,
                                         COSINE_SIM = shuffled.cosine.sim.pval,
                                         TOP10PCT_PREV = shuffled.prev.pval,
                                         TOP1PCT_PREV = shuffled.prev2.pval,
                                         TOP10PCT_OR = shuffled.top10pct.or.pval,
                                         TOP1PCT_OR = shuffled.top1pct.or.pval,
                                         PERCENTILE_AVE_PREV_SLOPE = shuffled.aveprev.pearson.pval,
                                         PERCENTILE_AVE_PREV_SPEARMAN = shuffled.aveprev.spearman.pval,
                                         PERCENTILE_AVE_PHENO_SLOPE = shuffled.avepheno.pearson.pval,
                                         PERCENTILE_AVE_PHENO_SPEARMAN = shuffled.avepheno.spearman.pval))
  signflip.metrics.df <- rbind(signflip.metrics.df,
                               data.frame(PRS_ID = pheno,
                                          N_TARGET_VARS = n.perturb.vars,
                                          PEARSON_CORR = signflip.pearson.corr.pval,
                                          SPEARMAN_RHO = signflip.spearman.corr.pval,
                                          COSINE_SIM = signflip.cosine.sim.pval,
                                          TOP10PCT_PREV = signflip.prev.pval,
                                          TOP1PCT_PREV = signflip.prev2.pval,
                                          TOP10PCT_OR = signflip.top10pct.or.pval,
                                          TOP1PCT_OR = signflip.top1pct.or.pval,
                                          PERCENTILE_AVE_PREV_SLOPE = signflip.aveprev.pearson.pval,
                                          PERCENTILE_AVE_PREV_SPEARMAN = signflip.aveprev.spearman.pval,
                                          PERCENTILE_AVE_PHENO_SLOPE = signflip.avepheno.pearson.pval,
                                          PERCENTILE_AVE_PHENO_SPEARMAN = signflip.avepheno.spearman.pval))
  usual.shuffle.metrics.df <- rbind(usual.shuffle.metrics.df,
                                    data.frame(PRS_ID = pheno,
                                               N_TARGET_VARS = n.perturb.vars,
                                               PEARSON_CORR = usual.shuffled.pearson.corr.pval,
                                               SPEARMAN_RHO = usual.shuffled.spearman.corr.pval,
                                               COSINE_SIM = usual.shuffled.cosine.sim.pval,
                                               TOP10PCT_PREV = usual.shuffled.prev.pval,
                                               TOP1PCT_PREV = usual.shuffled.prev2.pval,
                                               TOP10PCT_OR = usual.shuffled.top10pct.or.pval,
                                               TOP1PCT_OR = usual.shuffled.top1pct.or.pval,
                                               PERCENTILE_AVE_PREV_SLOPE = usual.shuffled.aveprev.pearson.pval,
                                               PERCENTILE_AVE_PREV_SPEARMAN = usual.shuffled.aveprev.spearman.pval,
                                               PERCENTILE_AVE_PHENO_SLOPE = usual.shuffled.avepheno.pearson.pval,
                                               PERCENTILE_AVE_PHENO_SPEARMAN = usual.shuffled.avepheno.spearman.pval))
  usual.signflip.metrics.df <- rbind(usual.signflip.metrics.df,
                                     data.frame(PRS_ID = pheno,
                                                N_TARGET_VARS = n.perturb.vars,
                                                PEARSON_CORR = usual.signflip.pearson.corr.pval,
                                                SPEARMAN_RHO = usual.signflip.spearman.corr.pval,
                                                COSINE_SIM = usual.signflip.cosine.sim.pval,
                                                TOP10PCT_PREV = usual.signflip.prev.pval,
                                                TOP1PCT_PREV = usual.signflip.prev2.pval,
                                                TOP10PCT_OR = usual.signflip.top10pct.or.pval,
                                                TOP1PCT_OR = usual.signflip.top1pct.or.pval,
                                                PERCENTILE_AVE_PREV_SLOPE = usual.signflip.aveprev.pearson.pval,
                                                PERCENTILE_AVE_PREV_SPEARMAN = usual.signflip.aveprev.spearman.pval,
                                                PERCENTILE_AVE_PHENO_SLOPE = usual.signflip.avepheno.pearson.pval,
                                                PERCENTILE_AVE_PHENO_SPEARMAN = usual.signflip.avepheno.spearman.pval))
}

# Save files
message("Save results across all PRSs")
readr::write_csv(shuffle.metrics.df,
                 file = paste0(out.dir,
                               'combined_cutoff',
                               sig.cutoff,'_shuffle_metrics_df.csv'))
readr::write_csv(signflip.metrics.df,
                 file = paste0(out.dir,
                               'combined_cutoff',
                               sig.cutoff,'_signflip_metrics_df.csv'))
readr::write_csv(usual.shuffle.metrics.df,
                 file = paste0(out.dir,
                               'combined_cutoff',
                               sig.cutoff,'_shuffle_usual_metrics_df.csv'))
readr::write_csv(usual.signflip.metrics.df,
                 file = paste0(out.dir,
                               'combined_cutoff',
                               sig.cutoff,'_signflip_usual_metrics_df.csv'))

sink()

####################################################
########### Mean Corpuscular Hemoglobin ############
############ Perturbation Experiment ###############
########### Range of Target SNP cutoffs 1e-7 #######
############ Shuffle and Sign flips  ###############
####################################################
# This version combines sensitivity metrics and distribution metrics
# to detect significant relationships

#################
## Directories ##
#################
# Create output file 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/MCH_get_strat_vs_perturb_sensitivity_1e-7_Spearman_rhos_062823.log')
sink(stdout(), type = "message")

library(data.table)
library(dplyr)
library(bigsnpr)

R.workbench <- FALSE
sig.cutoff <- '1e-7'
message('sig.cutoff = ', sig.cutoff)

if (R.workbench) {
  c_and_t.prs.dir <- '/deep_learning/aaw/051723/results/prs_dist_vs_perturbation_sensitivity/raw_tables/'
  perturb.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/Jeremy_test/'
  prs.dist.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/tables/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/strat_vs_perturb_sensitivity/'
} else {
  c_and_t.prs.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/prs_dist_vs_perturbation_sensitivity/raw_tables/'
  perturb.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/Jeremy_test/'
  prs.dist.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/tables/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/strat_vs_perturb_sensitivity/'
}

### Analysis of MCH PRS --------------------------------------------------------
## FULL LIST
prs.ids <- c("PGS000099","PGS000174","PGS001219","PGS001989","PGS002206","PGS002339",
             "PGS002371","PGS002411","PGS002460","PGS002509","PGS002558","PGS002607",
             "PGS002656","PGS002705","PGS003560")

## PARTIAL LIST
# prs.ids <- c("PGS000099","PGS000174","PGS001219","PGS001989",
#              "PGS002206","PGS002411","PGS002460","PGS002509",
#              "PGS002558","PGS002607","PGS002656","PGS003560")
message(date(), ": No. PRSes = ", length(prs.ids))

# Read distribution file
prs_dist <- readr::read_csv(paste0(prs.dist.dir,
                                   'prs_dist_summaries_cutoff',
                                   sig.cutoff,
                                   '.csv'),
                            show_col_types = FALSE) %>% 
  as.data.frame()
colnames(prs_dist)[1] <- 'PRS_ID'

# Read perturbation sensitivity files
prs_shuffle_max <- readr::read_csv(paste0(perturb.dir,'combined_cutoff',
                                          sig.cutoff,'_shuffle_metrics_df.csv'),
                                   show_col_types = FALSE) %>% 
  as.data.frame()
prs_signflip_max <- readr::read_csv(paste0(perturb.dir,'combined_cutoff',
                                           sig.cutoff,'_signflip_metrics_df.csv'),
                                    show_col_types = FALSE) %>% 
  as.data.frame()
prs_shuffle_usual <- readr::read_csv(paste0(perturb.dir,'combined_cutoff',
                                            sig.cutoff,'_shuffle_usual_metrics_df.csv'),
                                     show_col_types = FALSE) %>% 
  as.data.frame()
prs_signflip_usual <- readr::read_csv(paste0(perturb.dir,'combined_cutoff',
                                             sig.cutoff,'_signflip_usual_metrics_df.csv'),
                                      show_col_types = FALSE) %>% 
  as.data.frame()

if (sig.cutoff=='1e-10') {
  c_and_t_shuffle_max <- readr::read_csv(paste0(c_and_t.prs.dir, 
                                                'gwas1e-8_cutoff1e-10_shuffle_max_combined.csv'),
                                         show_col_types = FALSE) %>%
    subset(PHENO=='Mean_corpuscular_haemoglobin')
  c_and_t_signflip_max <- readr::read_csv(paste0(c_and_t.prs.dir, 
                                                'gwas1e-8_cutoff1e-10_signflip_max_combined.csv'),
                                         show_col_types = FALSE) %>%
    subset(PHENO=='Mean_corpuscular_haemoglobin')
  c_and_t_shuffle_usual <- readr::read_csv(paste0(c_and_t.prs.dir, 
                                                'gwas1e-8_cutoff1e-10_shuffle_usual_combined.csv'),
                                         show_col_types = FALSE) %>%
    subset(PHENO=='Mean_corpuscular_haemoglobin')
  c_and_t_signflip_usual <- readr::read_csv(paste0(c_and_t.prs.dir, 
                                                 'gwas1e-8_cutoff1e-10_signflip_usual_combined.csv'),
                                          show_col_types = FALSE) %>%
    subset(PHENO=='Mean_corpuscular_haemoglobin')
} else {
  c_and_t_shuffle_max <- readr::read_csv(paste0(c_and_t.prs.dir, 
                                                'gwas1e-5_cutoff',
                                                sig.cutoff,'_shuffle_max_combined.csv'),
                                         show_col_types = FALSE) %>%
    subset(PHENO=='Mean_corpuscular_haemoglobin')
  c_and_t_signflip_max <- readr::read_csv(paste0(c_and_t.prs.dir, 
                                                 'gwas1e-5_cutoff',
                                                 sig.cutoff,'_signflip_max_combined.csv'),
                                          show_col_types = FALSE) %>%
    subset(PHENO=='Mean_corpuscular_haemoglobin')
  c_and_t_shuffle_usual <- readr::read_csv(paste0(c_and_t.prs.dir, 
                                                  'gwas1e-5_cutoff',
                                                  sig.cutoff,'_shuffle_usual_combined.csv'),
                                           show_col_types = FALSE) %>%
    subset(PHENO=='Mean_corpuscular_haemoglobin')
  c_and_t_signflip_usual <- readr::read_csv(paste0(c_and_t.prs.dir, 
                                                   'gwas1e-5_cutoff',
                                                   sig.cutoff,'_signflip_usual_combined.csv'),
                                            show_col_types = FALSE) %>%
    subset(PHENO=='Mean_corpuscular_haemoglobin')
}
colnames(c_and_t_shuffle_max)[1] <- 'PRS_ID'; c_and_t_shuffle_max[['PRS_ID']] <- 'C_AND_T'
colnames(c_and_t_signflip_max)[1] <- 'PRS_ID'; c_and_t_signflip_max[['PRS_ID']] <- 'C_AND_T'
colnames(c_and_t_shuffle_usual)[1] <- 'PRS_ID'; c_and_t_shuffle_usual[['PRS_ID']] <- 'C_AND_T'
colnames(c_and_t_signflip_usual)[1] <- 'PRS_ID'; c_and_t_signflip_usual[['PRS_ID']] <- 'C_AND_T'

# Merge 
shuffle_max_prs_dist <- merge(prs_shuffle_max,prs_dist,by='PRS_ID')
signflip_max_prs_dist <- merge(prs_signflip_max,prs_dist,by='PRS_ID')
shuffle_usual_prs_dist <- merge(prs_shuffle_usual,prs_dist,by='PRS_ID')
signflip_usual_prs_dist <- merge(prs_signflip_usual,prs_dist,by='PRS_ID')

shuffle_max_prs_dist$N_TARGET_VARS <- NULL
signflip_max_prs_dist$N_TARGET_VARS <- NULL
shuffle_usual_prs_dist$N_TARGET_VARS <- NULL
signflip_usual_prs_dist$N_TARGET_VARS <- NULL

# Add lenient/strict C&T PRS 
shuffle_max_prs_dist <-rbind(shuffle_max_prs_dist, c_and_t_shuffle_max)
signflip_max_prs_dist <-rbind(signflip_max_prs_dist, c_and_t_signflip_max)
shuffle_usual_prs_dist <-rbind(shuffle_usual_prs_dist, c_and_t_shuffle_usual)
signflip_usual_prs_dist <-rbind(signflip_usual_prs_dist, c_and_t_signflip_usual)

# Save
readr::write_csv(shuffle_max_prs_dist,
                 file = paste0(out.dir,"/raw_tables/cutoff",
                               sig.cutoff,"_shuffle_max_combined.csv"))
readr::write_csv(signflip_max_prs_dist,
                 file = paste0(out.dir,"/raw_tables/cutoff",
                               sig.cutoff,"_signflip_max_combined.csv"))
readr::write_csv(shuffle_usual_prs_dist,
                 file = paste0(out.dir,"/raw_tables/cutoff",
                               sig.cutoff,"_shuffle_usual_combined.csv"))
readr::write_csv(signflip_usual_prs_dist,
                 file = paste0(out.dir,"/raw_tables/cutoff",
                               sig.cutoff,"_signflip_usual_combined.csv"))

# Analyze trends - compute p-values and correlations
shuffle_max_vs_strat_corr_array <- matrix(NA,nrow=ncol(prs_shuffle_max)-2,ncol=ncol(prs_dist)-1)
signflip_max_vs_strat_corr_array <- matrix(NA,nrow=ncol(prs_signflip_max)-2,ncol=ncol(prs_dist)-1)
shuffle_usual_vs_strat_corr_array <- matrix(NA,nrow=ncol(prs_shuffle_usual)-2,ncol=ncol(prs_dist)-1)
signflip_usual_vs_strat_corr_array <- matrix(NA,nrow=ncol(prs_signflip_usual)-2,ncol=ncol(prs_dist)-1)

shuffle_max_vs_strat_pvals_array <- matrix(NA,nrow=ncol(prs_shuffle_max)-2,ncol=ncol(prs_dist)-1)
signflip_max_vs_strat_pvals_array <- matrix(NA,nrow=ncol(prs_signflip_max)-2,ncol=ncol(prs_dist)-1)
shuffle_usual_vs_strat_pvals_array <- matrix(NA,nrow=ncol(prs_shuffle_usual)-2,ncol=ncol(prs_dist)-1)
signflip_usual_vs_strat_pvals_array <- matrix(NA,nrow=ncol(prs_signflip_usual)-2,ncol=ncol(prs_dist)-1)

colnames(shuffle_max_vs_strat_corr_array) <- colnames(prs_dist)[-1]
rownames(shuffle_max_vs_strat_corr_array) <- colnames(prs_shuffle_max)[-c(1,2)]
colnames(signflip_max_vs_strat_corr_array) <- colnames(prs_dist)[-1]
rownames(signflip_max_vs_strat_corr_array) <- colnames(prs_signflip_max)[-c(1,2)]
colnames(shuffle_usual_vs_strat_corr_array) <- colnames(prs_dist)[-1]
rownames(shuffle_usual_vs_strat_corr_array) <- colnames(prs_shuffle_usual)[-c(1,2)]
colnames(signflip_usual_vs_strat_corr_array) <- colnames(prs_dist)[-1]
rownames(signflip_usual_vs_strat_corr_array) <- colnames(prs_signflip_usual)[-c(1,2)]

colnames(shuffle_max_vs_strat_pvals_array) <- colnames(prs_dist)[-1]
rownames(shuffle_max_vs_strat_pvals_array) <- colnames(prs_shuffle_max)[-c(1,2)]
colnames(signflip_max_vs_strat_pvals_array) <- colnames(prs_dist)[-1]
rownames(signflip_max_vs_strat_pvals_array) <- colnames(prs_signflip_max)[-c(1,2)]
colnames(shuffle_usual_vs_strat_pvals_array) <- colnames(prs_dist)[-1]
rownames(shuffle_usual_vs_strat_pvals_array) <- colnames(prs_shuffle_usual)[-c(1,2)]
colnames(signflip_usual_vs_strat_pvals_array) <- colnames(prs_dist)[-1]
rownames(signflip_usual_vs_strat_pvals_array) <- colnames(prs_signflip_usual)[-c(1,2)]

n.tests <- nrow(shuffle_max_vs_strat_corr_array)*ncol(shuffle_max_vs_strat_corr_array)
message(date(), ": No. tests performed = ", n.tests)
fwer.thres.cutoff <- 0.05/n.tests
message(date(), ": FWER corrected p-value threshold = ", fwer.thres.cutoff)
for (i in 1:nrow(shuffle_max_vs_strat_corr_array)) {
  for (j in 1:ncol(shuffle_max_vs_strat_corr_array)) {
    # Shuffle, max
    shuffle_max_vs_strat_corr_array[i,j] <- cor(shuffle_max_prs_dist[[rownames(shuffle_max_vs_strat_corr_array)[i]]],
                                                shuffle_max_prs_dist[[colnames(shuffle_max_vs_strat_corr_array)[j]]],
                                                method = 'spearman')
    p_val <- cor.test(shuffle_max_prs_dist[[rownames(shuffle_max_vs_strat_corr_array)[i]]],
                      shuffle_max_prs_dist[[colnames(shuffle_max_vs_strat_corr_array)[j]]],
                      method='spearman')$p.value
    shuffle_max_vs_strat_pvals_array[i,j] <- p_val
    if (is.na(p_val)) {
      message('(SHUFFLE, MAX) Constant value observed for ', rownames(shuffle_max_vs_strat_corr_array)[i])
      message('(SHUFFLE, MAX) Value = ', mean(shuffle_max_prs_dist[[rownames(shuffle_max_vs_strat_corr_array)[i]]]))
    } else if (p_val < fwer.thres.cutoff) {
      message('(SHUFFLE, MAX): Significant correlation (p = ',p_val,') between ', 
              rownames(shuffle_max_vs_strat_corr_array)[i], ' and ', 
              colnames(shuffle_max_vs_strat_corr_array)[j])
      message('(SHUFFLE, MAX): Spearman rho = ', shuffle_max_vs_strat_corr_array[i,j])
    }
    
    # Signflip, max
    signflip_max_vs_strat_corr_array[i,j] <- cor(signflip_max_prs_dist[[rownames(signflip_max_vs_strat_corr_array)[i]]],
                                                 signflip_max_prs_dist[[colnames(signflip_max_vs_strat_corr_array)[j]]],
                                                 method = 'spearman')
    p_val <- cor.test(signflip_max_prs_dist[[rownames(signflip_max_vs_strat_corr_array)[i]]],
                      signflip_max_prs_dist[[colnames(signflip_max_vs_strat_corr_array)[j]]],
                      method = 'spearman')$p.value
    signflip_max_vs_strat_pvals_array[i,j] <- p_val
    if (is.na(p_val)) {
      message('(SIGNFLIP, MAX) Constant value observed for ', rownames(signflip_max_vs_strat_corr_array)[i])
      message('(SIGNFLIP, MAX) Value = ', mean(signflip_max_prs_dist[[rownames(signflip_max_vs_strat_corr_array)[i]]]))
    } else if (p_val < fwer.thres.cutoff) {
      message('(SIGNFLIP, MAX): Significant correlation (p = ',p_val,') between ', 
              rownames(signflip_max_vs_strat_corr_array)[i], ' and ', 
              colnames(signflip_max_vs_strat_corr_array)[j])
      message('(SIGNFLIP, MAX): Spearman rho = ', signflip_max_vs_strat_corr_array[i,j])
    }
    
    # Shuffle, usual
    shuffle_usual_vs_strat_corr_array[i,j] <- cor(shuffle_usual_prs_dist[[rownames(shuffle_usual_vs_strat_corr_array)[i]]],
                                                  shuffle_usual_prs_dist[[colnames(shuffle_usual_vs_strat_corr_array)[j]]],
                                                  method = 'spearman')
    p_val <- cor.test(shuffle_usual_prs_dist[[rownames(shuffle_usual_vs_strat_corr_array)[i]]],
                      shuffle_usual_prs_dist[[colnames(shuffle_usual_vs_strat_corr_array)[j]]],
                      method = 'spearman')$p.value
    shuffle_usual_vs_strat_pvals_array[i,j] <- p_val
    if (is.na(p_val)) {
      message('(SHUFFLE, USUAL) Constant value observed for ', rownames(shuffle_usual_vs_strat_corr_array)[i])
      message('(SHUFFLE, USUAL) Value = ', mean(shuffle_usual_prs_dist[[rownames(shuffle_usual_vs_strat_corr_array)[i]]]))
    } else if (p_val < fwer.thres.cutoff) {
      message('(SHUFFLE, USUAL): Significant correlation (p = ',p_val,') between ', 
              rownames(shuffle_usual_vs_strat_corr_array)[i], ' and ', 
              colnames(shuffle_usual_vs_strat_corr_array)[j])
      message('(SHUFFLE, USUAL): Spearman rho = ', shuffle_usual_vs_strat_corr_array[i,j])
    }
    
    # Signflip, usual
    signflip_usual_vs_strat_corr_array[i,j] <- cor(signflip_usual_prs_dist[[rownames(signflip_usual_vs_strat_corr_array)[i]]],
                                                   signflip_usual_prs_dist[[colnames(signflip_usual_vs_strat_corr_array)[j]]],
                                                   method = 'spearman')
    p_val <- cor.test(signflip_usual_prs_dist[[rownames(signflip_usual_vs_strat_corr_array)[i]]],
                      signflip_usual_prs_dist[[colnames(signflip_usual_vs_strat_corr_array)[j]]],
                      method = 'spearman')$p.value
    signflip_usual_vs_strat_pvals_array[i,j] <- p_val
    if (is.na(p_val)) {
      message('(SIGNFLIP, USUAL) Constant value observed for ', rownames(signflip_usual_vs_strat_corr_array)[i])
      message('(SIGNFLIP, USUAL) Value = ', mean(signflip_usual_prs_dist[[rownames(signflip_usual_vs_strat_corr_array)[i]]]))
    } else if (p_val < fwer.thres.cutoff) {
      message('(SIGNFLIP, USUAL): Significant correlation (p = ',p_val,') between ', 
              rownames(signflip_usual_vs_strat_corr_array)[i], ' and ', 
              colnames(signflip_usual_vs_strat_corr_array)[j])
      message('(SIGNFLIP, USUAL): Spearman rho = ', signflip_usual_vs_strat_corr_array[i,j])
    }
  }
}

# Convert to dataframe and include sensitivity metrics as a new feature column
shuffle_max_vs_strat_corr_array <- as.data.frame(shuffle_max_vs_strat_corr_array)
shuffle_max_vs_strat_corr_array$SENSITIVITY_METRIC <- rownames(shuffle_max_vs_strat_corr_array)
shuffle_max_vs_strat_pvals_array <- as.data.frame(shuffle_max_vs_strat_pvals_array)
shuffle_max_vs_strat_pvals_array$SENSITIVITY_METRIC <- rownames(shuffle_max_vs_strat_pvals_array)

signflip_max_vs_strat_corr_array <- as.data.frame(signflip_max_vs_strat_corr_array)
signflip_max_vs_strat_corr_array$SENSITIVITY_METRIC <- rownames(signflip_max_vs_strat_corr_array)
signflip_max_vs_strat_pvals_array <- as.data.frame(signflip_max_vs_strat_pvals_array)
signflip_max_vs_strat_pvals_array$SENSITIVITY_METRIC <- rownames(signflip_max_vs_strat_pvals_array)

shuffle_usual_vs_strat_corr_array <- as.data.frame(shuffle_usual_vs_strat_corr_array)
shuffle_usual_vs_strat_corr_array$SENSITIVITY_METRIC <- rownames(shuffle_usual_vs_strat_corr_array)
shuffle_usual_vs_strat_pvals_array <- as.data.frame(shuffle_usual_vs_strat_pvals_array)
shuffle_usual_vs_strat_pvals_array$SENSITIVITY_METRIC <- rownames(shuffle_usual_vs_strat_pvals_array)

signflip_usual_vs_strat_corr_array <- as.data.frame(signflip_usual_vs_strat_corr_array)
signflip_usual_vs_strat_corr_array$SENSITIVITY_METRIC <- rownames(signflip_usual_vs_strat_corr_array)
signflip_usual_vs_strat_pvals_array <- as.data.frame(signflip_usual_vs_strat_pvals_array)
signflip_usual_vs_strat_pvals_array$SENSITIVITY_METRIC <- rownames(signflip_usual_vs_strat_pvals_array)

# Save files
readr::write_csv(shuffle_max_vs_strat_corr_array,
                 file = paste0(out.dir,"corr_cutoff",
                               sig.cutoff,"_shuffle_max_vs_prs_dist.csv"))
readr::write_csv(shuffle_max_vs_strat_pvals_array,
                 file = paste0(out.dir,"pvals_cutoff",
                               sig.cutoff,"_shuffle_max_vs_prs_dist.csv"))

readr::write_csv(signflip_max_vs_strat_corr_array,
                 file = paste0(out.dir,"corr_cutoff",
                               sig.cutoff,"_signflip_max_vs_prs_dist.csv"))
readr::write_csv(signflip_max_vs_strat_pvals_array,
                 file = paste0(out.dir,"pvals_cutoff",
                               sig.cutoff,"_signflip_max_vs_prs_dist.csv"))

readr::write_csv(shuffle_usual_vs_strat_corr_array,
                 file = paste0(out.dir,"corr_cutoff",
                               sig.cutoff,"_shuffle_usual_vs_prs_dist.csv"))
readr::write_csv(shuffle_usual_vs_strat_pvals_array,
                 file = paste0(out.dir,"pvals_cutoff",
                               sig.cutoff,"_shuffle_usual_vs_prs_dist.csv"))

readr::write_csv(signflip_usual_vs_strat_corr_array,
                 file = paste0(out.dir,"corr_cutoff",
                               sig.cutoff,"_signflip_usual_vs_prs_dist.csv"))
readr::write_csv(signflip_usual_vs_strat_pvals_array,
                 file = paste0(out.dir,"pvals_cutoff",
                               sig.cutoff,"_signflip_usual_vs_prs_dist.csv"))
sink()
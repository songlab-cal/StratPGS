## Check no. perturbable variants available in each PRS ------------------------
sink('/illumina/scratch/deep_learning/aaw/051723/logs/get_mean_corpuscular_hemoglobin_perturb_variant_counts.log')
sink(stdout(), type = "message")
library(dplyr)
library(RSQLite)
library(DBI)

## Define directories ----------------------------------------------------------
R.workbench <- TRUE
if (R.workbench) {
  genos.dir <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  gwas.dir <- '/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/'
  corpuscular.hemoglobin.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_pvals/'
  gwas_matched_prs.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
} else {
  genos.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  gwas.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/'
  corpuscular.hemoglobin.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_pvals/'
  gwas_matched_prs.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
}

pheno <- 'Mean_Corpuscular_Hemoglobin'
prs.files <- system(paste0('ls ', corpuscular.hemoglobin.dir, '*.txt'), intern=T)
message(date(), ": ", length(prs.files), " PRSes detected.")
prs.ids <- sapply(prs.files, function(x) {strsplit(strsplit(x, "/")[[1]][6], "\\.")[[1]][1]}) # 8 if R.workbench is FALSE, else 6
names(prs.ids) <- NULL

perturb_counts_df <- data.frame(PRS=character(),
                                N_VARS=numeric(),
                                N_NA_BETAS=numeric(),
                                N_PVAL_ATLEAST_1e5=numeric(),
                                N_PVAL_ATLEAST_1e6=numeric(),
                                N_PVAL_ATLEAST_1e7=numeric(),
                                N_PVAL_ATLEAST_1e8=numeric(),
                                N_PVAL_ATLEAST_1e10=numeric())
for (i in 1:length(prs.files)) {
  message(date(), ": Working on ", prs.ids[i])
  # prs.file <- data.table::fread(file=paste0(gwas_matched_prs.dir,
  #                                            prs.ids[i],
  #                                            "_matched.txt")) %>%
  #   as.data.frame()
  prs.file <- data.table::fread(file=paste0(gwas_matched_prs.dir,
                                            "v2_files/",
                                            prs.ids[i],
                                            "_matched_v2.txt")) %>%
    as.data.frame()
  print(nrow(prs.file))
  
  perturb_counts_df <- rbind(perturb_counts_df,
                             data.frame(PRS=prs.ids[i],
                                        N_VARS=nrow(prs.file),
                                        N_NA_BETAS=nrow(prs.file %>% 
                                                          subset(is.na(beta))),
                                        N_PVAL_ATLEAST_1e5=nrow(prs.file %>% 
                                                                  subset(gwas_p_value >= 1e-5 & !is.na(beta))),
                                        N_PVAL_ATLEAST_1e6=nrow(prs.file %>% 
                                                                  subset(gwas_p_value >= 1e-6 & !is.na(beta))),
                                        N_PVAL_ATLEAST_1e7=nrow(prs.file %>% 
                                                                  subset(gwas_p_value >= 1e-7 & !is.na(beta))),
                                        N_PVAL_ATLEAST_1e8=nrow(prs.file %>% 
                                                                  subset(gwas_p_value >= 1e-8 & !is.na(beta))),
                                        N_PVAL_ATLEAST_1e10=nrow(prs.file %>% 
                                                                   subset(gwas_p_value >= 1e-10 & !is.na(beta)))))
  
}

readr::write_csv(perturb_counts_df,
                 file = '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/tables/non-NaN_perturb_var_counts_v2_new.csv')

kableExtra::kable(perturb_counts_df)
sink()

for (i in 1:nrow(perturb_counts_df)) {
  print(paste0("For ", perturb_counts_df$PRS[i],
               " the fraction of matched variants = ", round(100*(1 - perturb_counts_df$N_NA_BETAS[i]/perturb_counts_df$N_VARS[i]),1), "%"))
}

perturb_counts_df %>%
  mutate(N_MATCHING=perturb_counts_df$N_VARS-perturb_counts_df$N_NA_BETAS) %>%
  select(c('PRS','N_MATCHING','FRACTION_MATCHED',
           'N_PVAL_ATLEAST_1e6','N_PVAL_ATLEAST_1e7',
           'N_PVAL_ATLEAST_1e8','N_PVAL_ATLEAST_1e10')) %>%
  kableExtra::kable()

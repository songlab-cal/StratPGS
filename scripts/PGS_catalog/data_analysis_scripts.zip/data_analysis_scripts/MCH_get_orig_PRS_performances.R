####################################################
########### Mean Corpuscular Hemoglobin ############
############### Shuffling Experiment ###############
######### Range of Target SNP cutoffs 1e-10 ########
############# Shuffle and Sign flips  ##############
####################################################
# This version computes performance of original PRS
# across all 11 metrics

#################
## Directories ##
#################
library(data.table)
library(dplyr)
library(bigsnpr)

R.workbench <- TRUE
sig.cutoff <- '1e-10'
message('sig.cutoff = ', sig.cutoff)

if (R.workbench) {
  prs.dist.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/tables/'
  c_and_t.prs.dir <- '/deep_learning/aaw/051723/results/prs_perturbation_sensitivity/phenotypes/'
  c_and_t.dist.dir <- '/deep_learning/aaw/051723/results/prs_dist_summaries/'
  shuffled.prs.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  pheno.gwas.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/'
} else {
  prs.dist.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/tables/'
  c_and_t.prs.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/prs_perturbation_sensitivity/phenotypes/'
  c_and_t.dist.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/prs_dist_summaries/'
  shuffled.prs.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  pheno.gwas.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/'
}

## Main Body -------------------------------------------------------------------
message(date(), ": Computing original performances of Mean Corpuscular Haemoglobin PRSs")
# FULL IDS (UNCOMMENT TO RUN FOR ALL PRSs) -------------
prs.ids <- c("PGS000099","PGS000174","PGS001219","PGS001989","PGS002206","PGS002339",
             "PGS002371","PGS002411","PGS002460","PGS002509","PGS002558","PGS002607",
             "PGS002656","PGS002705","PGS003560")
# PARTIAL IDS (SINCE SOME TAKE A WHILE TO RUN) ---------
# prs.ids <- c("PGS000099","PGS000174","PGS001219","PGS001989",
#              "PGS002206","PGS002411","PGS002460","PGS002509",
#              "PGS002558","PGS002607","PGS002656","PGS003560")
message(date(), ": No. PRSes = ", length(prs.ids))


message(date(), ': Computing original PRS results for lenient, stringent and PGS Catalog PRSs')
# Create empty df to fill in
orig.PRS.scores.df <- data.frame(PRS_ID = character(),
                                 PEARSON_CORR = numeric(),
                                 SPEARMAN_RHO = numeric(),
                                 COSINE_SIM = numeric(),
                                 TOP10PCT_PREV = numeric(),
                                 TOP1PCT_PREV = numeric(),
                                 TOP10PCT_OR = numeric(),
                                 TOP1PCT_OR = numeric(),
                                 PERCENTILE_AVE_PREV_SLOPE = numeric(),
                                 PERCENTILE_AVE_PREV_SPEARMAN = numeric(),
                                 PERCENTILE_AVE_PHENO_SLOPE = numeric(),
                                 PERCENTILE_AVE_PHENO_SPEARMAN = numeric())
stringent.orig.res <- readr::read_csv(paste0(c_and_t.prs.dir,
                                             'Mean_corpuscular_haemoglobin_gwas_1e-8_cutoff1e-10_usual_metrics_df.csv'),
                                      show_col_types = FALSE) %>% 
  subset(TYPE=='original')
lenient.orig.res <- readr::read_csv(paste0(c_and_t.prs.dir,
                                           'Mean_corpuscular_haemoglobin_gwas_1e-5_cutoff1e-8_usual_metrics_df.csv'),
                                    show_col_types = FALSE) %>% 
  subset(TYPE=='original')

colnames(stringent.orig.res)[1] <- 'PRS_ID'
colnames(lenient.orig.res)[1] <- 'PRS_ID'
stringent.orig.res[['PRS_ID']] <- 'Stringent'
lenient.orig.res[['PRS_ID']] <- 'Lenient'

# Load each PRS from PGS Catalog
for (pheno in prs.ids) {
  orig.res <- readr::read_csv(paste0(out.dir,
                                     'Jeremy_test/',
                                     pheno,
                                     '_cutoff1e-10_usual_metrics_df.csv'),
                              show_col_types = FALSE) %>% 
    subset(TYPE=='original')
  colnames(orig.res)[1] <- 'PRS_ID'
  orig.res[['PRS_ID']] <- pheno
  orig.PRS.scores.df <- rbind(orig.PRS.scores.df, 
                              orig.res)
}

# Add C&T PRS results
orig.PRS.scores.df <- rbind(orig.PRS.scores.df,lenient.orig.res)
orig.PRS.scores.df <- rbind(orig.PRS.scores.df,stringent.orig.res)

# Save
readr::write_csv(orig.PRS.scores.df,
                 file=paste0(out.dir,
                             'tables/orig_prs_performance.csv'))

# Get ranked dataframe
ranked.PRS.scores.df <- apply(orig.PRS.scores.df[,-1],2,
                              function(x) rank(x, ties.method='average')) 
aggregated_ranks <- rowSums(ranked.PRS.scores.df)
ranked.PRS.scores.df <- ranked.PRS.scores.df %>% as.data.frame()
ranked.PRS.scores.df$AGGREGATED <- aggregated_ranks
ranked.PRS.scores.df$PRS_ID <- orig.PRS.scores.df$PRS_ID
readr::write_csv(ranked.PRS.scores.df %>% select(c(colnames(orig.PRS.scores.df),'AGGREGATED')),
                 file=paste0('/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/tables/orig_prs_ranked_performance.csv'))

# Compare with no. SNPs in PRS
to_join <- prs_dist_cutoff %>% select(c('PRS_ID','N_SNPS'))
ranks_vs_no_snps <- left_join(ranked.PRS.scores.df %>% select(c('PRS_ID','AGGREGATED')),
                          to_join, by='PRS_ID')
ranks_vs_no_snps$N_SNPS[16] <- 372

ggplot(ranks_vs_no_snps,aes(y=AGGREGATED,x=log(N_SNPS))) +
  geom_point() +
  theme_bw()

## Compare original performance and distributional metrics
for (sig.cutoff in c('1e-6','1e-7','1e-8','1e-10')) {
  # Read PRS distribution file
  prs_dist_cutoff <- readr::read_csv(paste0(prs.dist.dir,
                                            'prs_dist_summaries_cutoff',
                                            sig.cutoff,
                                            '.csv'),
                                     show_col_types = FALSE) %>% 
    as.data.frame()
  colnames(prs_dist_cutoff)[1]<-'PRS_ID'
  # Read C&T file
  if (sig.cutoff=='1e-10') {
    c_and_t_signflip_usual <- readr::read_csv(paste0(c_and_t.dist.dir, 
                                                     'prs_dist_summaries_gwas1e-8_cutoff',
                                                     as.numeric(sig.cutoff),'.csv'),
                                              show_col_types = FALSE) %>%
      subset(PHENOTYPE=='Mean_corpuscular_haemoglobin')
    colnames(c_and_t_signflip_usual)[1] <- 'PRS_ID'
    c_and_t_signflip_usual[['PRS_ID']] <- 'Stringent'
  } else {
    c_and_t_signflip_usual <- readr::read_csv(paste0(c_and_t.dist.dir, 
                                                     'prs_dist_summaries_gwas1e-5_cutoff',
                                                     as.numeric(sig.cutoff),'.csv'),
                                              show_col_types = FALSE) %>%
      subset(PHENOTYPE=='Mean_corpuscular_haemoglobin')
    colnames(c_and_t_signflip_usual)[1] <- 'PRS_ID'
    c_and_t_signflip_usual[['PRS_ID']] <- 'Lenient'
  }
  
  prs_dist_cutoff <- rbind(prs_dist_cutoff,c_and_t_signflip_usual)
  
  # Merge dist df with original PRS df
  to_save <- merge(prs_dist_cutoff,orig.PRS.scores.df)
  print(dim(to_save))
  
  # Save
  readr::write_csv(to_save, file=paste0(out.dir,
                                        'tables/orig_prs_perf_vs_dist_summary_cutoff',
                                        sig.cutoff,'.csv'))
}


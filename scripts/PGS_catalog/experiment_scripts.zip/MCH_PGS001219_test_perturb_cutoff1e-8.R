####################################################
########### Mean Corpuscular Hemoglobin ############
############# Shuffling Experiment #################
######## Range of Target SNP cutoffs 1e-8 #########
############ Shuffle and Sign flips  ###############
####################################################
# This version saves predictions on 
# the test set only. It performs: 
# - sign flipping only
# - shuffling
# - sign inversion of all 'target' SNPs
# (6/11/23) Mean Corpuscular Hemoglobin PRSes
# (6/14/23) Fixed PRS files to include more variants that 
#           can be matched on chr:pos (with downstream
#           check on effect and other alleles)

#################
## Directories ##
#################
# Create output file 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/MCH_PGS001219_perturb_test_cutoff1e-8.log')
sink(stdout(), type = "message")

library(data.table)
library(dplyr)
library(bigsnpr)

N_SHUFFLES <- 100
R.workbench <- FALSE
sig.cutoff <- 1e-8
message('N_SHUFFLES = ', N_SHUFFLES)
message('sig.cutoff = ', sig.cutoff)

if (R.workbench) {
  genos.dir <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  pheno.gwas.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  X.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_autosome_metadata.csv')
} else {
  genos.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  pheno.gwas.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  X.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_autosome_metadata.csv')
}


###############
## Functions ##
###############
getPRSTestOnly <- function(gwas_file) {
  gwas_file$chrom <- as.character(gwas_file$chrom) # This fixes inconsistency
  all.chr <- unique(gwas_file$chrom) 
  test.prs.list <- vector("list", length=length(all.chr))
  names(test.prs.list) <- all.chr
  
  for (chr in all.chr) {
    print(paste0('Working on Chr', chr))
    chr.gwas <- gwas_file %>% subset(chrom == chr)
    # If chr 01 to 09, remove 0 in front
    if (substr(chr,1,1) == '0') {
      chrom <- substr(chr,2,2) 
      obj.bigSNP <- snp_attach(paste0(genos.dir,'ukb_imp_chr', chrom, '_v3.rds'))
    } else {
      obj.bigSNP <- snp_attach(paste0(genos.dir,'ukb_imp_chr', chr, '_v3.rds'))
    }
    # Read genotype object and variant map
    G <- obj.bigSNP$genotypes
    chr.map <- obj.bigSNP$map
    colnames(chr.map)[4] <- 'pos'
    joined.df <- left_join(chr.map, chr.gwas, by = 'pos')
    match.ref.alt <- ((joined.df$allele1 == joined.df$major) |  
                        (joined.df$allele2 == joined.df$major)) & 
      ((joined.df$allele1 == joined.df$minor) |  (joined.df$allele2 == joined.df$minor)) # check for match 
    joined.df$beta0 <- joined.df$beta * ifelse(joined.df$allele1 == joined.df$major,
                                               1, -1) * match.ref.alt
    selected.vars <- which(!is.na(joined.df$beta0))
    e.sizes <- joined.df[selected.vars,]$beta0
    # If ChrX need to use X.metadata
    if (chr == 'X') {
      test.ids <- which(X.metadata$TEST & X.metadata$EURO)
      test.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=test.ids)

    } else {
      test.ids <- which(autosome.metadata$TEST & autosome.metadata$EURO)
      test.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=test.ids)
    }
  }
  
  # Return PRS for test set
  test.prs <- Reduce('+', test.prs.list)[,1] %>% as.vector()
  
  return(test.prs)
}

##########
## Main ##
##########
message(date(), ": Performing perturbation experiment on Mean Corpuscular Haemoglobin PRSs")
#prs.ids <- c("PGS000099","PGS000174","PGS001219","PGS001989","PGS002206","PGS002339",
#             "PGS002371","PGS002411","PGS002460","PGS002509","PGS002558","PGS002607",
#             "PGS002656","PGS002705","PGS003560")
prs.ids <- c("PGS001219")
#message(date(), ": No. PRSes = ", length(prs.ids))
for (pheno in prs.ids) {
  # Print message
  message(date(), ": Working on ", pheno)
  
  # Load GWAS results 
  message("Loading GWAS results...")
  pheno.gwas <- data.table::fread(paste0(pheno.gwas.dir,
                                         "v2_files/",
                                         pheno,
                                         "_matched_v2.txt"))
  
  # Subset to only those variants with valid beta value
  message("Removing ", 
          round(100*sum(is.na(pheno.gwas$beta))/nrow(pheno.gwas)), 
          "% of variants that could not be matched. Variants are located in:")
  print(table((pheno.gwas %>% subset(is.na(beta)))$chr_name))
  pheno.gwas <- pheno.gwas %>% subset(!is.na(beta))
  
  # Check no. variants to be perturbed
  n.perturb.vars <- pheno.gwas %>% 
    subset(gwas_p_value >= sig.cutoff) %>% 
    nrow()
  
  message(date(), ": Computing PRS for original weights...")
  orig.result <- getPRSTestOnly(pheno.gwas)
  
  message(date(), ": Performing inversion of signs for all perturbed SNPs...")
  pheno.gwas.inversion <- pheno.gwas
  rel.inds <- which(pheno.gwas$gwas_p_value >= sig.cutoff)
  pheno.gwas.inversion$beta[rel.inds] <- pheno.gwas.inversion$beta[rel.inds]*-1
  inversion.result <- getPRSTestOnly(pheno.gwas.inversion)
  
  # If fewer than 5, perform exact permutations and compute [6/1/23]
  message(date(), ": Performing perturbation experiments...")
  if (n.perturb.vars < 5) {
    message("Detected k = ", n.perturb.vars, " (< 5) perturbed variants")
    message("Using all k! = ",factorial(n.perturb.vars)," permutations (exact)")
    message("Using all 2^k = ",2^n.perturb.vars," shuffles (exact)")
    perturb.var.ids <- which(pheno.gwas$gwas_p_value >= sig.cutoff)
    shuffle.array <- gtools::permutations(v=perturb.var.ids,n=length(perturb.var.ids),r=length(perturb.var.ids))
    signflip.array <- expand.grid(replicate(n=length(perturb.var.ids), c(-1,1), simplify = FALSE))
    
    test.signflip.df <- matrix(nrow = 74084, ncol = (nrow(signflip.array)-1))
    test.shuffle.df <- matrix(nrow = 74084, ncol = (nrow(shuffle.array)-1))
    
    for (i in 2:nrow(shuffle.array)) {
      message(date(), ": Performing Shuffle ", i-1)
      pheno.gwas.shuffle <- pheno.gwas
      pheno.gwas.shuffle$beta[perturb.var.ids] <- pheno.gwas.shuffle$beta[shuffle.array[i,]]
      
      shuffle.result <- getPRSTestOnly(pheno.gwas.shuffle)
      test.shuffle.df[,i-1] <- shuffle.result
    }
    
    for (j in 1:(nrow(signflip.array)-1)) {
      message(date(), ": Performing Signflip ", j)
      pheno.gwas.signflip <- pheno.gwas
      pheno.gwas.signflip$beta[perturb.var.ids] <- pheno.gwas$beta[perturb.var.ids]*as.numeric(signflip.array[j,])
      
      signflip.result <- getPRSTestOnly(pheno.gwas.signflip)
      test.signflip.df[,j] <- signflip.result
    }
  } else {
    message("Detected k = ", n.perturb.vars, " (>= 5) perturbed variants")
    message("Performing ", N_SHUFFLES, " random shuffles and signflips")
    test.signflip.df <- matrix(nrow = 74084, ncol = N_SHUFFLES)
    test.shuffle.df <- matrix(nrow = 74084, ncol = N_SHUFFLES)
    
    for (i in 1:N_SHUFFLES) {
      message(date(), ": Performing Shuffle and Signflip ", i)
      set.seed(i)
      pheno.gwas.signflip <- pheno.gwas
      pheno.gwas.shuffle <- pheno.gwas
      
      pheno.gwas.signflip$beta[rel.inds] <- pheno.gwas.signflip$beta[rel.inds]* # sign flip
        (rbinom(length(rel.inds),prob=0.5,size=1)*2 - 1) # no shuffling! 
      pheno.gwas.shuffle$beta[rel.inds] <- sample(pheno.gwas.shuffle$beta[rel.inds]) # shuffle
      
      shuffle.result <- getPRSTestOnly(pheno.gwas.shuffle)
      signflip.result <- getPRSTestOnly(pheno.gwas.signflip)
      
      test.shuffle.df[,i] <- shuffle.result
      test.signflip.df[,i] <- signflip.result
    }
  }
  
  # Saving results
  message(date(), ": Saving resultss for ", pheno)
  saveRDS(list(TEST_SIGNFLIP_ONLY=test.signflip.df,
               TEST_SHUFFLE_ONLY=test.shuffle.df,
               INVERSION=inversion.result,
               ORIGINAL=orig.result),
          file = paste0(out.dir, pheno, "_cutoff1e-8_test_pred_v2.rds"))
}

sink()
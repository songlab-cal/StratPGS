#### Summarize PRS for Lipoprotein A
####
#### This script pulls out all available variants from the GWAS database files
#### to allow matching of p-values from our cohort with the PRS provided in PGS
#### Catalog.

## Log file / libraries --------------------------------------------------------
sink('/deep_learning/aaw/051723/logs/get_mean_corpuscular_hemoglobin_gwas_pvals.log')
sink(stdout(), type = "message")
library(dplyr)
library(RSQLite)
library(DBI)

## Define directories ----------------------------------------------------------
R.workbench <- TRUE
if (R.workbench) {
  genos.dir <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  gwas.dir <- '/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/'
  corpuscular.hemoglobin.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_pvals/'
  gwas_matched_prs.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
} else {
  genos.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  gwas.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/'
  corpuscular.hemoglobin.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_pvals/'
  gwas_matched_prs.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
}

pheno <- 'Mean_Corpuscular_Hemoglobin'

## Summarize PRS ---------------------------------------------------------------
prs.files <- system(paste0('ls ', corpuscular.hemoglobin.dir, '*.txt'), intern=T)
message(date(), ": ", length(prs.files), " PRSes detected.")
prs.ids <- sapply(prs.files, function(x) {strsplit(strsplit(x, "/")[[1]][6], "\\.")[[1]][1]}) 
names(prs.ids) <- NULL

# Connect DB
message(date(), " Set up GWAS database.")
pheno.db <- paste0(gwas.dir, 'Mean_corpuscular_haemoglobin', '.db')
con <- dbConnect(SQLite(), dbname = pheno.db)

for (i in 1:length(prs.files)) {
  prs.file <- data.table::fread(prs.files[i],
                                skip=14)
  # For PGS001989.txt, PGS000174.txt, PGS001219.txt, PGS002206.txt, need a different name
  # These 4 PRSs have rsIDs so we can match using rsID on top of REF/ALT
  if (grepl('PGS001989.txt', prs.files[i]) | 
      grepl('PGS000174.txt', prs.files[i]) |
      grepl('PGS001219.txt', prs.files[i]) |
      grepl('PGS002206.txt', prs.files[i])) {
    colnames(prs.file)[1:6] <- c('rsID','chr_name','chr_position','effect_allele','other_allele','effect_weight')
    in.file <- prs.file %>% select(c('rsID','chr_name','chr_position','effect_allele','other_allele','effect_weight'))
    
    message(date(), ": ", nrow(in.file), " PRS variants to be matched")
    message(date(), ": All columns available for ", prs.ids[i])
    message(date(), ": Query using rsID, pos-effect-other and pos-other-effect")
    in.file$varid_e_o <- paste0('\"',in.file$chr_name,':',
                                in.file$chr_position,
                                '_', in.file$effect_allele,
                                '_', in.file$other_allele, 
                                '\"')
    in.file$varid_o_e <- paste0('\"',in.file$chr_name,':',
                                in.file$chr_position,
                                '_', in.file$other_allele,
                                '_', in.file$effect_allele, 
                                '\"')
    in.file$rsid <- paste0('\"', in.file$rsID, '\"')
    
    start <- Sys.time()
    #dbGetQuery(con, 'SELECT * FROM variants LIMIT 5')
    e_o_variants <- dbGetQuery(con, paste0('SELECT * FROM variants WHERE varid IN (', paste(in.file$varid_e_o, collapse=','),')'))
    end <- Sys.time()
    end - start
    start <- Sys.time()
    o_e_variants <- dbGetQuery(con, paste0('SELECT * FROM variants WHERE varid IN (', paste(in.file$varid_o_e, collapse=','),')'))
    end <- Sys.time()
    end - start
    start <- Sys.time()
    rsid_variants <- dbGetQuery(con, paste0('SELECT * FROM variants WHERE rsid IN (', paste(in.file$rsid, collapse=','),')'))
    end <- Sys.time()
    end-start
    
    combined.df <- rbind(rbind(rsid_variants,o_e_variants),e_o_variants) %>% distinct()
    message(date(), ": Found ", nrow(combined.df), " PRS variants in GWAS database") 
    message(date(), ": Percent available = ", nrow(combined.df)/nrow(in.file))
    
    readr::write_csv(combined.df, 
                     paste0(out.dir, prs.ids[i], '_gwas_pvals.csv'))
  } else {
    colnames(prs.file)[1:5] <- c('chr_name','chr_position','effect_allele','other_allele','effect_weight')
    in.file <- prs.file %>% select(c('chr_name','chr_position','effect_allele','other_allele','effect_weight'))
    
    # No rsID available
    message(date(), ": ", nrow(in.file), " PRS variants to be matched")
    message(date(), ": No rsID available for ", prs.ids[i])
    message(date(), ": Query using pos-effect-other and pos-other-effect only")
    
    in.file$varid_e_o <- paste0('\"',in.file$chr_name,':',
                                in.file$chr_position,
                                '_', in.file$effect_allele,
                                '_', in.file$other_allele, 
                                '\"')
    in.file$varid_o_e <- paste0('\"',in.file$chr_name,':',
                                in.file$chr_position,
                                '_', in.file$other_allele,
                                '_', in.file$effect_allele, 
                                '\"')
    
    start <- Sys.time()
    #dbGetQuery(con, 'SELECT * FROM variants LIMIT 5')
    e_o_variants <- dbGetQuery(con, paste0('SELECT * FROM variants WHERE varid IN (', paste(in.file$varid_e_o, collapse=','),')'))
    end <- Sys.time()
    end - start
    start <- Sys.time()
    o_e_variants <- dbGetQuery(con, paste0('SELECT * FROM variants WHERE varid IN (', paste(in.file$varid_o_e, collapse=','),')'))
    end <- Sys.time()
    end - start
    
    combined.df <- rbind(o_e_variants,e_o_variants) %>% distinct()
    message(date(), ": Found ", nrow(combined.df), " PRS variants in GWAS database")
    message(date(), ": Percent missing = ", nrow(combined.df)/nrow(in.file))
    
    readr::write_csv(combined.df, 
                     paste0(out.dir, prs.ids[i], '_gwas_pvals.csv'))
  }
}

dbDisconnect()
sink()

## Analyze PRS -----------------------------------------------------------------
# hemoglobin.prs.df <- data.frame(PRS = character(),
#                                 NUM_NONZERO_BETAS = numeric(),
#                                 NUM_1e5_VARS = numeric(),
#                                 NUM_1e6_VARS = numeric(),
#                                 NUM_1e7_VARS = numeric(),
#                                 NUM_1e8_VARS = numeric(),
#                                 NUM_1e9_VARS = numeric(),
#                                 NUM_1e10_VARS = numeric())
# for (i in 1:length(prs.files)) {
#   prs.file <- data.table::fread(prs.files[i],
#                                 skip=14)
#   gwas.file <- readr::read_csv(paste0(out.dir,prs.ids[i],'_gwas_pvals.csv'),
#                                show_col_types = FALSE) %>% 
#     select(c('rsid','varid','chrom','pos','minor','major','p_value'))
#   message('No. rows of GWAS file = ', nrow(gwas.file))
#   colnames(gwas.file)[1] <- 'rsID'
#   message('No. rows of PRS file = ', nrow(prs.file))
#   if (grepl('PGS000689.txt',prs.files[i])) {
#     # Need to use rsID and o_e / e_o
#     message(prs.ids[i], ' requires matching on rsID column AND pos-effect-other/pos-other-effect')
#     
#     prs.file$varid_e_o <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$effect_allele,
#                                  '_', prs.file$other_allele)
#     prs.file$varid_o_e <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$other_allele,
#                                  '_', prs.file$effect_allele)
#     
#     message('No. varid in agreement with varid_o_e = ', length(intersect(gwas.file$varid,prs.file$varid_o_e)))
#     message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
#     
#     gwas.file$varid_o_e <- gwas.file$varid
#     gwas.file$varid_e_o <- gwas.file$varid
#     
#     # do o_e_ first
#     merged.file1 <- left_join(prs.file, gwas.file, by='varid_o_e') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                                 'effect_weight', 'major', 'minor', 'p_value'))
#     
#     # do e_o next
#     merged.file2 <- left_join(prs.file, gwas.file, by='varid_e_o') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                                 'effect_weight', 'major', 'minor', 'p_value'))
#     
#     # do rsID last
#     merged.file3 <- left_join(prs.file, gwas.file, by ='rsID') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                             'effect_weight', 'major', 'minor', 'p_value'))
#     
#     merged.file <- rbind(rbind(merged.file1,merged.file2),merged.file3) %>% distinct()
#     
#     message('No. rows filled in PRS file by GWAS result = ', sum(!is.na(merged.file$major)))
#     
#   } else if (grepl('PGS000752.txt',prs.files[i])) {
#     # No rsID available in PRS file
#     message(prs.ids[i], ' does not have rsID column, requires matching by pos-effect-other')
#     
#     prs.file$varid_e_o <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$effect_allele,
#                                  '_', prs.file$other_allele)
#     message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
#     
#     # Major allele in GWAS file corresponds to effect allele in PRS file
#     gwas.file$varid_e_o <- gwas.file$varid
#     merged.file <- left_join(prs.file, gwas.file, by='varid_e_o')
#     message('No. rows filled in PRS file by GWAS result = ', sum(!is.na(merged.file$major)))
#     
#   } else if (grepl('PGS003542.txt',prs.files[i])) {
#     # No rsID available in PRS file
#     message(prs.ids[i], ' requires matching by pos-effect-other AND pos-other-effect')
#     
#     prs.file$varid_e_o <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$effect_allele,
#                                  '_', prs.file$other_allele)
#     prs.file$varid_o_e <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$other_allele,
#                                  '_', prs.file$effect_allele)
#     message('No. varid in agreement with varid_o_e = ', length(intersect(gwas.file$varid,prs.file$varid_o_e)))
#     message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
#     
#     gwas.file$varid_o_e <- gwas.file$varid
#     gwas.file$varid_e_o <- gwas.file$varid
#     
#     # do o_e_ first
#     merged.file1 <- left_join(prs.file, gwas.file, by='varid_o_e') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                                 'effect_weight', 'major', 'minor', 'p_value'))
#     
#     # do e_o next
#     merged.file2 <- left_join(prs.file, gwas.file, by='varid_e_o') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                                 'effect_weight', 'major', 'minor', 'p_value'))
#     
#     # combine now
#     merged.file <- rbind(merged.file1,merged.file2) %>% distinct()
#     
#     message('No. rows filled in PRS file by GWAS result = ', sum(!is.na(merged.file$major)))
#     
#   } else {
#     # rsID available in PRS file
#     message('Merging using rsID for ', prs.ids[i])
#     merged.file <- left_join(prs.file, gwas.file, by ='rsID')
#     message('No. rows filled in PRS file by GWAS result = ', sum(!is.na(merged.file$major)))
#   }
#   lipoprotein.prs.df <- rbind(lipoprotein.prs.df,
#                               data.frame(PRS = prs.ids[i],
#                                          NUM_NONZERO_BETAS = prs.file %>% subset(effect_weight!=0) %>% nrow(),
#                                          NUM_1e5_VARS = merged.file %>% subset(effect_weight!=0 & p_value >= 1e-5) %>% nrow(),
#                                          NUM_1e6_VARS = merged.file %>% subset(effect_weight!=0 & p_value >= 1e-6) %>% nrow(),
#                                          NUM_1e7_VARS = merged.file %>% subset(effect_weight!=0 & p_value >= 1e-7) %>% nrow(),
#                                          NUM_1e8_VARS = merged.file %>% subset(effect_weight!=0 & p_value >= 1e-8) %>% nrow(),
#                                          NUM_1e9_VARS = merged.file %>% subset(effect_weight!=0 & p_value >= 1e-9) %>% nrow(),
#                                          NUM_1e10_VARS = merged.file %>% subset(effect_weight!=0 & p_value >= 1e-10) %>% nrow()))
# }
# 
# ## Analyze effect variances for insignificant variants in each PRS -------------
# lipoprotein.prs.df <- data.frame(PRS = character(),
#                                  NUM_NONZERO_BETAS = numeric(),
#                                  NUM_1e5_VARS = numeric(),
#                                  ABS_SPREAD_1e5_VARS = numeric(),
#                                  RAW_SPREAD_1e5_VARS = numeric())
# for (i in 1:length(prs.files)) {
#   prs.file <- data.table::fread(prs.files[i],
#                                 skip=14)
#   gwas.file <- readr::read_csv(paste0(out.dir,prs.ids[i],'_gwas_pvals.csv'),
#                                show_col_types = FALSE) %>% 
#     select(c('rsid','varid','chrom','pos','minor','major','p_value'))
#   message('No. rows of GWAS file = ', nrow(gwas.file))
#   colnames(gwas.file)[1] <- 'rsID'
#   message('No. rows of PRS file = ', nrow(prs.file))
#   if (grepl('PGS000689.txt',prs.files[i])) {
#     # Need to use rsID and o_e / e_o
#     message(prs.ids[i], ' requires matching on rsID column AND pos-effect-other/pos-other-effect')
#     
#     prs.file$varid_e_o <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$effect_allele,
#                                  '_', prs.file$other_allele)
#     prs.file$varid_o_e <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$other_allele,
#                                  '_', prs.file$effect_allele)
#     
#     message('No. varid in agreement with varid_o_e = ', length(intersect(gwas.file$varid,prs.file$varid_o_e)))
#     message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
#     
#     gwas.file$varid_o_e <- gwas.file$varid
#     gwas.file$varid_e_o <- gwas.file$varid
#     
#     # do o_e_ first
#     merged.file1 <- left_join(prs.file, gwas.file, by='varid_o_e') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                                 'effect_weight', 'major', 'minor', 'p_value'))
#     
#     # do e_o next
#     merged.file2 <- left_join(prs.file, gwas.file, by='varid_e_o') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                                 'effect_weight', 'major', 'minor', 'p_value'))
#     
#     # do rsID last
#     merged.file3 <- left_join(prs.file, gwas.file, by ='rsID') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                             'effect_weight', 'major', 'minor', 'p_value'))
#     
#     merged.file <- rbind(rbind(merged.file1,merged.file2),merged.file3) %>% distinct()
#     
#     message('No. rows filled in PRS file by GWAS result = ', sum(!is.na(merged.file$major)))
#     
#   } else if (grepl('PGS000752.txt',prs.files[i])) {
#     # No rsID available in PRS file
#     message(prs.ids[i], ' does not have rsID column, requires matching by pos-effect-other')
#     
#     prs.file$varid_e_o <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$effect_allele,
#                                  '_', prs.file$other_allele)
#     message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
#     
#     # Major allele in GWAS file corresponds to effect allele in PRS file
#     gwas.file$varid_e_o <- gwas.file$varid
#     merged.file <- left_join(prs.file, gwas.file, by='varid_e_o')
#     message('No. rows filled in PRS file by GWAS result = ', sum(!is.na(merged.file$major)))
#     
#   } else if (grepl('PGS003542.txt',prs.files[i])) {
#     # No rsID available in PRS file
#     message(prs.ids[i], ' requires matching by pos-effect-other AND pos-other-effect')
#     
#     prs.file$varid_e_o <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$effect_allele,
#                                  '_', prs.file$other_allele)
#     prs.file$varid_o_e <- paste0(prs.file$chr_name,':',
#                                  prs.file$chr_position,
#                                  '_', prs.file$other_allele,
#                                  '_', prs.file$effect_allele)
#     message('No. varid in agreement with varid_o_e = ', length(intersect(gwas.file$varid,prs.file$varid_o_e)))
#     message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
#     
#     gwas.file$varid_o_e <- gwas.file$varid
#     gwas.file$varid_e_o <- gwas.file$varid
#     
#     # do o_e_ first
#     merged.file1 <- left_join(prs.file, gwas.file, by='varid_o_e') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                                 'effect_weight', 'major', 'minor', 'p_value'))
#     
#     # do e_o next
#     merged.file2 <- left_join(prs.file, gwas.file, by='varid_e_o') %>% select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
#                                                                                 'effect_weight', 'major', 'minor', 'p_value'))
#     
#     # combine now
#     merged.file <- rbind(merged.file1,merged.file2) %>% distinct()
#     
#     message('No. rows filled in PRS file by GWAS result = ', sum(!is.na(merged.file$major)))
#     
#   } else {
#     # rsID available in PRS file
#     message('Merging using rsID for ', prs.ids[i])
#     merged.file <- left_join(prs.file, gwas.file, by ='rsID')
#     message('No. rows filled in PRS file by GWAS result = ', sum(!is.na(merged.file$major)))
#   }
#   message('HEADER OF INSIGNIFICANT VARIANTS FOR ', prs.ids[i])
#   print(head(merged.file %>% subset(effect_weight!=0 & p_value >= 1e-5)))
#   lipoprotein.prs.df <- rbind(lipoprotein.prs.df,
#                               data.frame(PRS = prs.ids[i],
#                                          NUM_NONZERO_BETAS = prs.file %>% subset(effect_weight!=0) %>% nrow(),
#                                          NUM_1e5_VARS = merged.file %>% subset(effect_weight!=0 & p_value >= 1e-5) %>% nrow(),
#                                          ABS_SPREAD_1e5_VARS = var(abs((merged.file %>% subset(effect_weight!=0 & p_value >= 1e-5))$effect_weight)),
#                                          RAW_SPREAD_1e5_VARS = var((merged.file %>% subset(effect_weight!=0 & p_value >= 1e-5))$effect_weight)))
# }

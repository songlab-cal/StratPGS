#### Summarize PRS for MCH
####
#### This script tries to match all remaining unmatched variants in the GWAS sumstats
#### files, and modifies the files (saving them as [ORIGINAL NAME]_v2.txt)

## Log file / libraries --------------------------------------------------------
sink('/illumina/scratch/deep_learning/aaw/051723/logs/get_remainder_MCH_gwas_pvals.log')
sink(stdout(), type = "message")
library(dplyr)
library(RSQLite)
library(DBI)

## Define directories ----------------------------------------------------------
R.workbench <- FALSE
if (R.workbench) {
  genos.dir <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  gwas.dir <- '/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/'
  corpuscular.hemoglobin.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_pvals/'
  gwas_matched_prs.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
} else {
  genos.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  gwas.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/'
  corpuscular.hemoglobin.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_pvals/'
  gwas_matched_prs.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
}

pheno <- 'Mean_Corpuscular_Hemoglobin'

## Summarize PRS ---------------------------------------------------------------
prs.files <- system(paste0('ls ', gwas_matched_prs.dir, '*.txt'), intern=T)
message(date(), ": ", length(prs.files), " PRSes detected.")
prs.ids <- sapply(prs.files, function(x) {strsplit(strsplit(x, "/")[[1]][9], "\\.")[[1]][1]}) # need to use 9 for R.workbench=FALSE
names(prs.ids) <- NULL

# Connect DB
message(date(), " Set up GWAS database.")
pheno.db <- paste0(gwas.dir, 'Mean_corpuscular_haemoglobin', '.db')
con <- dbConnect(SQLite(), dbname = pheno.db)

for (i in 1:length(prs.files)) {
  if (file.exists(paste0(gwas_matched_prs.dir,
                         "/v2_files/",
                         prs.ids[i],
                         "_v2.txt"))) {
    message(date(), ": Already worked on ", prs.ids[i], ", skipping")
  } else {
    message(date(), ": Working on ", prs.ids[i])
    prs.file <- data.table::fread(prs.files[i])
    
    # Select variants with beta = NA (these are the previously unmatched ones)
    matched.variants <- prs.file %>% subset(!is.na(beta))
    na.variants <- prs.file %>% subset(is.na(beta))
    selected_cols <- colnames(na.variants) # for selecting relevant columns to save later
    no_na_vars <- nrow(na.variants) # tracking this variable to make sure that it is the same after modification
    message("No. unmatched variants = ", no_na_vars)
    
    if (no_na_vars == 0) {
      message("All variants have been matched, skipping to next PRS file")
      data.table::fwrite(prs.file, 
                         file=paste0(gwas_matched_prs.dir,
                                     "/v2_files/",
                                     prs.ids[i],
                                     "_v2.txt"))
    } else {
      message(date(), ": Begin matching of unmatched variants")
      message(date(), ": Query using chrom and pos only")
      
      na.variants$chr_name_char <- na.variants$chr_name %>% 
        sapply(function(x){ifelse((x<10|identical(x,"2")|
                                    identical(x,"3")|identical(x,"4")|
                                    identical(x,"5")|identical(x,"6")|
                                    identical(x,"7")|identical(x,"8")|
                                    identical(x,"9")), 
                                  paste0('0',as.character(x)), 
                                  as.character(x))})
      distinct.chr <- unique(na.variants$chr_name_char)
      this_prs_df <- data.frame(varid=character(),
                                rsid=character(),
                                chrom=character(),
                                pos=numeric(),
                                minor=character(),
                                major=character(),
                                beta=numeric(),
                                se=numeric(),
                                r2=numeric(),
                                p_value=numeric())
      for (chr in distinct.chr) {
        message("Matching Chr ", chr)
        all.chr.positions <- (na.variants %>% subset(chr_name_char==chr))$chr_position
        #message("Removing NA positions --- case of HLA-DQA1*0301 for PGS001219")
        all.chr.positions <- na.omit(all.chr.positions) %>% as.numeric()
        chr_pos_variants <- dbGetQuery(con, paste0('SELECT * FROM variants WHERE chrom=\"',chr,'\" AND pos IN (', paste(all.chr.positions, collapse=','),')'))
        
        this_prs_df <- rbind(this_prs_df,
                             chr_pos_variants)
      }
      message(date(), ": Matched ", nrow(this_prs_df), " remaining variants")
      no_leftover_vars <- no_na_vars - nrow(this_prs_df)
      message(date(), ": No. leftover unmatched = ", no_leftover_vars)
      
      if (no_leftover_vars==no_na_vars) {
        # Could not match any of the remaining unmatched, so just save the file
        message("Could not match any remaining variants, skipping to next PRS file")
        data.table::fwrite(prs.file, 
                           file=paste0(gwas_matched_prs.dir,
                                       "/v2_files/",
                                       prs.ids[i],
                                       "_v2.txt"))
      } else {
        message(date(), ": FIRST CHECK that fraction of unmatched variants in ",prs.ids[i]," after this match = ", no_leftover_vars/nrow(prs.file))
        
        # Start merger with na.variants file
        for_merging <- this_prs_df %>% select(c('chrom','pos','minor','major','p_value'))
        colnames(for_merging)[5] <- 'gwas_p_value'
        #print(head(for_merging))
        
        na.variants$UNIQUE_ID <- paste0(na.variants$chr_name_char, ":", na.variants$chr_position)
        na.variants$chrom <- NULL; na.variants$pos <- NULL; na.variants$major <- NULL
        na.variants$minor <- NULL; na.variants$gwas_p_value <- NULL
        for_merging$UNIQUE_ID <- paste0(for_merging$chrom, ":", for_merging$pos)
        merged_df <- left_join(na.variants,for_merging,by='UNIQUE_ID')
        message("merged_df length = ", nrow(merged_df))
        
        # This if-else block exists to deal with PGS001219
        if (nrow(merged_df)==nrow(na.variants)) {
          message("nrow(merged_df) == nrow(na.variants), i.e., no duplicate chr:pos")
          out_file <- merged_df
          out_file$beta <- out_file$effect_weight * ifelse(out_file$effect_allele == out_file$major,
                                                           1, -1)
          problematic_vars <- (out_file %>% subset(((effect_allele==major|effect_allele==minor)&
                                 (other_allele==major|other_allele==minor))))$UNIQUE_ID
          problematic_ids <- which(out_file$UNIQUE_ID %in% problematic_vars)
          
          if (length(problematic_ids) > 0) {
            message("Setting beta to NA for non-matching ref/alt vs effect/other variants")
            out_file$beta[problematic_ids] <- NA
          }
        } else {
          message("nrow(merged_df) != nrow(na.variants), need to perform extra filter")
          out_file <- merged_df %>% 
            subset(is.na(major)&is.na(minor)|(effect_allele=='P')| # case of HLA-DQA1*0301 for PGS001219 requires P/N as a case
                     ((effect_allele==major|effect_allele==minor)&
                        (other_allele==major|other_allele==minor)))
          
          message("Out file length = ", nrow(out_file))
          message("No. NA variants = ", nrow(na.variants))
          message("Which variants are not in out_file?")
          diff_vars<-setdiff(na.variants$UNIQUE_ID, out_file$UNIQUE_ID)
          print(diff_vars)
          pathological_df <- merged_df %>% subset(UNIQUE_ID %in% diff_vars)
          if (nrow(pathological_df)==length(diff_vars)) {
            message("nrow(pathological_df) == length(diff_vars), just row-append pathological_df to out_file")
            out_file <- rbind(out_file, pathological_df)
          } else {
            message("Need to remove duplicate variants in pathological_df")
            message("AKA, manually row-appending each variant and removing duplicates")
            for (unique_id in unique(pathological_df$UNIQUE_ID)) {
              pathological_id <- pathological_df %>% subset(UNIQUE_ID == unique_id)
              if (nrow(pathological_id) > 1) {
                print(pathological_id)
              } 
              out_file <- rbind(out_file, pathological_id[1,])
            }
          }
          message("New out file length = ", nrow(out_file))
          assertthat::assert_that(nrow(out_file)==nrow(na.variants),
                                  msg="The out file length and original no. unmatched variants do not match.")
          out_file$beta <- out_file$effect_weight * ifelse(out_file$effect_allele == out_file$major,
                                                           1, -1)
          problematic_ids <- which(out_file$UNIQUE_ID %in% diff_vars)
          if (length(problematic_ids) > 0) {
            message("Setting beta to NA for non-matching ref/alt vs effect/other variants")
            out_file$beta[problematic_ids] <- NA
          }
        }
        # Select relevant columns
        real_out_file <- out_file %>% select(selected_cols)
        
        to_return_file <- rbind(matched.variants,
                                real_out_file)
        
        message(date(), ": SECOND CHECK that fraction of unmatched variants in ", prs.ids[i],
                " after this match = ", nrow(to_return_file %>% subset(is.na(beta)))/nrow(prs.file))
        data.table::fwrite(to_return_file, 
                           file=paste0(gwas_matched_prs.dir,
                                       "/v2_files/",
                                       prs.ids[i],
                                       "_v2.txt"))
      }
    }
  }
}

dbDisconnect(con)
sink()
## Merge PRS files with summary stats for perturbation experiment --------------
## DATED 6/10/2023 
# Make sure effect allele matches major allele, else multiply by -1
# This forces effect to be w.r.t. major allele 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/mean_corpuscular_hemoglobin_prs_sumstats_matching.log')
sink(stdout(), type = "message")
library(dplyr)
library(RSQLite)
library(DBI)

## Define directories ----------------------------------------------------------
R.workbench <- FALSE
if (R.workbench) {
  genos.dir <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  gwas.dir <- '/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/'
  corpuscular.hemoglobin.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_pvals/'
  gwas_matched_prs.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
} else {
  genos.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  gwas.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/'
  corpuscular.hemoglobin.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_pvals/'
  gwas_matched_prs.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
}

pheno <- 'Mean_Corpuscular_Hemoglobin'
prs.files <- system(paste0('ls ', corpuscular.hemoglobin.dir, '*.txt'), intern=T)
message(date(), ": ", length(prs.files), " PRSes detected.")
prs.ids <- sapply(prs.files, function(x) {strsplit(strsplit(x, "/")[[1]][8], "\\.")[[1]][1]}) # 8 if R.workbench is FALSE, else 6
names(prs.ids) <- NULL
selected.columns <- c('chrom','pos','major','minor','beta','p_value')

for (i in 1:length(prs.files)) {
  message(date(), ': WORKING ON ', prs.ids[i], ' -----------------------------')
  gwas.file <- readr::read_csv(paste0(out.dir,prs.ids[i],'_gwas_pvals.csv'),
                               show_col_types = FALSE) %>% 
    select(c('rsid','varid','chrom','pos','minor','major','p_value'))
  message('No. rows of GWAS file = ', nrow(gwas.file))
  colnames(gwas.file)[1] <- 'rsID'
  prs.file <- data.table::fread(prs.files[i],
                                skip=14)
  message('No. rows of PRS file = ', nrow(prs.file))
  
  prs.file$varid_e_o <- paste0(prs.file$chr_name,':',
                               prs.file$chr_position,
                               '_', prs.file$effect_allele,
                               '_', prs.file$other_allele)
  prs.file$varid_o_e <- paste0(prs.file$chr_name,':',
                               prs.file$chr_position,
                               '_', prs.file$other_allele,
                               '_', prs.file$effect_allele)
  prs.file.copy <- prs.file # for modifying 

  if (grepl('PGS001989.txt', prs.files[i]) | 
      grepl('PGS000174.txt', prs.files[i]) |
      grepl('PGS001219.txt', prs.files[i]) |
      grepl('PGS002206.txt', prs.files[i])) {
    # These files have rsID, so need to match on rsID,
    # pos-other-effect, and pos-effect-other columns
    message('Matching on rsID column, pos-other-effect and pos-effect-other')
    
    if (length(intersect(gwas.file$varid,prs.file$varid_o_e))>0 & length(intersect(gwas.file$varid,prs.file$varid_e_o))>0) {
      message('No. varid in agreement with varid_o_e = ', length(intersect(gwas.file$varid,prs.file$varid_o_e)))
      message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
      message('Appending p-values for agreeing varid_o_e and varid_e_o variants')
      gwas.file$varid_o_e <- gwas.file$varid
      gwas.file$varid_e_o <- gwas.file$varid
      
      # do o_e_ first
      merged.file1 <- left_join(prs.file.copy, gwas.file, by='varid_o_e') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele',
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value'))
      prs.file.copy <- prs.file.copy[which(is.na(merged.file1$major)),] # what's not matched yet
      
      # do e_o_ next 
      merged.file2 <- left_join(prs.file.copy, gwas.file, by='varid_e_o') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele',
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value'))
      prs.file.copy <- prs.file.copy[which(is.na(merged.file2$major)),] # what's not matched yet
      
      # do rsID last
      merged.file3 <- left_join(prs.file.copy, gwas.file, by ='rsID') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value')) 
      
      # Merge into a single file
      merged.file <- rbind(rbind(merged.file1 %>% subset(!is.na(major)),
                                 merged.file2 %>% subset(!is.na(major))),
                           merged.file3) %>% distinct()
      
      # Assert that dimensions match original prs file
      assertthat::assert_that(nrow(merged.file)==nrow(prs.file),
                              msg="Final merged file has different no. variants than input PRS file")
      
      # Report fraction of unmatched variants
      message('No. rows filled in PRS file by GWAS result for ', prs.ids[i], ' = ', sum(is.na(merged.file$major)))
      message('Matching rate for ', prs.ids[i], ' = ', sum(!is.na(merged.file$major))/nrow(prs.file))
      
    } else if (length(intersect(gwas.file$varid,prs.file$varid_o_e))>0) {
      message('No. varid in agreement with varid_o_e = ', length(intersect(gwas.file$varid,prs.file$varid_o_e)))
      message('Appending p-values for agreeing varid_o_e variants')
      
      gwas.file$varid_o_e <- gwas.file$varid
      
      # do o_e_ first
      merged.file1 <- left_join(prs.file.copy, gwas.file, by='varid_o_e') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele',
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value'))
      prs.file.copy <- prs.file.copy[which(is.na(merged.file1$major)),] # what's not matched yet
      
      # do rsID last
      merged.file3 <- left_join(prs.file.copy, gwas.file, by ='rsID') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value')) 
      
      # Merge into a single file
      merged.file <- rbind(merged.file1 %>% subset(!is.na(major)),
                           merged.file3) %>% distinct()
      
      # Assert that dimensions at least as large as original prs file 
      assertthat::assert_that(nrow(merged.file)>=nrow(prs.file),
                              msg="Final merged file has fewer no. variants than input PRS file")
      if (nrow(merged.file)>nrow(prs.file)) {
        # Alert if duplicate variants found
        # will be fixed later on
        message("Duplicate variants found for ", prs.ids[i]) 
      }
      
      # Report fraction of unmatched variants
      message('No. rows filled in PRS file by GWAS result for ', prs.ids[i], ' = ', sum(is.na(merged.file$major)))
      message('Matching rate for ', prs.ids[i], ' = ', sum(!is.na(merged.file$major))/nrow(prs.file))
      
    } else {
      message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
      message('Appending p-values for agreeing varid_e_o variants')
      
      gwas.file$varid_e_o <- gwas.file$varid
      
      # do e_o_ first
      merged.file1 <- left_join(prs.file.copy, gwas.file, by='varid_e_o') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele',
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value'))
      prs.file.copy <- prs.file.copy[which(is.na(merged.file1$major)),] # what's not matched yet
      
      # do rsID last
      merged.file3 <- left_join(prs.file.copy, gwas.file, by ='rsID') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele', 
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value')) 
      
      # Merge into a single file
      merged.file <- rbind(merged.file1 %>% subset(!is.na(major)),
                           merged.file3) %>% distinct()
      
      # Assert that dimensions match original prs file
      assertthat::assert_that(nrow(merged.file)==nrow(prs.file),
                              msg="Final merged file has different no. variants than input PRS file")
      
      # Report fraction of unmatched variants
      message('No. rows filled in PRS file by GWAS result for ', prs.ids[i], ' = ', sum(is.na(merged.file$major)))
      message('Matching rate for ', prs.ids[i], ' = ', sum(!is.na(merged.file$major))/nrow(prs.file))
    }
  } else {
    # These other files do not have rsID, so need to
    # match on pos-other-effect and pos-effect-other
    message('No rsID. Matching on pos-other-effect and pos-effect-other')
    
    if (length(intersect(gwas.file$varid,prs.file$varid_o_e))>0 & length(intersect(gwas.file$varid,prs.file$varid_e_o))>0) {
      message('No. varid in agreement with varid_o_e = ', length(intersect(gwas.file$varid,prs.file$varid_o_e)))
      message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
      message('Appending p-values for agreeing varid_o_e and varid_e_o variants')
      gwas.file$varid_o_e <- gwas.file$varid
      gwas.file$varid_e_o <- gwas.file$varid
      
      # do o_e_ first
      merged.file1 <- left_join(prs.file.copy, gwas.file, by='varid_o_e') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele',
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value'))
      prs.file.copy <- prs.file.copy[which(is.na(merged.file1$major)),] # what's not matched yet
      
      # do e_o_ next 
      merged.file2 <- left_join(prs.file.copy, gwas.file, by='varid_e_o') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele',
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value'))
      
      # Merge into a single file
      merged.file <- rbind(merged.file1 %>% subset(!is.na(major)),
                           merged.file2) %>% distinct()
      
      # Assert that dimensions match original prs file
      assertthat::assert_that(nrow(merged.file)==nrow(prs.file),
                              msg="Final merged file has different no. variants than input PRS file")
      
      # Report fraction of unmatched variants
      message('No. rows filled in PRS file by GWAS result for ', prs.ids[i], ' = ', sum(is.na(merged.file$major)))
      message('Matching rate for ', prs.ids[i], ' = ', sum(!is.na(merged.file$major))/nrow(prs.file))
      
    } else if (length(intersect(gwas.file$varid,prs.file$varid_o_e))>0) {
      message('No. varid in agreement with varid_o_e = ', length(intersect(gwas.file$varid,prs.file$varid_o_e)))
      message('Appending p-values for agreeing varid_o_e variants')
      
      gwas.file$varid_o_e <- gwas.file$varid
      
      # do o_e_ first
      merged.file1 <- left_join(prs.file.copy, gwas.file, by='varid_o_e') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele',
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value'))
      
      # Merge into a single file
      merged.file <- merged.file1 
      
      # Assert that dimensions match original prs file
      assertthat::assert_that(nrow(merged.file)==nrow(prs.file),
                              msg="Final merged file has different no. variants than input PRS file")
      
      # Report fraction of unmatched variants
      message('No. rows filled in PRS file by GWAS result for ', prs.ids[i], ' = ', sum(is.na(merged.file$major)))
      message('Matching rate for ', prs.ids[i], ' = ', sum(!is.na(merged.file$major))/nrow(prs.file))
      
    } else {
      message('No. varid in agreement with varid_e_o = ', length(intersect(gwas.file$varid,prs.file$varid_e_o)))
      message('Appending p-values for agreeing varid_e_o variants')
      
      gwas.file$varid_e_o <- gwas.file$varid
      
      # do e_o_ first
      merged.file1 <- left_join(prs.file.copy, gwas.file, by='varid_e_o') %>% 
        select(c('chr_name','chr_position', 'effect_allele', 'other_allele',
                 'effect_weight', 'chrom', 'pos', 'major', 'minor', 'p_value'))
      
      # Merge into a single file
      merged.file <- merged.file1
      
      # Assert that dimensions match original prs file
      assertthat::assert_that(nrow(merged.file)==nrow(prs.file),
                              msg="Final merged file has different no. variants than input PRS file")
      
      # Report fraction of unmatched variants
      message('No. rows filled in PRS file by GWAS result for ', prs.ids[i], ' = ', sum(is.na(merged.file$major)))
      message('Matching rate for ', prs.ids[i], ' = ', sum(!is.na(merged.file$major))/nrow(prs.file))
    }
  }
  
  # Flip effect direction if necessary
  # so that major allele matches effect allele 
  message(date(), ': Saving PRS file in perturbation-friendly format')
  merged.file$beta <- merged.file$effect_weight * ifelse(merged.file$effect_allele == merged.file$major,
                                                         1, -1)
  
  out.file <- merged.file %>% 
    select(c('chr_name','chr_position','effect_allele', 'other_allele', 
             'effect_weight',selected.columns)) %>%
    # this step prevents pathological cases, like an erroneous variant
    # sharing the same rsID, from contributing junk matches to the final
    # outfile. (Example is for PGS001219", with two rs10887621, but with
    #           exactly one of them being the correct variant that is matched)
    # Be careful of the major = NaN or minor = NaN cases when creating the subset
    # criterion.
    subset(is.na(major)&is.na(minor)|
             ((effect_allele==major|effect_allele==minor)&
             (other_allele==major|other_allele==minor)))
  colnames(out.file)[11] <- 'gwas_p_value'
  print(head(out.file))
  
  message('No. rows in out.file = ', nrow(out.file))
  message('No. rows in prs.file = ', nrow(prs.file))
  
  assertthat::assert_that(nrow(out.file) == nrow(prs.file),
                          msg='Outfile and original PRS file have different no. rows even after extra filtering step!')
  message('Removing ', length(which(out.file$effect_weight==0)), ' variants with effect_weight = 0 to save memory')
  final.out.file <- out.file %>% subset(effect_weight != 0)
  message('Final no. variants for ', prs.ids[i], ' = ', nrow(final.out.file))
  message('Fraction removed from original file (due to effect_weight = 0) = ', 1-nrow(final.out.file)/nrow(prs.file))
  if (sum(is.na(out.file$beta))>0) {
    message('Percent final betas available (i.e., matched) = ', sum(!is.na(out.file$beta))/nrow(out.file))
    warning(paste0(sum(is.na(out.file$beta)), ' variants could not be matched to summary stats file (',prs.ids[i],')'))
  }
  data.table::fwrite(final.out.file,
                     file=paste0(gwas_matched_prs.dir,
                                 prs.ids[i],
                                 "_matched.txt"))
}

sink()

## Analyse ---------------------------------------------------------------------

##### Remove duplicate pos variants --------------------------------------------
# Create output file 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/MCH_check_duplicate_pos_vars.log')
sink(stdout(), type = "message")

library(data.table)
library(dplyr)
library(bigsnpr)

R.workbench <- FALSE
if (R.workbench) {
  genos.dir <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  pheno.gwas.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
  out.dir <- '/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  X.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_autosome_metadata.csv')
} else {
  genos.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  pheno.gwas.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/gwas_matched_prs/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/Mean_Corpuscular_Hemoglobin/results/prs/'
  X.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_autosome_metadata.csv')
}

prs.ids <- c("PGS002656", "PGS002371", "PGS002339")

## Helper Function -------------------------------------------------------------
checkDuplicates <- function(gwas_file) {
  gwas_file$chrom <- as.character(gwas_file$chrom) # This fixes inconsistency
  all.chr <- unique(gwas_file$chrom) 
  
  gwas_file_out <- gwas_file
  
  dup_pos_counter <- 0
  for (chr in all.chr) {
    print(paste0('Working on Chr', chr))
    chr.gwas <- gwas_file %>% subset(chrom == chr)
    
    # Select pos 
    duplicate.pos <- as.numeric(names(which(table(chr.gwas$pos) > 1)))
    dup_pos_counter <- dup_pos_counter + length(duplicate.pos)
    message('Found ', length(duplicate.pos), ' variants with duplicate pos')
    if (length(duplicate.pos) >= 1) {
      print(chr.gwas %>% subset(pos %in% duplicate.pos))
    }
  }
  message("Total no. duplicate pos variants = ", dup_pos_counter)
  return(0)
}

## Main Body -------------------------------------------------------------------
for (prs in prs.ids) {
  # Load PRS file 
  message("Loading PRS GWAS file for ", prs, "...")
  pheno.gwas <- data.table::fread(paste0(pheno.gwas.dir,
                                         "v2_files/",
                                         prs,
                                         "_matched_v2.txt"))
  
  # Subset to only those variants with valid beta value
  message("Removing ", 
          round(100*sum(is.na(pheno.gwas$beta))/nrow(pheno.gwas)), 
          "% of variants that could not be matched. Variants are located in:")
  print(table((pheno.gwas %>% subset(is.na(beta)))$chr_name))
  pheno.gwas <- pheno.gwas %>% subset(!is.na(beta))
  
  checkDuplicates(pheno.gwas)
}

######################################
## Evaluate significance of metrics ##
######################################
## Created: 12/1/22 - Alan Aw
## Compute same R^2 diagnosis metrics, by randomizing the phenotypes and 
## evaluating the significance of diagnosis metrics for the observed
## data against the randomization null
## 

# Create output file
sink(
  '/illumina/scratch/deep_learning/aaw/120122/evaluate_significance_6.txt')
sink(stdout(), type = "message")

# Report available RAM
message(date(), "Available memory: ", memuse::Sys.meminfo()$freeram)

library(dplyr)
library(tidyr)
library(reshape2)
library(readr)
library(doParallel)

message(date(), ": No. cores = ", bigstatsr::nb_cores())
registerDoParallel(bigstatsr::nb_cores()-1)

R.workbench <- FALSE

# Define directories 
if (R.workbench) {
  pheno.dir <- '/deep_learning/aaw/101922/data_10pct/n487309_phenos.csv'
  save.folder <- '/deep_learning/aaw/120122/'
} else {
  pheno.dir <- '/illumina/scratch/deep_learning/aaw/101922/data_10pct/n487309_phenos.csv'
  save.folder <- '/illumina/scratch/deep_learning/aaw/120122/'
}

# Define metric computation function
computeMetrics4 <- function(prs, actual, covariates.df) {
  # Compute R^2 with PRS included
  local.df <- covariates.df[,-1]
  local.df[['pheno']] <- actual
  local.df[['prs']] <- prs
  lm.w.prs <- lm(pheno ~., data = local.df) # with intercept and PRS
  
  # Return model R^2 statistics
  return(data.frame(R2 = summary(lm.w.prs)$r.squared,
                    ADJ.R2 = summary(lm.w.prs)$adj.r.squared,
                    ADJ.R2.POSITIVE = 0+(summary(lm.w.prs)$adj.r.squared > 0)))
}

# Load random projections
message(date(), ": Loading random projections")
if (R.workbench) {
  rel.gw.rprojs <- readr::read_csv('/deep_learning/aaw/101922/data_10pct/n487309_rprojs_10pct.csv')
} else {
  rel.gw.rprojs <- readr::read_csv('/illumina/scratch/deep_learning/aaw/101922/data_10pct/n487309_rprojs_10pct.csv')
}

colnames(rel.gw.rprojs)[201] <- 'sample_id'

# Use k = 20 PCs
k <- 20
message(date(), ": Using ", 
        k, " gPCs for computing incremental R^2")

# Load covariates 
library(data.table)
covariates.dir <- ifelse(R.workbench,
                         '/deep_learning/ukbiobank/data/processed_tables/csv/covariates_for_phenotype_corrections.all_UKB.all_ethnicities.csv.gz',
                         '/illumina/scratch/deep_learning/ukbiobank/data/processed_tables/csv/covariates_for_phenotype_corrections.all_UKB.all_ethnicities.csv.gz')
cov.df = fread(covariates.dir)
age.sex.metadata <- cov.df[,c('sample_id','age','sex')]

# Load genetic PCs
if (R.workbench) {
  gPCs.df <- readr::read_csv('/deep_learning/aaw/101922/data_10pct/n487296_gpcs.csv')
} else {
  gPCs.df <- readr::read_csv('/illumina/scratch/deep_learning/aaw/101922/data_10pct/n487296_gpcs.csv')
}

# Restrict to sample IDs available in both random projection and phenotype
common.ids <- intersect(gPCs.df$sample_id, age.sex.metadata$sample_id)
rel.age.sex.metadata <- age.sex.metadata %>% subset(sample_id %in% common.ids)

# Merge
regress.df <- merge(rel.age.sex.metadata,gPCs.df,by='sample_id')
bigger.regress.df<- merge(regress.df, rel.gw.rprojs, by='sample_id')
covariates.df <- bigger.regress.df %>% 
  select(c('sample_id','age','sex',paste0('gPC_',1:k)))

# Read phenos
phenos <- readr::read_csv(pheno.dir)
pheno.names <- colnames(phenos)[2:1270]
rel.phenos <- phenos %>% subset(sample_id %in% common.ids)

# Define number of randomizations
n.randomizations <- 100

#for (i in 2:182) {
#for (i in 183:363) {
#for (i in 364:544) {
#for (i in 545:725) {
#for (i in 726:906) {
for (i in 907:1087) {
#for (i in 1088:1269) {
  message(date(), ": Working on Phenotype ", 
          i, " (",
          pheno.names[i], ")")
  start <- Sys.time()
  pheno.random.df <- data.frame(MEAN.DELTA.R2 = numeric(),
                                MEAN.DELTA.ADJ.R2 = numeric(),
                                MEAN.DELTA.ADJ.R2.POSITIVE = numeric())
  for (j in 1:n.randomizations) {
    # Randomize the phenotype
    set.seed(j)
    message("Randomizing with seed = ", j)
    randomized.pheno <- sample(rel.phenos[[i+1]])
    
    # Compute null R^2 
    null.df <- covariates.df[,-1]
    null.df$pheno <- randomized.pheno
    lm.null <- lm(pheno ~., data = null.df)
    
    # Compute R^2 for each random projection
    random.j <- foreach(k=1:200, .combine = rbind) %dopar% {
      #for (k in 1:200) {
      computeMetrics4(prs=bigger.regress.df[[paste0('V',k)]], actual = randomized.pheno, covariates.df = covariates.df)
    }
    pheno.random.df <- rbind(pheno.random.df,
                             data.frame(MEAN.DELTA.R2 = mean(random.j$R2 - summary(lm.null)$r.squared),
                                        MEAN.DELTA.ADJ.R2 = mean(random.j$ADJ.R2 - summary(lm.null)$adj.r.squared),
                                        MEAN.DELTA.ADJ.R2.POSITIVE = mean(random.j$ADJ.R2.POSITIVE - (summary(lm.null)$adj.r.squared > 0))))
  }
  readr::write_csv(pheno.random.df, file = paste0(save.folder, pheno.names[i], '_stats.csv'))
  end <- Sys.time()
  time.elapsed <- difftime(end, start, units='mins')
  message("Time elapsed for ", 
          pheno.names[i], 
          " = ", round(time.elapsed,3), "min")
}
sink()

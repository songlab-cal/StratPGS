######################################
## Evaluate significance of metrics ##
######################################
## Created: 11/1/22 - Alan Aw
## Compute same diagnosis metrics, by randomizing the phenotypes and 
## evaluating the significance of diagnosis metrics for the observed
## data against the randomization null
## 

# Create output file
sink(
  '/illumina/scratch/deep_learning/aaw/110122/evaluate_significance_2.txt')
sink(stdout(), type = "message")

# Report available RAM
message(date(), "Available memory: ", memuse::Sys.meminfo()$freeram)

library(dplyr)
library(tidyr)
library(reshape2)
library(readr)
library(doParallel)

message(date(), ": No. cores = ", bigstatsr::nb_cores())
registerDoParallel(bigstatsr::nb_cores()-1)

R.workbench <- FALSE

# Define directories 
if (R.workbench) {
  pheno.dir <- '/deep_learning/aaw/101922/data_10pct/n487309_phenos.csv'
  rproj.dir <- '/deep_learning/aaw/101922/data_10pct/n487309_rprojs_10pct.csv'
  backup.folder <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  bgen.folder <- '/deep_learning/ukbiobank/data/array_genotypes/'
  save.folder <- '/deep_learning/aaw/110122/randomization_results/'
} else {
  pheno.dir <- '/illumina/scratch/deep_learning/aaw/101922/data_10pct/n487309_phenos.csv'
  rproj.dir <- '/illumina/scratch/deep_learning/aaw/101922/data_10pct/n487309_rprojs_10pct.csv'
  backup.folder <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  bgen.folder <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/'
  save.folder <- '/illumina/scratch/deep_learning/aaw/110122/randomization_results/'
}

# Define metric computation function
computeMetrics3 <- function(prs, actual) {
  # Create decile vector 
  decile_vec <- quantile(prs, seq(0.01,1,length.out=100))
  
  # Create df to manipulate
  my_df <- data.frame(PRS = prs,
                      PERCENTILE = ntile(prs,100),
                      ACTUAL = actual,
                      CASE_CONTROL = ifelse(actual > median(actual, 
                                                            na.rm = TRUE), 
                                            1, 0)) #[!] may need to change later
  
  # Compute mean values of case/control
  my_df_2 <- my_df %>% 
    gather(variable, value, -PERCENTILE) %>% 
    group_by(variable, PERCENTILE) %>% 
    summarise(mean = mean(value, na.rm=TRUE))
  prev.dec.df <- reshape2::dcast(my_df_2, PERCENTILE ~ variable)
  colnames(prev.dec.df)[3] <- "prevalence"; prev.dec.df$PERCENTILE <- NULL
  # Create a dataframe [prevalence(pheno), decile]
  prev.dec.df <- cbind(data.frame(percentile = decile_vec), prev.dec.df)
  
  # Get regression p-value
  my_model <- lm(prevalence ~ percentile -1, data=prev.dec.df)
  decile.t.score <- as.numeric(summary(my_model)[["coefficients"]][, "t value"])[1]
  
  # Return
  return(data.frame(PERCENTILE_T_SCORE = decile.t.score,
                    PERCENTILE_BETA = summary(my_model)[["coefficients"]][1,1],
                    PERCENTILE_PREV_COR = cor(prev.dec.df$percentile, prev.dec.df$prevalence),
                    PERCENTILE_P_VAL = summary(my_model)[["coefficients"]][1,4]))
}

# Read in phenotypes and random projections
phenos <- readr::read_csv(pheno.dir)
rel.gw.rprojs <- readr::read_csv(rproj.dir)
pheno.names <- colnames(phenos)[2:1270]
n.randomizations <- 100 
# I think 500 randomizations takes 50 min per pheno, 
# so about 44 days for 1269 phenos
# for each phenotype
#for (i in 1:182) {
for (i in 184:363) {
#for (i in 364:544) {
#for (i in 545:725) {
#for (i in 726:906) {
#for (i in 907:1087) {
#for (i in 1088:1269) {
  message(date(), ": Working on Phenotype ", 
          i, " (",
          pheno.names[i], ")")
  start <- Sys.time()
  pheno.random.df <- data.frame(VAR_BETAS = numeric(),
                                MAX_ABS_BETAS = numeric(),
                                MEAN_ABS_BETAS = numeric(),
                                VAR_PP_CORS = numeric(),
                                MAX_ABS_PP_CORS = numeric(),
                                MEAN_ABS_PP_CORS = numeric())
  # perform randomization and computation of metrics
  # (can be parallelized)
  for (j in 1:n.randomizations) {
    set.seed(j)
    message("Randomizing with seed = ", j)
    randomized.pheno <- sample(phenos[[i+1]])
    # [!] parallelize here!
    random.j <- foreach(k=1:200, .combine = rbind) %dopar% {
      #for (k in 1:200) {
      computeMetrics3(prs=rel.gw.rprojs[[k]], actual = randomized.pheno)
    }
    pheno.random.df <- rbind(pheno.random.df,
                             data.frame(VAR_BETAS = var(random.j$PERCENTILE_BETA),
                                        MAX_ABS_BETAS = max(abs(random.j$PERCENTILE_BETA)),
                                        MEAN_ABS_BETAS = mean(abs(random.j$PERCENTILE_BETA)),
                                        VAR_PP_CORS = var(random.j$PERCENTILE_PREV_COR),
                                        MAX_ABS_PP_CORS = max(abs(random.j$PERCENTILE_PREV_COR)),
                                        MEAN_ABS_PP_CORS = mean(abs(random.j$PERCENTILE_PREV_COR))))
  }
  readr::write_csv(pheno.random.df, file = paste0(save.folder, pheno.names[i], '_stats.csv'))
  end <- Sys.time()
  time.elapsed <- difftime(end, start, units='mins')
  message("Time elapsed for ", 
          pheno.names[i], 
          " = ", round(time.elapsed,3), "min")
}

sink()
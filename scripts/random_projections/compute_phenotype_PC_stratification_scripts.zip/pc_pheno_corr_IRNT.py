## Perform correlation computation of phenotypes
# For each phenotype, compute its inner product (both RAW and IRNT) with 
# the top 50 PCs

# Which PC has highest inner product with phenotype?
# For a phenotype, is the "PC-inner product profile" uniform or spiked?
# For a PC, which phenotypes are most highly similar to it? 


import pandas
import numpy
import datetime

pcs_df=pandas.read_csv('/illumina/scratch/deep_learning/aaw/090622/gPCs.csv')
pc_indices=['gPC_' + str(x) for x in range(1,41)]
#pheno_list=pandas.read_table('/illumina/scratch/deep_learning/aaw/090622/RAW_names.txt', \
#	header=None)[0].tolist()
pheno_list=pandas.read_table('/illumina/scratch/deep_learning/aaw/090622/IRNT_names.txt', \
        header=None)[0].tolist()

#inner_prod_list=[]
norm_inner_prod_list=[]
start_time=datetime.datetime.now()
for pheno in pheno_list:
	# Print
	print(f"{datetime.datetime.now()} --- Working on {pheno}...")
	# Select phenotype
	phenos_df=pandas.read_csv('/illumina/scratch/deep_learning/aaw/090622/phenotypes.all_ethnicities.both.all_UKB.csv', \
		usecols=['sample_id', pheno], \
		sep='\t') 
	# Merge with pcs_df
	merged_df=phenos_df.merge(pcs_df, on='sample_id', how='inner')
	merged_df.dropna(axis = 0, how = 'any', inplace = True)
	# Compute correlation with each gPC
	#inner_prod_list.append([numpy.inner(merged_df[pheno],merged_df[x]) for x in pc_indices])
	norm_inner_prod_list.append([numpy.inner(merged_df[pheno],merged_df[x])/(numpy.linalg.norm(merged_df[pheno])*numpy.linalg.norm(merged_df[x])) for x in pc_indices])
end_time=datetime.datetime.now()
print(f"Time elapsed = {(end_time-start_time).total_seconds()} sec")

#inner_prod_df = pandas.DataFrame(inner_prod_list, columns=pc_indices)
norm_inner_prod_df = pandas.DataFrame(norm_inner_prod_list, columns=pc_indices)
#inner_prod_df.index=pheno_list
norm_inner_prod_df.index=pheno_list

#inner_prod_df.to_csv('/illumina/scratch/deep_learning/aaw/091522/RAW_inner_prod.csv', index=True)
norm_inner_prod_df.to_csv('/illumina/scratch/deep_learning/aaw/091622/IRNT_cosine_sim.csv', index=True)

###################################
#### Check robustness of trend ####
###################################
## Created: 11/11/22 - Alan Aw
## Perform bootstrap on the phenotypes
## Compute correlation statistic to see if 
## the positive correlation still persists and
## p-values still significant
library(rsample)
library(dplyr)

raw.orig.plotting.df <- readr::read_csv('/deep_learning/aaw/111122/raw_orig_plotting_df.csv')
irnt.orig.plotting.df <- readr::read_csv('/deep_learning/aaw/111122/irnt_orig_plotting_df.csv')

getBootStats <- function(my.df) {
  resamp.no <- nrow(my.df)
  sample()
}

boot.list <- rsample::bootstraps(raw.orig.plotting.df, times = 5000)
boot.list <- rsample::bootstraps(irnt.orig.plotting.df, times = 5000)
boot.list$splits

boot.pvals <- map_dbl(boot.list$splits, 
                      function(x) {
                        cor.test(as.data.frame(x)$PC1_ABS_COS_SIM, 
                                 as.data.frame(x)$MAX_ABS_BETAS)$p.value
                      })

boot.cor <- map_dbl(boot.list$splits, 
                    function(x) {
                      cor.test(as.data.frame(x)$PC1_ABS_COS_SIM, 
                               as.data.frame(x)$MAX_ABS_BETAS)$estimate
                    })

foo <- cor.test(irnt.orig.plotting.df$PC1_ABS_COS_SIM, irnt.orig.plotting.df$MAX_ABS_BETAS)
point.cor <- foo$estimate; point.pval <- foo$p.value

2 * point.cor - quantile(boot.cor, c(0.975,0.025))
2 * point.pval - quantile(boot.pvals, c(0.975,0.025))

## Plotting for slide deck -----------------------------------------------------
# Date: 4/11/23

raw.orig.plotting.df
raw.orig.1stvisit.plotting.df <- raw.orig.plotting.df[which(!sapply(raw.orig.plotting.df$PHENOTYPE, function(x) grepl('2nd_visit',x))),]
raw.orig.plot <- ggplot(raw.orig.1stvisit.plotting.df, aes(x = PC1_ABS_COS_SIM, 
                                                         y = MAX_ABS_BETAS)) +
  geom_point(aes(colour = GREATER_P_VAL,
                 shape = SIGNIFICANT)) +
  theme_bw() +
  scale_colour_gradientn(colours = terrain.colors(10)) +
  #xlim(c(2.4,3.6)) +
  #ylim(c(0,2e-5)) +
  #stat_smooth(method = "lm",
  #            formula = y ~ x,
  #            geom = "smooth") +
  #ggpubr::stat_cor(label.x = 0, label.y = 5e-4) +
  #ggpubr::stat_regline_equation(label.y = 4.8e-4, aes(label = ..eq.label..)) +
  xlab('Absolute Cosine Similarity of Phenotype with PC1') +
  ylab('Maximum Absolute Regression Coefficient\nAcross 200 Random Projections') +
  guides(colour=guide_colourbar(title="Randomization\np-value"),
         shape=guide_legend(title='p < 0.05')) +
  ggtitle('RAW Original Phenotypes (1st Visit)') +
  theme(plot.title = element_text(hjust = 0.5,
                                  face = 'bold'))
ggsave(raw.orig.plot,
       filename = '/deep_learning/aaw/111122/raw_orig_1stvisit_pc1cossim_vs_maxRegressBeta_111122.jpg',
       width = 5, 
       height = 4.5, 
       dpi = 400)

raw.left.df <- raw.orig.1stvisit.plotting.df %>% subset(PC1_ABS_COS_SIM <= 0.1) 
raw.right.df <-raw.orig.1stvisit.plotting.df %>% subset(PC1_ABS_COS_SIM > 0.1)

raw.right.plot <- ggplot(raw.right.df, aes(x = GREATER_P_VAL)) +
  geom_histogram(fill='grey',colour = 'black',binwidth=0.01) +
  theme_bw() +
  xlab('p-value') +
  ylab('count') +
  xlim(c(-0.01,1)) +
  geom_vline(xintercept = 0.05, lty='dashed') +
  ggtitle('Phenotypes with Abs. Cos. Sim. At Least 0.1') +
  theme(plot.title = element_text(hjust = 0.5,
                                  face = 'bold'))
ggsave(raw.right.plot,
       filename = '/deep_learning/aaw/111122/right_hist_1stvisit_pc1cossim_vs_maxRegressBeta_111122.jpg',
       width = 4.5, 
       height = 4, 
       dpi = 300)

raw.left.plot <- ggplot(raw.left.df, aes(x = GREATER_P_VAL)) +
  geom_histogram(fill='grey',colour = 'black',binwidth=0.01) +
  theme_bw() +
  xlab('p-value') +
  ylab('count') +
  xlim(c(-0.01,1)) +
  geom_vline(xintercept = 0.05, lty='dashed') +
  ggtitle('Phenotypes with Abs. Cos. Sim. Less Than 0.1') +
  theme(plot.title = element_text(hjust = 0.5,
                                  face = 'bold'))
ggsave(raw.left.plot,
       filename = '/deep_learning/aaw/111122/left_hist_1stvisit_pc1cossim_vs_maxRegressBeta_111122.jpg',
       width = 4.5, 
       height = 4, 
       dpi = 300)

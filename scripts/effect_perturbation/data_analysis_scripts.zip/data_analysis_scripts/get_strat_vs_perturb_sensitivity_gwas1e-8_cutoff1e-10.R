#############################################
########## Perturbation Experiment ##########
########## Using GWAS cutoff 1e-8 ###########
####### Sign flips and eSize Shuffles #######
#############################################
# This script combines stratification of PRS metrics by PCs
# and sensitivity of PRS to perturbations on a training set
# Created on 5/30/23: This version takes max(f(y,PRS^+),f(y,PRS^-))
#                     Also computes the f(y,PRS) version (aka 'usual approach')
# objects with 'usual' appended in front correspond to the f(y,PRS) version of things

## Log file / libraries --------------------------------------------------------
sink('/illumina/scratch/deep_learning/aaw/051723/logs/gwas1e-8_cutoff1e-10_strat_vs_perturb_sensitivity.log')
sink(stdout(), type = "message")
library(data.table)
library(dplyr)
#library(bigsnpr)

## Variables -------------------------------------------------------------------
R.workbench <- FALSE
gwas.thres <- '1e-8'
sig.cutoff <- '1e-10'
message('gwas.thres = ', gwas.thres)
message('sig.cutoff = ', sig.cutoff)

if (R.workbench) {
  phenos.shortlist <- data.table::fread('/deep_learning/aaw/051723/results/pheno_names_gwas1e8.txt',
                                        header = FALSE)$V1
  out.dir <- '/deep_learning/aaw/051723/results/stratification_vs_perturbation_sensitivity/'
  prs.strat.dir <- '/deep_learning/aaw/051723/results/prs_pc_stratification/'
  pheno.strat.dir <- '/deep_learning/aaw/051723/results/pheno_pc_stratification/'
  perturb.dir <- '/deep_learning/aaw/051723/results/prs_perturbation_sensitivity/'
} else {
  phenos.shortlist <- data.table::fread('/illumina/scratch/deep_learning/aaw/051723/results/pheno_names_gwas1e8.txt',
                                        header = FALSE)$V1
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/stratification_vs_perturbation_sensitivity/'
  prs.strat.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/prs_pc_stratification/'
  pheno.strat.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/pheno_pc_stratification/'
  perturb.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/prs_perturbation_sensitivity/'
}

## Main Body -------------------------------------------------------------------
# Read perturbation sensitivity metrics
prs_shuffle_max <- readr::read_csv(paste0(perturb.dir,'gwas',
                                          gwas.thres,'_cutoff',
                                          sig.cutoff,'_shuffle_metrics_df.csv'),
                                   show_col_types = FALSE) %>% 
  as.data.frame()
prs_signflip_max <- readr::read_csv(paste0(perturb.dir,'gwas',
                                           gwas.thres,'_cutoff',
                                           sig.cutoff,'_signflip_metrics_df.csv'),
                                    show_col_types = FALSE) %>% 
  as.data.frame()
prs_shuffle_usual <- readr::read_csv(paste0(perturb.dir,'gwas',
                                          gwas.thres,'_cutoff',
                                          sig.cutoff,'_shuffle_usual_metrics_df.csv'),
                                     show_col_types = FALSE) %>% 
  as.data.frame()
prs_signflip_usual <- readr::read_csv(paste0(perturb.dir,'gwas',
                                           gwas.thres,'_cutoff',
                                           sig.cutoff,'_signflip_usual_metrics_df.csv'),
                                      show_col_types = FALSE) %>% 
  as.data.frame()

# Read PRS stratification metrics
prs_strat <- readr::read_csv(paste0(prs.strat.dir,
                                    'train_n288728_prs_gwas_',
                                    gwas.thres,
                                    '_gPC_metrics.csv'),
                             show_col_types = FALSE) %>% 
  as.data.frame()
prs_strat$PC1_COSSIM <- NULL;prs_strat$PC1_PEARSON <- NULL;prs_strat$PC1_SPEARMAN <- NULL

# Combine 
shuffle_max_prs_strat <- merge(prs_shuffle_max,prs_strat,by='PHENO')
signflip_max_prs_strat <- merge(prs_signflip_max,prs_strat,by='PHENO')
shuffle_usual_prs_strat <- merge(prs_shuffle_usual,prs_strat,by='PHENO')
signflip_usual_prs_strat <- merge(prs_signflip_usual,prs_strat,by='PHENO')

readr::write_csv(shuffle_max_prs_strat,
                 file = paste0(out.dir,"/raw_tables/gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_shuffle_max_combined.csv"))
readr::write_csv(signflip_max_prs_strat,
                 file = paste0(out.dir,"/raw_tables/gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_signflip_max_combined.csv"))

readr::write_csv(shuffle_usual_prs_strat,
                 file = paste0(out.dir,"/raw_tables/gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_shuffle_usual_combined.csv"))
readr::write_csv(signflip_usual_prs_strat,
                 file = paste0(out.dir,"/raw_tables/gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_signflip_usual_combined.csv"))

# Compute p-values and correlations
shuffle_max_vs_strat_corr_array <- matrix(NA,nrow=ncol(prs_shuffle_max)-1,ncol=ncol(prs_strat)-1)
signflip_max_vs_strat_corr_array <- matrix(NA,nrow=ncol(prs_signflip_max)-1,ncol=ncol(prs_strat)-1)
shuffle_usual_vs_strat_corr_array <- matrix(NA,nrow=ncol(prs_shuffle_usual)-1,ncol=ncol(prs_strat)-1)
signflip_usual_vs_strat_corr_array <- matrix(NA,nrow=ncol(prs_signflip_usual)-1,ncol=ncol(prs_strat)-1)

shuffle_max_vs_strat_pvals_array <- matrix(NA,nrow=ncol(prs_shuffle_max)-1,ncol=ncol(prs_strat)-1)
signflip_max_vs_strat_pvals_array <- matrix(NA,nrow=ncol(prs_signflip_max)-1,ncol=ncol(prs_strat)-1)
shuffle_usual_vs_strat_pvals_array <- matrix(NA,nrow=ncol(prs_shuffle_usual)-1,ncol=ncol(prs_strat)-1)
signflip_usual_vs_strat_pvals_array <- matrix(NA,nrow=ncol(prs_signflip_usual)-1,ncol=ncol(prs_strat)-1)

colnames(shuffle_max_vs_strat_corr_array) <- colnames(prs_strat)[-1]
rownames(shuffle_max_vs_strat_corr_array) <- colnames(prs_shuffle_max)[-1]
colnames(signflip_max_vs_strat_corr_array) <- colnames(prs_strat)[-1]
rownames(signflip_max_vs_strat_corr_array) <- colnames(prs_signflip_max)[-1]
colnames(shuffle_usual_vs_strat_corr_array) <- colnames(prs_strat)[-1]
rownames(shuffle_usual_vs_strat_corr_array) <- colnames(prs_shuffle_usual)[-1]
colnames(signflip_usual_vs_strat_corr_array) <- colnames(prs_strat)[-1]
rownames(signflip_usual_vs_strat_corr_array) <- colnames(prs_signflip_usual)[-1]

colnames(shuffle_max_vs_strat_pvals_array) <- colnames(prs_strat)[-1]
rownames(shuffle_max_vs_strat_pvals_array) <- colnames(prs_shuffle_max)[-1]
colnames(signflip_max_vs_strat_pvals_array) <- colnames(prs_strat)[-1]
rownames(signflip_max_vs_strat_pvals_array) <- colnames(prs_signflip_max)[-1]
colnames(shuffle_usual_vs_strat_pvals_array) <- colnames(prs_strat)[-1]
rownames(shuffle_usual_vs_strat_pvals_array) <- colnames(prs_shuffle_usual)[-1]
colnames(signflip_usual_vs_strat_pvals_array) <- colnames(prs_strat)[-1]
rownames(signflip_usual_vs_strat_pvals_array) <- colnames(prs_signflip_usual)[-1]

n.tests <- nrow(shuffle_max_vs_strat_corr_array)*ncol(shuffle_max_vs_strat_corr_array)
message(date(), ": No. tests performed = ", n.tests)
fwer.thres.cutoff <- 0.05/n.tests
message(date(), ": FWER corrected p-value threshold = ", fwer.thres.cutoff)
for (i in 1:nrow(shuffle_max_vs_strat_corr_array)) {
  for (j in 1:ncol(shuffle_max_vs_strat_corr_array)) {
    # Shuffle, max
    shuffle_max_vs_strat_corr_array[i,j] <- cor(shuffle_max_prs_strat[[rownames(shuffle_max_vs_strat_corr_array)[i]]],
                                                shuffle_max_prs_strat[[colnames(shuffle_max_vs_strat_corr_array)[j]]])
    p_val <- cor.test(shuffle_max_prs_strat[[rownames(shuffle_max_vs_strat_corr_array)[i]]],
                      shuffle_max_prs_strat[[colnames(shuffle_max_vs_strat_corr_array)[j]]])$p.value
    shuffle_max_vs_strat_pvals_array[i,j] <- p_val
    if (p_val < fwer.thres.cutoff) {
      message('(SHUFFLE, MAX): Significant correlation (p = ',p_val,') between ', 
              rownames(shuffle_max_vs_strat_corr_array)[i], ' and ', 
              colnames(shuffle_max_vs_strat_corr_array)[j])
      message('(SHUFFLE, MAX): Pearson r = ', shuffle_max_vs_strat_corr_array[i,j])
    }
    
    # Signflip, max
    signflip_max_vs_strat_corr_array[i,j] <- cor(signflip_max_prs_strat[[rownames(signflip_max_vs_strat_corr_array)[i]]],
                                                signflip_max_prs_strat[[colnames(signflip_max_vs_strat_corr_array)[j]]])
    p_val <- cor.test(signflip_max_prs_strat[[rownames(signflip_max_vs_strat_corr_array)[i]]],
                      signflip_max_prs_strat[[colnames(signflip_max_vs_strat_corr_array)[j]]])$p.value
    signflip_max_vs_strat_pvals_array[i,j] <- p_val
    if (p_val < fwer.thres.cutoff) {
      message('(SIGNFLIP, MAX): Significant correlation (p = ',p_val,') between ', 
              rownames(signflip_max_vs_strat_corr_array)[i], ' and ', 
              colnames(signflip_max_vs_strat_corr_array)[j])
      message('(SIGNFLIP, MAX): Pearson r = ', signflip_max_vs_strat_corr_array[i,j])
    }
    
    # Shuffle, usual
    shuffle_usual_vs_strat_corr_array[i,j] <- cor(shuffle_usual_prs_strat[[rownames(shuffle_usual_vs_strat_corr_array)[i]]],
                                                shuffle_usual_prs_strat[[colnames(shuffle_usual_vs_strat_corr_array)[j]]])
    p_val <- cor.test(shuffle_usual_prs_strat[[rownames(shuffle_usual_vs_strat_corr_array)[i]]],
                      shuffle_usual_prs_strat[[colnames(shuffle_usual_vs_strat_corr_array)[j]]])$p.value
    shuffle_usual_vs_strat_pvals_array[i,j] <- p_val
    if (p_val < fwer.thres.cutoff) {
      message('(SHUFFLE, USUAL): Significant correlation (p = ',p_val,') between ', 
              rownames(shuffle_usual_vs_strat_corr_array)[i], ' and ', 
              colnames(shuffle_usual_vs_strat_corr_array)[j])
      message('(SHUFFLE, USUAL): Pearson r = ', shuffle_usual_vs_strat_corr_array[i,j])
    }
    
    # Signflip, usual
    signflip_usual_vs_strat_corr_array[i,j] <- cor(signflip_usual_prs_strat[[rownames(signflip_usual_vs_strat_corr_array)[i]]],
                                                   signflip_usual_prs_strat[[colnames(signflip_usual_vs_strat_corr_array)[j]]])
    p_val <- cor.test(signflip_usual_prs_strat[[rownames(signflip_usual_vs_strat_corr_array)[i]]],
                      signflip_usual_prs_strat[[colnames(signflip_usual_vs_strat_corr_array)[j]]])$p.value
    signflip_usual_vs_strat_pvals_array[i,j] <- p_val
    if (p_val < fwer.thres.cutoff) {
      message('(SIGNFLIP, USUAL): Significant correlation (p = ',p_val,') between ', 
              rownames(signflip_usual_vs_strat_corr_array)[i], ' and ', 
              colnames(signflip_usual_vs_strat_corr_array)[j])
      message('(SIGNFLIP, USUAL): Pearson r = ', signflip_usual_vs_strat_corr_array[i,j])
    }
  }
}

# Convert to dataframe and include sensitivity metrics as a new feature column
shuffle_max_vs_strat_corr_array <- as.data.frame(shuffle_max_vs_strat_corr_array)
shuffle_max_vs_strat_corr_array$SENSITIVITY_METRIC <- rownames(shuffle_max_vs_strat_corr_array)
shuffle_max_vs_strat_pvals_array <- as.data.frame(shuffle_max_vs_strat_pvals_array)
shuffle_max_vs_strat_pvals_array$SENSITIVITY_METRIC <- rownames(shuffle_max_vs_strat_pvals_array)

signflip_max_vs_strat_corr_array <- as.data.frame(signflip_max_vs_strat_corr_array)
signflip_max_vs_strat_corr_array$SENSITIVITY_METRIC <- rownames(signflip_max_vs_strat_corr_array)
signflip_max_vs_strat_pvals_array <- as.data.frame(signflip_max_vs_strat_pvals_array)
signflip_max_vs_strat_pvals_array$SENSITIVITY_METRIC <- rownames(signflip_max_vs_strat_pvals_array)

shuffle_usual_vs_strat_corr_array <- as.data.frame(shuffle_usual_vs_strat_corr_array)
shuffle_usual_vs_strat_corr_array$SENSITIVITY_METRIC <- rownames(shuffle_usual_vs_strat_corr_array)
shuffle_usual_vs_strat_pvals_array <- as.data.frame(shuffle_usual_vs_strat_pvals_array)
shuffle_usual_vs_strat_pvals_array$SENSITIVITY_METRIC <- rownames(shuffle_usual_vs_strat_pvals_array)

signflip_usual_vs_strat_corr_array <- as.data.frame(signflip_usual_vs_strat_corr_array)
signflip_usual_vs_strat_corr_array$SENSITIVITY_METRIC <- rownames(signflip_usual_vs_strat_corr_array)
signflip_usual_vs_strat_pvals_array <- as.data.frame(signflip_usual_vs_strat_pvals_array)
signflip_usual_vs_strat_pvals_array$SENSITIVITY_METRIC <- rownames(signflip_usual_vs_strat_pvals_array)

# Save files
readr::write_csv(shuffle_max_vs_strat_corr_array,
                 file = paste0(out.dir,"corr_gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_shuffle_max_vs_strat.csv"))
readr::write_csv(shuffle_max_vs_strat_pvals_array,
                 file = paste0(out.dir,"pvals_gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_shuffle_max_vs_strat.csv"))

readr::write_csv(signflip_max_vs_strat_corr_array,
                 file = paste0(out.dir,"corr_gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_signflip_max_vs_strat.csv"))
readr::write_csv(signflip_max_vs_strat_pvals_array,
                 file = paste0(out.dir,"pvals_gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_signflip_max_vs_strat.csv"))

readr::write_csv(shuffle_usual_vs_strat_corr_array,
                 file = paste0(out.dir,"corr_gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_shuffle_usual_vs_strat.csv"))
readr::write_csv(shuffle_usual_vs_strat_pvals_array,
                 file = paste0(out.dir,"pvals_gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_shuffle_usual_vs_strat.csv"))

readr::write_csv(signflip_usual_vs_strat_corr_array,
                 file = paste0(out.dir,"corr_gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_signflip_usual_vs_strat.csv"))
readr::write_csv(signflip_usual_vs_strat_pvals_array,
                 file = paste0(out.dir,"pvals_gwas",
                               gwas.thres,"_cutoff",
                               sig.cutoff,"_signflip_usual_vs_strat.csv"))
sink()

## Manual plotting -------------------------------------------------------------
prefix.dir <- '/deep_learning/aaw/051723/results/stratification_vs_perturbation_sensitivity/raw_tables/'
shuffle_max_prs_strat <- readr::read_csv(paste0(prefix.dir,'gwas',gwas.thres,'_cutoff',sig.cutoff,'_shuffle_max_combined.csv'))
signflip_max_prs_strat <- readr::read_csv(paste0(prefix.dir,'gwas',gwas.thres,'_cutoff',sig.cutoff,'_signflip_max_combined.csv'))
shuffle_usual_prs_strat <- readr::read_csv(paste0(prefix.dir,'gwas',gwas.thres,'_cutoff',sig.cutoff,'_shuffle_usual_combined.csv'))
signflip_usual_prs_strat <- readr::read_csv(paste0(prefix.dir,'gwas',gwas.thres,'_cutoff',sig.cutoff,'_signflip_usual_combined.csv'))

cossimEven.vs.cossim.shuffle.max <- ggplot(shuffle_max_prs_strat, 
                                   aes(x=EVENNESS_COSSIM,
                                       y=COSINE_SIM)) +
  geom_point()+
  theme_bw() +
  stat_smooth(method = "lm",
              formula = y ~ x + I(x^2) + I(x^3),
              se = FALSE,
              alpha=0.5) +
  # stat_smooth(method = "lm", 
  #             formula = y ~ x, 
  #             se = FALSE) +
  ylim(c(0,1.1)) +
  xlab('Entropy of Unsigned Cosine Similarity of PRS with 40 PCs\n(Training Cohort)') +
  ylab('Fraction of Cosine Simlarities for Shuffled PRS\nBeaten by Original PRS (Test Cohort)') +
  ggtitle('PRS Sensitivity vs PC-Similarity Evenness\n(GWAS,cutoff)=(1e-8,1e-10)') +
  scale_y_continuous(breaks = seq(0,1.1,by=0.1)) +
  theme(plot.title = element_text(face='bold'))

absCossim.vs.cossim.shuffle.max <- ggplot(shuffle_max_prs_strat, 
                               aes(x=PC1_ABS_COSSIM,
                                   y=COSINE_SIM)) +
  geom_point()+
  theme_bw() +
  stat_smooth(method = "lm", 
              formula = y ~ x, 
              se = FALSE,
              alpha=0.5) +
  ylim(c(0,1.1)) +
  xlab('Unsigned Cosine Similarity of PRS with PC1\n(Training Cohort)') +
  ylab('Fraction of Cosine Simlarities for Shuffled PRS\nBeaten by Original PRS (Test Cohort)') +
  ggtitle('PRS Sensitivity vs PC1 Stratification\n(GWAS,cutoff)=(1e-8,1e-10)') +
  scale_y_continuous(breaks = seq(0,1.1,by=0.1)) +
  theme(plot.title = element_text(face='bold'))

cossimEven.vs.cossim.signflip.max  <- ggplot(signflip_max_prs_strat, 
                              aes(x=EVENNESS_COSSIM,
                                  y=COSINE_SIM)) +
  geom_point()+
  theme_bw() +
  stat_smooth(method = "lm",
              formula = y ~ x + I(x^2) + I(x^3),
              se = FALSE,
              alpha=0.5) +
  ylim(c(0,1.1)) +
  xlab('Entropy of Unsigned Cosine Similarity of PRS with 40 PCs\n(Training Cohort)') +
  ylab('Fraction of Cosine Simlarities for Sign-flipped PRS\nBeaten by Original PRS (Test Cohort)') +
  ggtitle('PRS Sensitivity vs PC-Similarity Evenness\n(GWAS,cutoff)=(1e-8,1e-10)') +
  scale_y_continuous(breaks = seq(0,1.1,by=0.1)) +
  theme(plot.title = element_text(face='bold'))

combined.gwas1e8.cutoff1e10.max <- gridExtra::grid.arrange(absCossim.vs.cossim.shuffle.max,
                                                              cossimEven.vs.cossim.shuffle.max,
                                                              cossimEven.vs.cossim.signflip.max,
                                                              widths=c(0.333, 0.333,0.333),
                                                              nrow=1)
ggsave(combined.gwas1e8.cutoff1e10.max,
       filename = "/deep_learning/aaw/051723/results/stratification_vs_perturbation_sensitivity/gwas1e8_cutoff1e10_max_allsig.jpg",
       width = 13.5, height = 4.5,
       dpi = 300)

cossimEven.vs.cossim.shuffle.usual <- ggplot(shuffle_usual_prs_strat, 
                                           aes(x=EVENNESS_COSSIM,
                                               y=COSINE_SIM)) +
  geom_point()+
  theme_bw() +
  stat_smooth(method = "lm",
              formula = y ~ x + I(x^2) + I(x^3),
              se = FALSE,
              alpha=0.5) +
  # stat_smooth(method = "lm", 
  #             formula = y ~ x, 
  #             se = FALSE) +
  ylim(c(0,1.1)) +
  xlab('Entropy of Unsigned Cosine Similarity of PRS with 40 PCs\n(Training Cohort)') +
  ylab('Fraction of Cosine Simlarities for Shuffled PRS\nBeaten by Original PRS (Test Cohort)') +
  ggtitle('PRS Sensitivity vs PC-Similarity Evenness\n(GWAS,cutoff)=(1e-8,1e-10)') +
  scale_y_continuous(breaks = seq(0,1.1,by=0.1)) +
  theme(plot.title = element_text(face='bold'))

ggsave(cossimEven.vs.cossim.shuffle.usual,
       filename = "/deep_learning/aaw/051723/results/stratification_vs_perturbation_sensitivity/gwas1e8_cutoff1e10_usual_allsig.jpg",
       width = 4.5, height = 4.5,
       dpi = 300)

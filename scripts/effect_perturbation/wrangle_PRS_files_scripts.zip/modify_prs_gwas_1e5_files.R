#############################################
########### Shuffling Experiment ############
######### Using GWAS threshold 1e-5 #########
########### Target SNP cutoff 1e-8 ##########
#############################################
# Check each file for duplication of variants 
# included in GWAS, combine effect sizes 
# and merge into a single row

#################
## Directories ##
#################
# Create output file 
sink('/deep_learning/aaw/051723/modify_prs_1e5.log')
sink(stdout(), type = "message")

library(data.table)
library(dplyr)
library(bigsnpr)

R.workbench <- TRUE
gwas.thres <- '1e-5'
message('gwas.thres = ', gwas.thres)

if (R.workbench) {
  genos.dir <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  phenos.shortlist <- data.table::fread('/deep_learning/aaw/022823/pheno_names.txt',
                                        header = FALSE)$V1
  #pheno.gwas.dir <- '/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/prs/'
  pheno.gwas.dir <- '/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/prs_v2/'
  out.dir <- '/deep_learning/aaw/040723/results/'
  #X.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_X_metadata.csv')
  #autosome.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_autosome_metadata.csv')
} else {
  genos.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  phenos.shortlist <- data.table::fread('/illumina/scratch/deep_learning/aaw/022823/pheno_names.txt',
                                        header = FALSE)$V1
  #pheno.gwas.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/prs/'
  pheno.gwas.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/summary_stats/gwas/ukb500k/train_80_test_20/prs_v2/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/040723/results/'
  #X.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_X_metadata.csv')
  #autosome.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_autosome_metadata.csv')
}

## Main ------------------------------------------------------------------------
message(date(), ": Performing perturbation experiment")
dup.counter <- 0
for (pheno in phenos.shortlist) {
  # Print message
  message(date(), ": Working on ", pheno)
  
  # Load GWAS results 
  message("Loading GWAS results...")
  pheno.gwas <- data.table::fread(paste0(pheno.gwas.dir,
                                         pheno,
                                         ".loci.common.",gwas.thres,".txt"))
  # Check for duplicate SNPs
  if (length(which(table(pheno.gwas$pos)>1)) > 0) {
    message(length(which(table(pheno.gwas$pos)>1)), ' duplicate variants detected.')
    dup.counter <-  dup.counter + 1
    dup.vars <- names(which(table(pheno.gwas$pos)>1)) %>% as.numeric()
    message('Original no. variants in PRS = ',nrow(pheno.gwas))
    # Replace duplicates with a single row with sum of betas as the new beta
    for (dup.var in dup.vars) {
      this.dup.var <- pheno.gwas %>% subset(pos == dup.var)
      
      # remove duplicates 
      pheno.gwas <- pheno.gwas %>% subset(pos != dup.var)
      
      # add new row with sum of betas
      new.row <- data.frame(chrom=this.dup.var$chrom[1],
                            pos=this.dup.var$pos[1],
                            major=this.dup.var$major[1],
                            minor=this.dup.var$minor[1],
                            beta=sum(this.dup.var$beta),
                            p_value=-99,
                            gwas_p_value=this.dup.var$gwas_p_value[1])
      pheno.gwas <- rbind(pheno.gwas,
                          new.row)
    }
    message('New no. variants in PRS = ',nrow(pheno.gwas))
    
    # Saving results
    message("Saving PRS file")
    data.table::fwrite(pheno.gwas,
                       file = paste0('/deep_learning/aaw/051723/prs/',
                                     pheno,
                                     ".loci.common.",gwas.thres,"_no_dups.txt"))
  } else {
    message('No duplicates. Skipping to next trait')
    data.table::fwrite(pheno.gwas,
                       file = paste0('/deep_learning/aaw/051723/prs/',
                                     pheno,
                                     ".loci.common.",gwas.thres,"_no_dups.txt"))
  }
}
message(date(), ": No. PRS with duplicates found = ", dup.counter)

sink()

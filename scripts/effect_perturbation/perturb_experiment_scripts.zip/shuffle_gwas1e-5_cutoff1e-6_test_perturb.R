#############################################
########### Shuffling Experiment ############
######### Using GWAS threshold 1e-5 #########
########### Target SNP cutoff 1e-6 ##########
################ Sign flips  ################
#############################################
# This version saves predictions on 
# the test set only. It performs: 
# - sign flipping only
# - shuffling
# - sign inversion of all 'target' SNPs
# (5/19/23) New list of phenotypes and PRSes

#################
## Directories ##
#################
# Create output file 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/perturb_gwas1e-5_cutoff1e-6_test.log')
sink(stdout(), type = "message")

library(data.table)
library(dplyr)
library(bigsnpr)

N_SHUFFLES <- 100
R.workbench <- FALSE
gwas.thres <- '1e-5'
sig.cutoff <- 1e-6
message('N_SHUFFLES = ', N_SHUFFLES)
message('gwas.thres = ', gwas.thres)
message('sig.cutoff = ', sig.cutoff)

if (R.workbench) {
  genos.dir <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  phenos.shortlist <- data.table::fread('/deep_learning/aaw/051723/results/pheno_names_gwas1e5.txt',
                                        header = FALSE)$V1
  pheno.gwas.dir <- '/deep_learning/aaw/051723/prs/'
  out.dir <- '/deep_learning/aaw/051723/results/prs/'
  X.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_autosome_metadata.csv')
} else {
  genos.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  phenos.shortlist <- data.table::fread('/illumina/scratch/deep_learning/aaw/051723/results/pheno_names_gwas1e5.txt',
                                        header = FALSE)$V1
  pheno.gwas.dir <- '/illumina/scratch/deep_learning/aaw/051723/prs/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/prs/'
  X.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_autosome_metadata.csv')
}


###############
## Functions ##
###############
getPRSTestOnly <- function(gwas_file) {
  gwas_file$chrom <- as.character(gwas_file$chrom) # This fixes inconsistency
  all.chr <- unique(gwas_file$chrom) 
  test.prs.list <- vector("list", length=length(all.chr))
  names(test.prs.list) <- all.chr
  
  for (chr in all.chr) {
    print(paste0('Working on Chr', chr))
    chr.gwas <- gwas_file %>% subset(chrom == chr)
    # If chr 01 to 09, remove 0 in front
    if (substr(chr,1,1) == '0') {
      chrom <- substr(chr,2,2) 
      obj.bigSNP <- snp_attach(paste0(genos.dir,'ukb_imp_chr', chrom, '_v3.rds'))
    } else {
      obj.bigSNP <- snp_attach(paste0(genos.dir,'ukb_imp_chr', chr, '_v3.rds'))
    }
    # Read genotype object and variant map
    G <- obj.bigSNP$genotypes
    chr.map <- obj.bigSNP$map
    colnames(chr.map)[4] <- 'pos'
    joined.df <- left_join(chr.map, chr.gwas, by = 'pos')
    match.ref.alt <- ((joined.df$allele1 == joined.df$major) |  
                        (joined.df$allele2 == joined.df$major)) & 
      ((joined.df$allele1 == joined.df$minor) |  (joined.df$allele2 == joined.df$minor)) # check for match 
    joined.df$beta0 <- joined.df$beta * ifelse(joined.df$allele1 == joined.df$major,
                                               1, -1) * match.ref.alt
    selected.vars <- which(!is.na(joined.df$beta0))
    e.sizes <- joined.df[selected.vars,]$beta0
    # If ChrX need to use X.metadata
    if (chr == 'X') {
      test.ids <- which(X.metadata$TEST & X.metadata$EURO)
      test.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=test.ids)

    } else {
      test.ids <- which(autosome.metadata$TEST & autosome.metadata$EURO)
      test.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=test.ids)
    }
  }
  
  # Return PRS for test set
  test.prs <- Reduce('+', test.prs.list)[,1] %>% as.vector()
  
  return(test.prs)
}

# message(date(),": Start") # Sat Mar  4 01:30:30 2023: Start
# prs.list <- getPRS(gwas_file)
# message(date(),": End") # Sat Mar  4 01:32:01 2023: End

##########
## Main ##
##########
message(date(), ": Performing perturbation experiment")
message(date(), ": No. phenotypes = ", length(phenos.shortlist))
for (pheno in phenos.shortlist) {
  # Print message
  message(date(), ": Working on ", pheno)
  
  # Load GWAS results 
  message("Loading GWAS results...")
  pheno.gwas <- data.table::fread(paste0(pheno.gwas.dir,
                                         pheno,
                                         ".loci.common.",gwas.thres,"_no_dups.txt"))
  
  # Perform 100 shuffles, saving predictions each time round
  message("Performing perturbation experiments...")
  test.signflip.df <- matrix(nrow = 74084, ncol = 100)
  test.shuffle.df <- matrix(nrow = 74084, ncol = 100)
  
  message("Performing inversion of signs for all weakly significant SNPs...")
  
  pheno.gwas.inversion <- pheno.gwas
  rel.inds <- which(pheno.gwas$gwas_p_value >= sig.cutoff)
  pheno.gwas.inversion$beta[rel.inds] <- pheno.gwas.inversion$beta[rel.inds]*-1
  
  inversion.result <- getPRSTestOnly(pheno.gwas.inversion)
  
  for (i in 1:N_SHUFFLES) {
    message(date(), ": Performing Shuffle ", i)
    set.seed(i)
    pheno.gwas.signflip <- pheno.gwas
    pheno.gwas.shuffle <- pheno.gwas
    
    pheno.gwas.signflip$beta[rel.inds] <- pheno.gwas.signflip$beta[rel.inds]* # sign flip
      (rbinom(length(rel.inds),prob=0.5,size=1)*2 - 1) # no shuffling! 
    pheno.gwas.shuffle$beta[rel.inds] <- sample(pheno.gwas.shuffle$beta[rel.inds]) # shuffle

    shuffle.result <- getPRSTestOnly(pheno.gwas.shuffle)
    signflip.result <- getPRSTestOnly(pheno.gwas.signflip)
    
    test.shuffle.df[,i] <- shuffle.result
    test.signflip.df[,i] <- signflip.result
  }
  # Saving results
  message("Saving results...")
  saveRDS(list(TEST_SIGNFLIP_ONLY=test.signflip.df,
               TEST_SHUFFLE_ONLY=test.shuffle.df,
               INVERSION=inversion.result),
          file = paste0(out.dir, pheno, "_perturb_gwas1e-5_cutoff1e-6_test_pred.rds"))
}

sink()
#############################################
######### Perturbation Experiment ###########
########## Using GWAS cutoff 1e-8 ###########
##### Compute Original PRS (Test/Train) #####
#############################################
# This script saves original predictions on 
# both training and test set 

#################
## Directories ##
#################
# Create output file 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/orig_prs_gwas_1e-8.log')
sink(stdout(), type = "message")

library(data.table)
library(dplyr)
library(bigsnpr)

R.workbench <- FALSE
gwas.thres <- '1e-8'
message('gwas.thres = ', gwas.thres)

if (R.workbench) {
  genos.dir <- '/deep_learning/ukbiobank/data/array_genotypes/backup/'
  phenos.shortlist <- data.table::fread('/deep_learning/aaw/051723/results/pheno_names_gwas1e8.txt',
                                        header = FALSE)$V1
  pheno.gwas.dir <- '/deep_learning/aaw/051723/prs/'
  out.dir <- '/deep_learning/aaw/051723/results/prs/'
  X.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_autosome_metadata.csv')
} else {
  genos.dir <- '/illumina/scratch/deep_learning/ukbiobank/data/array_genotypes/backup/'
  phenos.shortlist <- data.table::fread('/illumina/scratch/deep_learning/aaw/051723/results/pheno_names_gwas1e8.txt',
                                        header = FALSE)$V1
  pheno.gwas.dir <- '/illumina/scratch/deep_learning/aaw/051723/prs/'
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/prs/'
  X.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_autosome_metadata.csv')
}


###############
## Functions ##
###############
getPRS <- function(gwas_file) {
  gwas_file$chrom <- as.character(gwas_file$chrom) # This fixes inconsistency
  all.chr <- unique(gwas_file$chrom) 
  test.prs.list <- vector("list", length=length(all.chr))
  train.prs.list <- vector("list", length=length(all.chr))
  names(test.prs.list) <- all.chr
  names(train.prs.list) <- all.chr
  
  for (chr in all.chr) {
    print(paste0('Working on Chr', chr))
    chr.gwas <- gwas_file %>% subset(chrom == chr)
    # If chr 01 to 09, remove 0 in front
    if (substr(chr,1,1) == '0') {
      chrom <- substr(chr,2,2) 
      obj.bigSNP <- snp_attach(paste0(genos.dir,'ukb_imp_chr', chrom, '_v3.rds'))
    } else {
      obj.bigSNP <- snp_attach(paste0(genos.dir,'ukb_imp_chr', chr, '_v3.rds'))
    }
    # Read genotype object and variant map
    G <- obj.bigSNP$genotypes
    chr.map <- obj.bigSNP$map
    colnames(chr.map)[4] <- 'pos'
    joined.df <- left_join(chr.map, chr.gwas, by = 'pos')
    match.ref.alt <- ((joined.df$allele1 == joined.df$major) |  
                        (joined.df$allele2 == joined.df$major)) & 
      ((joined.df$allele1 == joined.df$minor) |  (joined.df$allele2 == joined.df$minor)) # check for match 
    joined.df$beta0 <- joined.df$beta * ifelse(joined.df$allele1 == joined.df$major,
                                               1, -1) * match.ref.alt
    selected.vars <- which(!is.na(joined.df$beta0))
    e.sizes <- joined.df[selected.vars,]$beta0
    # If ChrX need to use X.metadata
    if (chr == 'X') {
      test.ids <- which(X.metadata$TEST & X.metadata$EURO)
      train.ids <- which(X.metadata$TRAIN & X.metadata$EURO)
      test.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=test.ids)
      train.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=train.ids)
    } else {
      test.ids <- which(autosome.metadata$TEST & autosome.metadata$EURO)
      train.ids <- which(autosome.metadata$TRAIN & autosome.metadata$EURO)
      test.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=test.ids)
      train.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=train.ids)
    }
  }
  
  # Return PRS for both test and train set
  print(as.vector(sapply(train.prs.list, length)))
  train.prs <- Reduce('+', train.prs.list)[,1] %>% as.vector()
  test.prs <- Reduce('+', test.prs.list)[,1] %>% as.vector()
  
  return(list(TRAIN = train.prs,
              TEST = test.prs))
}

getPRSTestOnly <- function(gwas_file) {
  gwas_file$chrom <- as.character(gwas_file$chrom) # This fixes inconsistency
  all.chr <- unique(gwas_file$chrom) 
  test.prs.list <- vector("list", length=length(all.chr))
  names(test.prs.list) <- all.chr
  
  for (chr in all.chr) {
    print(paste0('Working on Chr', chr))
    chr.gwas <- gwas_file %>% subset(chrom == chr)
    # If chr 01 to 09, remove 0 in front
    if (substr(chr,1,1) == '0') {
      chrom <- substr(chr,2,2) 
      obj.bigSNP <- snp_attach(paste0(genos.dir,'ukb_imp_chr', chrom, '_v3.rds'))
    } else {
      obj.bigSNP <- snp_attach(paste0(genos.dir,'ukb_imp_chr', chr, '_v3.rds'))
    }
    # Read genotype object and variant map
    G <- obj.bigSNP$genotypes
    chr.map <- obj.bigSNP$map
    colnames(chr.map)[4] <- 'pos'
    joined.df <- left_join(chr.map, chr.gwas, by = 'pos')
    match.ref.alt <- ((joined.df$allele1 == joined.df$major) |  
                        (joined.df$allele2 == joined.df$major)) & 
      ((joined.df$allele1 == joined.df$minor) |  (joined.df$allele2 == joined.df$minor)) # check for match 
    joined.df$beta0 <- joined.df$beta * ifelse(joined.df$allele1 == joined.df$major,
                                               1, -1) * match.ref.alt
    selected.vars <- which(!is.na(joined.df$beta0))
    e.sizes <- joined.df[selected.vars,]$beta0
    # If ChrX need to use X.metadata
    if (chr == 'X') {
      test.ids <- which(X.metadata$TEST & X.metadata$EURO)
      test.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=test.ids)
      
    } else {
      test.ids <- which(autosome.metadata$TEST & autosome.metadata$EURO)
      test.prs.list[[chr]] <- snp_PRS(G,betas.keep=e.sizes,ind.keep=selected.vars,ind.test=test.ids)
    }
  }
  
  # Return PRS for test set
  test.prs <- Reduce('+', test.prs.list)[,1] %>% as.vector()
  
  return(test.prs)
}

# message(date(),": Start") # Sat Mar  4 01:30:30 2023: Start
# prs.list <- getPRS(gwas_file)
# message(date(),": End") # Sat Mar  4 01:32:01 2023: End

##########
## Main ##
##########
message(date(), ": Computing original PRS predictions")
message(date(), ": No. phenotypes = ", length(phenos.shortlist))
for (pheno in phenos.shortlist) {
  # Print message
  message(date(), ": Working on ", pheno)
  
  # Load GWAS results 
  message("Loading GWAS results...")
  pheno.gwas <- data.table::fread(paste0(pheno.gwas.dir,
                                         pheno,
                                         ".loci.common.",gwas.thres,"_no_dups.txt"))
  # Save original predictions
  if (!file.exists(paste0(out.dir, pheno, "_orig_pred.rds"))) {
    message("Computing and saving original predictions...")
    orig.preds <- getPRS(gwas_file = pheno.gwas)
    saveRDS(orig.preds, file = paste0(out.dir, pheno, "_gwas_1e-8_orig_test_train_pred.rds"))
  } else {
    message("Original predictions already computed for ", pheno, ", skipping...")
  }
}

sink()

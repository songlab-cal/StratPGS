####################################################
############# Perturbation Experiment ##############
########### PC metrics on Training Data ############
####################################################
# This script computes stratification of PRS
# by genetic PCs using PCs computed on entire cohort
# Relevant measures include: 
# - PC1 cosine sim
# - PC1 abs cosine sim
# - PC1 Pearson cor
# - PC1 abs Pearson cor
# - PC1 cossim rank
# - PC1 Pearson cor rank
# - Evenness cos sim
# - Evenness Pearson
# - R2 of PRS regressed against PCs
# 
# Created on 5/21/23

## Create log file -------------------------------------------------------------
# Create output file 
sink('/illumina/scratch/deep_learning/aaw/051723/logs/get_prs_pc_stratification_gwas1e-5.log')
sink(stdout(), type = "message")

## Variables -------------------------------------------------------------------
R.workbench <- FALSE
if (R.workbench) {
  phenos.shortlist <- data.table::fread('/deep_learning/aaw/051723/results/pheno_names_gwas1e5.txt',
                                        header = FALSE)$V1
  out.dir <- '/deep_learning/aaw/051723/results/prs_pc_stratification/'
  phenos.df <- readr::read_csv('/deep_learning/aaw/101922/data_10pct/n487309_phenos.csv')
  shuffle.result.dir <- '/deep_learning/aaw/051723/results/prs/'
  gPCs.train.only <- readr::read_csv('/deep_learning/aaw/042023/gPCs/gPCs_train_only.csv')
  X.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/deep_learning/aaw/022823/ind_autosome_metadata.csv')
  phenos.train.subset.df <- readr::read_csv('/deep_learning/aaw/042023/phenos/phenos_train_subset_df.csv')
} else {
  phenos.shortlist <- data.table::fread('/illumina/scratch/deep_learning/aaw/051723/results/pheno_names_gwas1e5.txt',
                                        header = FALSE)$V1
  out.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/prs_pc_stratification/'
  phenos.df <- readr::read_csv('/illumina/scratch/deep_learning/aaw/101922/data_10pct/n487309_phenos.csv')
  shuffle.result.dir <- '/illumina/scratch/deep_learning/aaw/051723/results/prs/'
  gPCs.train.only <- readr::read_csv('/illumina/scratch/deep_learning/aaw/042023/gPCs/gPCs_train_only.csv')
  X.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_X_metadata.csv')
  autosome.metadata <- readr::read_csv('/illumina/scratch/deep_learning/aaw/022823/ind_autosome_metadata.csv')
  phenos.train.subset.df <- readr::read_csv('/illumina/scratch/deep_learning/aaw/042023/phenos/phenos_train_subset_df.csv')
}

gwas.thres <- '1e-5'
message(date(), ': gwas.thres = ', gwas.thres)

## Main Body -------------------------------------------------------------------
# Do once and comment out - OLD CODE FROM APRIL 2023, DIRECTORY VARIABLES ARE OLD
# train.ids <- which(autosome.metadata$TRAIN & autosome.metadata$EURO)
# train.metadata <- autosome.metadata[train.ids,]; colnames(train.metadata)[1] <- 'sample_id'
# phenos.train.subset.df <- phenos.df[,c(1,which(grepl("original.IRNT", colnames(phenos.df))))] %>% subset(sample_id %in% train.metadata$sample_id)
# readr::write_csv(phenos.train.subset.df,
#                  file = paste0(out.dir, "phenos/phenos_train_subset_df.csv"))
# readr::write_csv(gPCs.train.only,
#                  file = paste0(out.dir, "gPCs/gPCs_train_only.csv"))
assertthat::assert_that(identical(sort(gPCs.train.only$sample_id), sort(phenos.train.subset.df$sample_id)))
train.ids <- which(autosome.metadata$TRAIN & autosome.metadata$EURO)

getEvenness <- function(v) {
  norm.v <- abs(v)/sum(abs(v))
  return(sum(norm.v * log(1/norm.v)))
}
stratify.metrics.df <- data.frame(PHENO = character(),
                                  PC1_COSSIM = numeric(),
                                  PC1_ABS_COSSIM = numeric(),
                                  PC1_PEARSON = numeric(),
                                  PC1_ABS_PEARSON = numeric(),
                                  PC1_SPEARMAN = numeric(),
                                  PC1_ABS_SPEARMAN = numeric(),
                                  PC1_COSSIM_ABS_RANK = numeric(),
                                  PC1_PEARSON_ABS_RANK = numeric(),
                                  PC1_SPEARMAN_ABS_RANK = numeric(),
                                  EVENNESS_COSSIM = numeric(),
                                  EVENNESS_PEARSON = numeric(),
                                  EVENNESS_SPEARMAN = numeric(),
                                  R2_PHENO_PCS = numeric(),
                                  ADJ_R2_PHENO_PCS = numeric(),
                                  LinearModel_NUM_SIG_VARS = numeric())
for (pheno in phenos.shortlist) {
  message(date(), ": Working on ", pheno)
  # Load phenotype values
  #pheno.name <- paste0(pheno,'.all_ethnicities.both.original.IRNT')
  #pheno.vals <- phenos.train.subset.df[,c('sample_id',pheno.name)]
  
  # Load PRS values
  original.pred <- readRDS(paste0(shuffle.result.dir,pheno,"_gwas_",gwas.thres,"_orig_test_train_pred.rds"))
  train.PRS.df <- data.frame(sample_id = autosome.metadata$ID_1[train.ids],
                             PRS = original.pred$TRAIN)
  # Merge with PC dataframe
  merged.df <- merge(train.PRS.df,gPCs.train.only,by='sample_id')
  #pheno.vals <- train.PRS.df[[pheno.name]]
  spearman.prof <- apply(merged.df[,-c(1,2)], 2, function(x){cor(x,merged.df[['PRS']],
                                                method = 'spearman',
                                                use = "pairwise.complete.obs")})
  pearson.prof <-  apply(merged.df[,-c(1,2)], 2, function(x){cor(x,merged.df[['PRS']],
                                                                 method = 'pearson',
                                                                 use = "pairwise.complete.obs")})
  cossim.prof <-  apply(merged.df[,-c(1,2)], 2, function(x){sum(x*merged.df[['PRS']],
                                                                na.rm=TRUE)/
      ((norm(na.omit(merged.df[['PRS']]),'2')*norm(na.omit(x),'2')))})
  
  # Remove irrelevant column and rename phenotype column before fitting a linear model
  colnames(merged.df)[2] <- 'PHENO'; merged.df[['sample_id']] <- NULL
  model.fit <- lm(PHENO~.,data=merged.df)
  
  stratify.metrics.df <- rbind(stratify.metrics.df,
                               data.frame(PHENO = pheno,
                                          PC1_COSSIM = as.numeric(cossim.prof[1]),
                                          PC1_ABS_COSSIM = abs(as.numeric(cossim.prof[1])),
                                          PC1_PEARSON = as.numeric(pearson.prof[1]),
                                          PC1_ABS_PEARSON = abs(as.numeric(pearson.prof[1])),
                                          PC1_SPEARMAN = as.numeric(spearman.prof[1]),
                                          PC1_ABS_SPEARMAN = abs(as.numeric(spearman.prof[1])),
                                          PC1_COSSIM_ABS_RANK = as.numeric(rank(abs(cossim.prof))[1]),
                                          PC1_PEARSON_ABS_RANK = as.numeric(rank(abs(pearson.prof))[1]),
                                          PC1_SPEARMAN_ABS_RANK = as.numeric(rank(abs(spearman.prof))[1]),
                                          EVENNESS_COSSIM = getEvenness(cossim.prof),
                                          EVENNESS_PEARSON = getEvenness(pearson.prof),
                                          EVENNESS_SPEARMAN = getEvenness(spearman.prof),
                                          R2_PHENO_PCS = summary(model.fit)$r.squared,
                                          ADJ_R2_PHENO_PCS = summary(model.fit)$adj.r.squared,
                                          LinearModel_NUM_SIG_VARS = sum(summary(model.fit)$coefficients[,4] < 0.05/41)))
}

readr::write_csv(stratify.metrics.df,
                 file = paste0(out.dir,'train_n288728_prs_gwas_',gwas.thres,'_gPC_metrics.csv'))

# close(fileConn)
sink()

## Analysis --------------------------------------------------------------------
gwas.thres <- '1e-5'
stratify_metrics_gwas1e5 <- readr::read_csv(paste0('/deep_learning/aaw/051723/results/prs_pc_stratification/train_n288728_prs_gwas_',gwas.thres,'_gPC_metrics.csv'))
